library("rstan")
library("bayesplot")
library("zoo")
library("dplyr")
library("reshape2")
library("scales")
library("ggridges")
library("ggthemes")
library("ggcor")
library("ggplot2")
library("gridExtra")
library("ggalt")
library("aomisc")
library("meta")
library("RColorBrewer")
library("grid")
library("Hmisc")
library("ggthemr")
library("caret")
setwd("E:/COVID19_vacciantion1210")#set up your setwd here
Sys.setlocale("LC_TIME","English")
source('code/main.R')
source('code/rstanmain.R')
RT<-read.csv("Dataset/owid-covid-data.csv")# Daily reproduction rate data (Rt)
Variants<-read.csv("Dataset/covid-variants.csv")# Weekly variant structure data
NPI<-"Dataset/OxCGRT_latest.csv" # Daily non-pharmaceutical interventions data (NPI)
POP<-"Dataset/pop_data_age_by_country.csv" # Total population number of each country
index<-'Dataset/index.csv'# Control variables, contained population density, age structre and health index of each country
Env<-'Dataset/20200120-20211201humidity&airtem.csv'# Control variables, contained temperature and humidity. Only air temperature were considered in our study
Vaccination<-'Dataset/vaccinations.csv' # Daily vaccination data 
Vaccman<-'Dataset/vaccinations-by-manufacturer.csv'# Weekly vaccination manufacturer structure
agedata<-"Dataset/pop_structure_data.csv"
school_holiday<-"Dataset/day_public_and_school_holidays_2010_2019.csv"
vaccine_effect<-"Dataset/vaccine_effectiveness_V1.csv"
#vaccine_effect<-"Dataset/vaccine_effectiveness_S2.csv"
variant_tran<-"Dataset/variant_transmission.csv"# transmission parameters of each variant

#############����ÿ�����ҵ����ݼ���Ч��######################
R0calculate_withineachcountry<-function(DatasetV2,source,mcon,xname,monthnum){
  if (dir.exists(source)==F){dir.create(source)
  }else{print("This path has been exists")}
  lapply(split(DatasetV2,DatasetV2$iso_code),FUN=function(v){
    out<-paste0(source,unique(v$location),"_withinR0/")
    if (dir.exists(out)==F){dir.create(out)
    }else{print("This path has been exists")}
    output<-paste0(out,"all.rds")
    start<-as.Date("2020-08-01")
    end<-as.Date("2021-10-26")
    fit<-alpha_calculate_withinR0_con(mcon,v,start,end,output,xname,monthnum)
    gc()
    print(paste0(unique(v$location),start,"has been processed"))
  })
}

R0process<-function(RT,Variants,Vaccination,NPI,POP,index,Env,
                      vaccine_effect,variant_tran,i,outpath,
                      mcon,xname,monthnum){
  Dataset<-merge_dataset(RT,Variants,Vaccination,NPI,POP,index,Env)
  Dataset<-subset(Dataset,Dataset$continent=="Europe"|Dataset$location=="Israel")
  gc()
  DatasetV2<-RatioVariable_merge(Dataset,vaccine_effect,variant_tran,list=c(1:length(unique(Dataset$location))))
  if (length(xname)>2){
    DatasetV2$Interaction<-DatasetV2[,xname[1]]*DatasetV2[,xname[2]]
  }
  write.csv(DatasetV2,paste0(outpath,"/Europe_dataset_1220withinR0.csv"),row.names = F)
  R0calculate_withineachcountry(DatasetV2,source=paste0(outpath,"/R0_calculate/"),mcon,xname,monthnum)
}
R0extract<-function(path){
  conlist<-list.files(path)
  datapath<-list.files(strsplit(path,"/")[[1]][1],".csv")
  Da<-read.csv(paste0(strsplit(path,"/")[[1]][1],"/",datapath),stringsAsFactors = F)
  condata<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(Da,Da$location==strsplit(c,"_")[[1]][1])
    k<-subset(k,k$Date>="2020-08-01"&k$Date<"2021-10-26")
    f<-readRDS(paste0(path,"/",c,"/all.rds"))
    R0<-as.data.frame(rstan::extract(f)$R0)
    colnames(R0)<-k$Date
    R0d<-mcmc_intervals_data(R0,prob = .5,prob_outer= .95,point_est="mean")
    k<-k[order(k$Date),]
    R0d<-R0d[order(R0d$parameter),]
    k$R0<-R0d$m
    k$R0_CI95low<-R0d$ll
    k$R0_CI95high<-R0d$hh
    k$R0_sd<-apply(R0,2,sd)
    return(k)
    }))
  write.csv(condata,paste0(strsplit(path,"/")[[1]][1],"/R0_",datapath))
  return(condata)
}

outpath<-"20200112_newR0V2"
if (dir.exists(outpath)==F){dir.create(outpath)
}else{print("This path has been exists")}
R0process(RT,Variants,Vaccination,NPI,POP,index,Env,
          vaccine_effect,variant_tran,i,outpath,
          mcon=stan_model('stan_R0_withinModel_lastV2.stan'),
          xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),monthnum=15)
DatasetV2<-R0extract("20200112_newR0V2/R0_calculate")
################################################################################
Leave_one_out_Validation<-function(Datapath,outpath,mcon,xname){
  DatasetV2<-read.csv(paste0(Datapath,"/Europe_dataset_1220withinR0.csv"),stringsAsFactors = F)
  lapply(unique(DatasetV2$location),function(x){
    D<-subset(DatasetV2,DatasetV2$location!=x)
    out<-paste0(outpath,"/all_without_",x,".rds")
    start<-as.Date("2020-08-01")
    end<-as.Date("2021-10-26")
    fit<-alpha_calculate_withinR0_all(mcon,D,start,end,out,xname,monthnum=15)
    gc()
    print(paste("Validation without",x,"has been processed"))
  })
}
outpath<-"20220112_newR0_pop"
if (dir.exists(outpath)==F){dir.create(outpath)
}else{print("This path has been exists")}
Leave_one_out_Validation(Datapath="20200112_newR0V2",outpath,
                         mcon=stan_model('stan_R0_withinModel_last.stan'),
                         xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"))
####################fig 2 &meta anlaysis########################################
counresultplot<-function(DatasetV2,path,outname,xname,outpath){
  DatasetV2$Date<-as.Date(DatasetV2$Date)
  efdata<-list()
  conlist<-list.files(path)
  condata<-lapply(conlist,function(c){
    DD<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    DD$Tem<-(DD$Tem-min(DD$Tem))/(max(DD$Tem)-min(DD$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(DD,DD$Date>=start&DD$Date<(end+1))
      X<-as.data.frame(do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      })))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      for (k in c(xname,"Air Temperature","Epslion")){
        pars[,k]<- pars[,k]*X[,k]}
      pars$all_SI<-pars$StringencyIndex+pars$Interaction
      pars$all_V<-pars$Fully_vaccinated_effect+pars$Interaction
      #write.csv(pars,paste0("sensitivity_analysis/",outname,"_",c,"_",start,".csv"),row.names = F)
      pars$all<-apply(pars,1,sum)
      pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
      pars<-(1-exp(-pars))*100
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="mean")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      pard$strength[which(pard$parameter=="all_SI")]<-X[,"StringencyIndex"]
      pard$strength[which(pard$parameter=="all_V")]<-X[,"Fully_vaccinated_effect"]
      return(pard)
    }))
    return(d)
  })
  c<-do.call(rbind,condata)
  write.csv(c,paste0(outpath,"/SI_country_",outname,".csv"),row.names = F)
  plot<-lapply(condata,function(r){
    rg<-subset(r,r$parameter=="Fully_vaccinated_effect"|r$parameter=="StringencyIndex"|r$parameter=="Interaction")
    rg$start[which(rg$parameter=="Fully_vaccinated_effect")]<-rg$start[which(rg$parameter=="Fully_vaccinated_effect")]+10
    rg$start[which(rg$parameter=="Interaction")]<-rg$start[which(rg$parameter=="Interaction")]+20
    g<-ggplot(data=rg)+
      geom_bar(aes(x=as.Date(start),y=strength*100,fill=parameter),stat="identity",
               position=position_dodge(width=0),alpha=0.2,width=8,size=0.1)+
      geom_xspline(aes(x=as.Date(start),y=m,color=parameter),size=0.1)+
      theme_clean()+
      geom_errorbar(mapping = aes_(ymin =~l, ymax=~h, x=~as.Date(start),color= ~parameter),
                    show.legend = T,alpha=0.7,width=8,
                    size=0.5)+
      geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1)+
      scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                   breaks=("4 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
      scale_shape_manual(values = c(21,24,4))+
      scale_color_manual(values=c("#0b5c9e","#880208","#80581d"))+
      scale_fill_manual(values=c("#0b5c9e","#880208","#80581d"))+
      scale_size_continuous(breaks=c(0,0.2,0.4,0.6,0.8,1.0))+
      scale_y_continuous(limits=c(-10,100),breaks=c(0,25,50,75,100),expand=c(0,0))+
      labs(y =paste0("Reduction in Rt","(%)"),x = NULL,title=unique(rg$country))+
      guides(color=guide_legend(nrow=1,byrow=TRUE))+
      theme(legend.position = "",
            panel.grid.major = element_line(colour = "white"),
            panel.grid.minor = element_line(colour = "white"),
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
            axis.title.x= element_text(color="black",size = unit(9, "pt")),
            axis.text.x = element_text(color="black",size = unit(9, "pt")),
            axis.title.y= element_blank(),
            axis.text.y = element_blank(),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.border= element_rect(color=NA,fill=NA),
            panel.background=element_rect(fill = "transparent",colour = NA))
    return(g)
  })
  for(i in 1:length(plot)){
    if(i%%2==1){
      plot[[i]]<-plot[[i]]+theme(axis.ticks.y=element_line(color="black"),
                                 axis.title.y= element_text(color="black",angle=90,size = unit(9, "pt")),
                                 axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")))}
  }
  legend<-plot[[1]]+guides(color=guide_legend(ncol=1))+
    theme(legend.position = "right",legend.title=element_blank(),
          legend.text = element_text(size = unit(9, "pt")),
          legend.background = element_rect(fill=NA,color=NA),
          legend.key=element_rect(fill="transparent"))
  plot[[32]]<-g_legend(legend)
  for (i in seq(1,32,2)){
    pl<-grid.arrange(plot[[i]],plot[[i+1]],ncol =2)
    ggsave(paste0(outpath,"/",outname,i,".pdf"),pl,units="mm",width=140,height=50,device = cairo_pdf)
    ggsave(paste0(outpath,"/",outname,i,".png"),pl,units="mm",width=140,height=50)
  }
  
  dev.off()
  pod<-subset(c,c$parameter=="Fully_vaccinated_pre")
  po<-ggplot(data=pod)+geom_point(aes(x=strength*100,y=m),size=0.6)+ theme_clean()+
    scale_y_continuous(limits=c(0,50),breaks=c(0,10,20,30,40,50),expand=c(0.1,0.1))+
    labs(y =paste0("Reduction in Rt","(%)"),x = "Vaccinated rate")+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "",
          panel.grid.major = element_line(colour = "white"),
          panel.grid.minor = element_line(colour = "white"),
          legend.title=element_blank(),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/vaccination_",outname,".pdf"),po,units="mm",width=100,height=80,device = cairo_pdf)
  
}
meta_alalysis<-function(DatasetV2,path,outname,xname,outpath){
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      for (k in c(xname,"Air Temperature","Epslion")){
        pars[,k]<- pars[,k]*X[,k]}
      pars$all<-apply(pars,1,sum)
      pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
      pars<-(1-exp(-pars))*100
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$start),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(start=f$start[1],par="R0",
                  strength=NA,
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
    #air temperature
    sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
    si<-summary(sia)$random
    weight<-sia$w.random/sum(sia$w.random)
    t<-data.frame(start=f$start[1],par="Air Temperature",
                  strength=mean(f$strength_Tem),
                  m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight))
    #Epslion
    sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
    si<-summary(sie)$random
    weight<-sie$w.random/sum(sie$w.random)
    e<-data.frame(start=f$start[1],par="Epslion",
                  strength=1,
                  m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight))
    
    if(max(f$median_SI)>0){
      ds<-subset(f,f$mean_SI>0)
      sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
      si<-summary(sim)$random
      weight<-sim$w.random/sum(sim$w.random)
      s<-data.frame(start=f$start[1],par="Stringency Index",
                    strength=mean(f$strength_SI),
                    m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight))
    }else{s<-NULL}
    if(is.null(f$mean_V)==F){
      if(max(f$mean_V)>0){
        dv<-subset(f,f$mean_V>0)
        vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        v<-data.frame(start=dv$start[1],par="Vaccination",
                      strength=mean(dv$strength_V),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{v<-NULL}
      if(max(f$median_Int)>0){
        dI<-subset(f,f$median_Int>0)
        vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab=dI$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                      strength=mean(dI$strength_Int),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{i<-NULL}
      X<-do.call(rbind,list(r,t,e,s,v,i))
    }else{
      X<-do.call(rbind,list(r,t,e,s))
    }
    X$Rt<-mean(f$Rt)   #Rt
    return(X)
    print(paste0(unique(f$start),"has been processed"))
  }))
  all<-do.call(rbind,lapply(split(d1,d1$start),function(x){
    x1<-subset(x,x$par!="R0")
    x1$m<- -log(1-x1$m/100)
    x1$lower<- -log(1-x1$lower/100)
    x1$upper<- -log(1-x1$upper/100)
    all1<-data.frame(start=unique(x1$start),par="all",
                     strength=NA,
                     m=(1-exp(-sum(x1$m)))*100,lower=(1-exp(-sum(x1$lower)))*100,upper=(1-exp(-sum(x1$upper)))*100)
    all2<-data.frame(start=unique(x1$start),par="all_SI&V",
                     strength=NA,
                     m=(1-exp(-sum(x1$m[which(x1$par!="Air Temperature"&x1$par!="Epslion")])))*100,
                     lower=(1-exp(-sum(x1$lower[which(x1$par!="Air Temperature"&x1$par!="Epslion")])))*100,
                     upper=(1-exp(-sum(x1$upper[which(x1$par!="Air Temperature"&x1$par!="Epslion")])))*100)
    all3<-data.frame(start=unique(x1$start),par="all_SI",
                     strength=NA,
                     m=(1-exp(-sum(x1$m[which(x1$par=="Stringency Index"|
                                              x1$par=="Interaction of SI and Vaccination")])))*100,
                     lower=(1-exp(-sum(x1$lower[which(x1$par=="Stringency Index"|
                                                      x1$par=="Interaction of SI and Vaccination")])))*100,
                     upper=(1-exp(-sum(x1$upper[which(x1$par=="Stringency Index"|
                                                      x1$par=="Interaction of SI and Vaccination")])))*100)
    all4<-data.frame(start=unique(x1$start),par="all_V",
                     strength=NA,
                     m=(1-exp(-sum(x1$m[which(x1$par=="Vaccination"|
                                              x1$par=="Interaction of SI and Vaccination")])))*100,
                     lower=(1-exp(-sum(x1$lower[which(x1$par=="Vaccination"|
                                                      x1$par=="Interaction of SI and Vaccination")])))*100,
                     upper=(1-exp(-sum(x1$upper[which(x1$par=="Vaccination"|
                                                      x1$par=="Interaction of SI and Vaccination")])))*100)
    all<-do.call(rbind,list(all1,all2,all3,all4))
    all$Rt<-unique(x1$Rt)
    return(all)}))
  meta<-do.call(rbind,list(d1,all))
  write.csv(meta,paste0(outpath,"/Meta_",outname,".csv"),row.names = F)
  #write.csv(eachC,paste0("picture/countryresult_result_",outname,".csv"),row.names = F)
  d2<-subset(meta,meta$par=="Stringency Index"|meta$par=="Vaccination"|meta$par=="Interaction of SI and Vaccination"|
                  meta$par=="all_SI&V"|meta$par=="all_SI"|meta$par=="all_V")
  d2$shape<-"Individual"
  d2$shape[which(d2$par=="all_SI"|d2$par=="all_V")]<-"Combined"
  d2$parameter<-"NPIs"
  d2$parameter[which(d2$par=="Vaccination"|d2$par=="all_V")]<-"Vaccination"
  d2$parameter[which(d2$par=="Interaction of SI and Vaccination")]<-"Interaction"
  d2$parameter[which(d2$par=="all_SI&V")]<-"Combined effect of NPIs and vaccination"
  Sys.setlocale("LC_TIME","English")
  d2$start[which(d2$parameter=="NPIs")]<-d2$start[which(d2$parameter=="NPIs")]+10
  d2$start[which(d2$parameter=="Vaccination")]<-d2$start[which(d2$parameter=="Vaccination")]+20
  g<-ggplot(data=d2)+
    geom_xspline(aes(x=as.Date(start),y=m,color=parameter,linetype=shape),size=0.2)+
    #geom_col(aes(x=as.Date(start),y=strength*100,fill=par),alpha=0.1)
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~parameter),
                  show.legend = T,width=6,size=0.2,alpha=0.3)+
    #position =  position_dodge(width=0.2))+
    geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1.2)+
    #geom_smooth(aes(x=as.Date(start),y=real),span=0.4,color="#8d8e96",linetype = "dashed")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    #602029��ɫ 606bbc��ɫ 4c753��ɫ dda203��ɫ
    scale_linetype_manual(values = c("dashed","solid"))+
    scale_shape_manual(values = c(15,4,21,24))+
    scale_color_manual(values=c("black","#80581d","#0b5c9e","#880208"))+
    scale_fill_manual(values=c("black","#80581d","#0b5c9e","#880208"))+
    scale_y_continuous(limits=c(0,65),breaks=c(0,20,40,60),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_mainpar_",outname,".pdf"),g,units="mm",width=140,height=90,device = cairo_pdf)
  ##############fig 2#######################
  d2<-subset(meta,meta$par=="all_SI&V"|meta$par=="all_SI"|meta$par=="all_V")
  d2$parameter<-"NPIs"
  d2$parameter[which(d2$par=="all_V")]<-"Vaccination"
  d2$parameter[which(d2$par=="all_SI&V")]<-"Combined effect of NPIs and vaccination"
  Sys.setlocale("LC_TIME","English")
  d2$start[which(d2$parameter=="NPIs")]<-d2$start[which(d2$parameter=="NPIs")]+10
  d2$start[which(d2$parameter=="Vaccination")]<-d2$start[which(d2$parameter=="Vaccination")]+20
  g1<-ggplot(data=d2)+
    geom_xspline(aes(x=as.Date(start),y=m,color=parameter),size=0.2)+
    #geom_col(aes(x=as.Date(start),y=strength*100,fill=par),alpha=0.1)
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~parameter),
                  show.legend = T,width=6,size=0.2,alpha=0.3)+
    #position =  position_dodge(width=0.2))+
    geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1.2)+
    #geom_smooth(aes(x=as.Date(start),y=real),span=0.4,color="#8d8e96",linetype = "dashed")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    #602029��ɫ 606bbc��ɫ 4c753��ɫ dda203��ɫ
    scale_shape_manual(values = c(15,21,24))+
    scale_color_manual(values=c("black","#0b5c9e","#880208"))+
    scale_fill_manual(values=c("black","#0b5c9e","#880208"))+
    scale_y_continuous(limits=c(0,65),breaks=c(0,20,40,60),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_mainpar_fig2_",outname,".pdf"),g1,units="mm",width=140,height=90,device = cairo_pdf)

  #########fig 3 subfigure############
  d2<-subset(meta,meta$par=="Stringency Index"|meta$par=="Vaccination"|meta$par=="Interaction of SI and Vaccination")
  d2$parameter<-"NPIs"
  d2$parameter[which(d2$par=="Vaccination")]<-"Vaccination"
  d2$parameter[which(d2$par=="Interaction of SI and Vaccination")]<-"Interaction of NPIs and Vaccination"
  Sys.setlocale("LC_TIME","English")
  d2$start[which(d2$parameter=="NPIs")]<-d2$start[which(d2$parameter=="NPIs")]+10
  d2$start[which(d2$parameter=="Vaccination")]<-d2$start[which(d2$parameter=="Vaccination")]+20
  g2<-ggplot(data=d2)+
    geom_xspline(aes(x=as.Date(start),y=m,color=parameter),size=0.2)+
    #geom_col(aes(x=as.Date(start),y=strength*100,fill=par),alpha=0.1)
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~parameter),
                  show.legend = T,width=6,size=0.2,alpha=0.3)+
    geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1.2)+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_shape_manual(values = c(4,21,24))+
    scale_color_manual(values=c("#a06f24","#0b5c9e","#880208"))+
    scale_fill_manual(values=c("#a06f24","#0b5c9e","#880208"))+
    scale_y_continuous(limits=c(0,50),breaks=c(0,10,20,30,40),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  #ggsave(paste0("picture/",outname,".png"),g,units="mm",width=160,height=120)
  ggsave(paste0(outpath,"/Meta_mainpar_fig3_",outname,".pdf"),g2,units="mm",width=75,height=90,device = cairo_pdf)
  dev.off()
  
  d3<-subset(meta,meta$par=="Air Temperature")
  d3$start<-d3$start+15
  g3<-ggplot(data=d3)+
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~par),
                  show.legend = T,width=6,size=0.2,alpha=0.5)+
    geom_xspline(aes(x=as.Date(start),y=m,color=par),size=0.2)+
    geom_point(aes(x=as.Date(start),y=m),shape=12,size=1.2,color="#080e12")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_color_manual(values=c("#2b343d"))+
    scale_fill_manual(values=c("#2b343d"))+
    scale_y_continuous(limits=c(-20,20),breaks=c(-10,0,10),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "top",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_unseenFactors_tem_",outname,".pdf"),g3,units="mm",width=140,height=90,device = cairo_pdf)

  
  d3<-subset(meta,meta$par=="Epslion")
  d3$start<-d3$start+15
  g3<-ggplot(data=d3)+
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~par),
                  show.legend = T,width=6,size=0.2,alpha=0.5)+
    geom_xspline(aes(x=as.Date(start),y=m,color=par),size=0.2)+
    geom_point(aes(x=as.Date(start),y=m),shape=12,size=1.2,color="#080e12")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_color_manual(values=c("#4c5b6b"))+
    scale_fill_manual(values=c("#4c5b6b"))+
    scale_y_continuous(limits=c(-15,35),breaks=c(-10,0,10,20,30),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "top",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_unseenFactors_e_",outname,".pdf"),g3,units="mm",width=140,height=90,device = cairo_pdf)
  
  pod<-subset(meta,meta$par=="Vaccination"|meta$par=="all_V")
  pod<-subset(pod,pod$m!=0)
  pod$strength[which(pod$par=="all_V")]<-pod$strength[which(pod$par=="Vaccination")]
  po<-ggplot(data=pod)+geom_point(aes(x=strength*100,y=m,color=par),size=1,shape=21)+ theme_clean()+
    scale_y_continuous(limits=c(0,40),breaks=c(0,10,20,30,40),expand=c(0.01,0))+
    scale_color_manual(values=c("#a6a07d","#69491A"))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = "Practical vaccination rate")+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "white"),
          panel.grid.minor = element_line(colour = "white"),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          legend.title=element_blank(),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/vaccination_meta_",outname,".pdf"),po,units="mm",width=75,height=90,device = cairo_pdf)
  dev.off()
  }
meta_R0<-function(DatasetV2,path,outname,outpath){
  efdata<-list()
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    d<-do.call(rbind,lapply(split(k,k$Date),function(i){
      data<-data.frame(n=1,sd_R0=i$R0_sd,mean_R0=i$R0,
                       q1_R0=i$R0_CI95low,q3_R0=i$R0_CI95high,
                       country=strsplit(c,"_")[[1]][1],Date=unique(i$Date),
                       Rt=i$Rt)
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$Date),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(Date=unique(f$Date),par="R0",
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
    r$Rt<-mean(f$Rt)   #Rt
    return(r)
    print(paste0(unique(f$Date),"has been processed"))
  }))
  write.csv(d1,paste0(outpath,"/R0_meta_",outname,".csv"),row.names = F)
  #write.csv(eachC,paste0("picture/countryresult_result_",outname,".csv"),row.names = F)
  g<-ggplot(data=d1)+
    geom_ribbon(aes(x=as.Date(Date),ymin=lower,ymax=upper),fill="grey93",alpha=0.7)+
    geom_ribbon(aes(x=as.Date(Date),ymin=Rt,ymax=m),fill="#A8D8CD",alpha=0.4)+
    geom_line(aes(x=as.Date(Date),y=Rt),size=0.2,color="#377375")+
    geom_line(aes(x=as.Date(Date),y=m),size=0.2,linetype="dashed",color="#2A484E")+
    theme_clean()+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_y_continuous(limits=c(0.5,4),breaks=c(1,2,3),expand=c(0,0))+
    labs(y =expression("Observed variation of"*"  "*R["0,t"]),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = 10),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = 10),
          axis.title.y= element_text(color="black",size = 10),
          axis.text.y= element_text(color="black",hjust=1,size = 10),
          plot.margin=unit(c(0.2,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  #ggsave(paste0("picture/",outname,".png"),g,units="mm",width=160,height=120)
  ggsave(paste0(outpath,"/",outname,"_R0.pdf"),g,units="mm",width=140,height=50,device = cairo_pdf)
  dev.off()
}
outpath<-"20220112_resultV2"
if (dir.exists(outpath)==F){dir.create(outpath)
}else{print("This path has been exists")}
path<-"20200112_newR0V2/R0_calculate"
DatasetV2<-read.csv("20200112_newR0V2/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
counresultplot(DatasetV2,path,outname="20220112",
               xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),outpath)
meta_alalysis(DatasetV2,path,outname="20220112",
              xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),outpath)
meta_R0(DatasetV2,path,outname="20220112",outpath)
##################extract sensitivity analysis result##############

##################################################
R0plot<-function(DatasetV2,outname){
  DatasetV2$Date<-as.Date(DatasetV2$Date)
  plot<-lapply(split(DatasetV2,DatasetV2$iso_code),function(r){
    rg<-r[,c("Date","R0","Rt")]
    rg<-melt(rg,id="Date")
    g<-ggplot()+
      geom_errorbar(data=r,mapping = aes_(ymin =~R0_CI95low, ymax=~R0_CI95high, x=~as.Date(Date)),color="grey80",
                    show.legend = T,alpha=0.9,width=1,size=0.2, position =  position_dodge(width=0.2))+
      geom_xspline(data=rg,aes(x=as.Date(Date),y=value,color=variable))+
      theme_clean()+
      geom_point(data=rg,aes(x=as.Date(Date),y=value,color=variable),size=0.5,shape=12)+
      #geom_smooth(aes(x=as.Date(start),y=real),span=0.4,color="#8d8e96",linetype = "dashed")+
      scale_x_date(limits=as.Date(c("2020-07-15","2021-10-25")),
                   breaks=("4 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
      scale_y_continuous(limits=c(0,6),breaks=c(0,1,2,3),expand=c(0,0))+
      scale_color_manual(values=c("#a18f72","#723f39","#7f97bd"))+
      scale_fill_manual(values=c("#a18f72","#723f39","#7f97bd"))+
      labs(y ="Rt",x = NULL,title=unique(r$location))+
      guides(color=guide_legend(nrow=1,byrow=TRUE))+
      theme(legend.position = "",
            panel.grid.major = element_line(colour = "white"),
            panel.grid.minor = element_line(colour = "white"),
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_blank(),
            axis.title.y= element_blank(),
            axis.text.y = element_blank(),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    return(g)
  })
  for(i in 1:length(plot)){
    if(i%%4==1){
      plot[[i]]<-plot[[i]]+theme(axis.ticks.y=element_line(color="black"),
                                 axis.title.y= element_text(color="black",angle=90,size = unit(9, "pt")),
                                 axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")))}
    if(i>27){
      plot[[i]]<-plot[[i]]+theme(axis.title.x= element_text(color="black",size = unit(9, "pt")),
                                 axis.text.x = element_text(color="black",size = unit(9, "pt")))}
  }
  legend<-plot[[1]]+theme(legend.position = "bottom",
                          legend.title=element_blank(),
                          legend.text = element_text(size = unit(9, "pt")),
                          legend.key.height=unit(0.2,'cm'),
                          legend.key.width=unit(1,'cm'),
                          legend.background = element_rect(fill="transparent"),
                          legend.key=element_rect(fill="transparent"))
  mylegend<-g_legend(legend)
  plot<-grid.arrange(mylegend,arrangeGrob(grobs =plot,ncol =4,widths=c(2.8,2.5,2.5,2.5)),heights = c(0.5,10))
  ggsave(paste0("picture/R0_",outname,".pdf"),plot,units="mm",width=240,height=320,device = cairo_pdf)
  dev.off()
}
R0plot(DatasetV2,"1220R0V2")
########coefficient extract################
country_coefficient<-function(DatasetV2,path,outname,xname,outpath){
  DatasetV2$Date<-as.Date(DatasetV2$Date)
  efdata<-list()
  conlist<-list.files(path)
  condata<-lapply(conlist,function(c){
    DD<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    DD$Tem<-(DD$Tem-min(DD$Tem))/(max(DD$Tem)-min(DD$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(DD,DD$Date>=start&DD$Date<(end+1))
      X<-as.data.frame(do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      })))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="mean")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      return(pard)
    }))
    return(d)
  })
  c<-do.call(rbind,condata)
  write.csv(c,paste0(outpath,"/Country_cofficient_",outname,".csv"),row.names = F)
}
meta_coefficient<-function(DatasetV2,path,outname,xname,outpath){
  efdata<-list()
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$start),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(start=f$start[1],par="R0",
                  strength=NA,
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
    #air temperature
    sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
    si<-summary(sia)$random
    weight<-sia$w.random/sum(sia$w.random)
    t<-data.frame(start=f$start[1],par="Air Temperature",
                  strength=mean(f$strength_Tem),
                  m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight))
    #Epslion
    sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
    si<-summary(sie)$random
    weight<-sie$w.random/sum(sie$w.random)
    e<-data.frame(start=f$start[1],par="Epslion",
                  strength=1,
                  m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight))
    
    if(max(f$mean_SI)>0){
      ds<-subset(f,f$mean_SI>0)
      sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
      si<-summary(sim)$random
      weight<-sim$w.random/sum(sim$w.random)
      s<-data.frame(start=f$start[1],par="Stringency Index",
                    strength=mean(f$strength_SI),
                    m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight))
    }else{s<-NULL}
    if(is.null(f$mean_V)==F){
      if(max(f$mean_V)>0){
        dv<-subset(f,f$mean_V>0)
        vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        v<-data.frame(start=dv$start[1],par="Vaccination",
                      strength=mean(dv$strength_V),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{v<-NULL}
      if(max(f$median_Int)>0){
        dI<-subset(f,f$median_Int>0)
        vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab =  dI$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                      strength=mean(dI$strength_Int),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{i<-NULL}
      X<-do.call(rbind,list(r,t,e,s,v,i))
    }else{
      X<-do.call(rbind,list(r,t,e,s))
    }
    X$Rt<-mean(f$Rt)   #Rt
    return(X)
    print(paste0(unique(f$start),"has been processed"))
  }))
  write.csv(d1,paste0(outpath,"/Meta_coefficient_",outname,".csv"),row.names = F)
}
outpath<-"20220112_resultV2"
path<-"20200112_newR0V2/R0_calculate"
DatasetV2<-read.csv("20200112_newR0V2/Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
country_coefficient(DatasetV2,path,outname="20220112",
                   xname=c("StringencyIndex","Fully_vaccinated_pre","Interaction"),outpath)
meta_coefficient(DatasetV2,path,outname="20220112",
                  xname=c("StringencyIndex","Fully_vaccinated_pre","Interaction"),outpath)


################SI coefficient variation plot############

Coe<-read.csv(paste0(outpath,"/Country_cofficient_20220112.csv"),stringsAsFactors = F)
meta<-read.csv(paste0(outpath,"/Meta_coefficient_20220112.csv"),stringsAsFactors = F)
Coe$parameter[which(Coe$parameter=="StringencyIndex")]<-"Stringency Index"
Coe$parameter[which(Coe$parameter=="Fully_vaccinated_pre")]<-"Vaccination"
Coe$parameter[which(Coe$parameter=="Interaction")]<-"Interaction of SI and Vaccination"
Coe$m[which(Coe$strength==0)]<-0
meta$m[which(meta$strength==0)]<-0
concol<-c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7",
          "#777777", "#f6be6a", "#79add0", "#398367", "#d6ca67", "#4e88bf", "#af4f08", "#d68fb5",
          "#a2a2a2", "#fcce8f", "#b4d9f4", "#74bfa0", "#b9b182", "#769ecc", "#8a400d", "#e8bcd2",
          "#d0d0d0", "#fcce8f", "#e7f2fc", "#bbdfce", "#aaa58e", "#9ab6d9", "#67310e", "#b296a4")
fig<-lapply(split(Coe,Coe$parameter),function(k){
  m<-subset(meta,meta$par==unique(k$parameter))
  fig<-ggplot()+
    geom_line(data=k,aes(x=as.Date(start),y=m,color=country),size=0.2,alpha=0.4,linetype=2)+
    geom_line(data=m,aes(x=as.Date(start),y=m),color="grey20",size=0.5,alpha=0.7)+
    #geom_ribbon(data=m,aes(x=as.Date(start), ymin = lower, ymax = upper),fill="#cbd5ea", alpha = 0.3)+
    scale_color_manual(values=concol)+
    scale_x_date(limits=as.Date(c("2020-08-01","2021-10-01")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
    labs(y =paste("Coefficient of",tolower(unique(k$parameter))),x = NULL)+theme_light()+
    theme(legend.position = "none",
          legend.background = element_rect(fill=NA,color = NA),
          legend.key.size = unit(9, "pt"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.x= element_text(color="black",size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Coefficient_",unique(k$parameter),".pdf"),fig,
         units="mm",width=140,height=80,device = cairo_pdf)
  return(fig)
})
dev.off()
legend<-fig[[1]]+geom_line(data=k,aes(x=as.Date(start),y=m,color=country),size=0.35,alpha=1,linetype=2)+
  guides(color=guide_legend(nrow=7)) +
  theme(legend.position = "bottom")
mylegend<-g_legend(legend)
leg<-grid.arrange(mylegend)
ggsave(paste0(outpath,"/Coefficient_legend.pdf"),leg,
       units="mm",width=140,height=25,device = cairo_pdf)







####RSS and Rhat#########
path<-"20200112_newR0V2/R0_calculate/"
efdata<-list()
list<-list.files(path)
conresult<-do.call(rbind,lapply(list,function(l){
  f<-readRDS(paste0(path,l,"/all.rds"))
  rhat<-as.data.frame(rhat(f))
  Rneff<-as.data.frame(neff_ratio(f))
  dd<-do.call(cbind,list(rhat,Rneff))
  colnames(dd)<-c("rhat","R_ESS")
  return(dd)
}))

valplot<-list()
valplot[[1]]<-ggplot(conresult,aes(rhat))+
  geom_histogram(bins=100,colour="white",fill="#a23434",size=0.01)+
  labs(x=NULL,y=NULL,title="a")+
  scale_x_continuous(expand=c(0,0),limits=c(0.998,1.045))+
  scale_y_continuous(expand=c(0,0))+geom_vline(xintercept = 1,linetype ="dotdash",size=1)+
  theme(axis.line.y= element_blank(),
        axis.text.y = element_blank(),
        axis.text.x =element_text(size = unit(9, "pt")),
        axis.ticks.y = element_blank(),
        axis.title.y = element_blank(),
        legend.position = "none",
        plot.title=element_text(size = unit(9, "pt"),hjust=0),
        panel.grid=element_blank(),
        axis.line.x = element_line(colour = "black"),
        axis.ticks.x = element_line(colour = "black"),
        panel.background=element_rect(fill = "transparent",colour = NA),
        plot.margin=unit(c(0.1,0.2,0.1,0.2),"cm"),
        axis.text=element_text(size = unit(9, "pt")))
valplot[[2]]<-ggplot(conresult,aes(R_ESS))+
  geom_histogram(bins=100,colour="white",fill="#a23434",size=0.01)+
  labs(x=NULL,y=NULL,title="b")+scale_x_continuous(expand=c(0.02,0.02),limits=c(0,1.2))+
  scale_y_continuous(expand=(c(0,0)))+
  theme(axis.line.y= element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title.y = element_blank(),
        legend.position = "none",
        axis.text.x =element_text(size = unit(9, "pt")),
        plot.title=element_text(size =unit(9, "pt"),hjust=0),
        panel.grid=element_blank(),
        axis.line.x = element_line(colour = "black"),
        axis.ticks.x = element_line(colour = "black"),
        panel.background=element_rect(fill = "transparent",colour = NA),
        plot.margin=unit(c(0.1,0.2,0.1,0.2),"cm"),
        axis.text=element_text(size = unit(9, "pt")))
plot<-grid.arrange(arrangeGrob(grobs =valplot,ncol =2))
ggsave(paste0(outpath,"/mcmc_convergence.pdf"),plot,units="mm",width=140,height=50,device = cairo_pdf)
ggsave(paste0(outpath,"/mcmc_convergence.png"),plot,units="mm",width=140,height=50)


#############Correlation analysis##########
N<-DatasetV2[,c("R0","Rt","StringencyIndex","Fully_vaccinated_effect","Interaction","Tem","Hum")]
colnames(N)<-c("R0","R0,t","Stringency index","Pratical vaccination rate","Interaction of SI and vaccination","Temperature","Humidity")
cor<-COR(N)
ggsave(paste0("picture/correlation_analysis.pdf"),cor,width=140,height=160,units="mm",device = cairo_pdf)
ggsave(paste0("picture/correlation_analysis.png"),cor,width=140,height=160,units="mm")

###########################################


