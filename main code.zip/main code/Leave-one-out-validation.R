###Leave one out validation###
library("rstan")
library("bayesplot")
library("zoo")
library("dplyr")
library("reshape2")
library("scales")
library("ggridges")
library("ggthemr")
library("ggcor")
library("ggplot2")
library("gridExtra")
library("ggalt")
library("aomisc")
library("meta")
library("grid")
library("Hmisc")
library("caret")

setwd("E:/COVID19_vacciantion1210")#set up your setwd here
Sys.setlocale("LC_TIME","English")
R2<-function(x,y){
  xm<-mean(x)
  ssres<-sum((x-xm)^2)
  ssreg<-sum((y-x)^2)
  return(ssreg/(ssres+ssreg))
}
###########meta leave one out validation##############

meta_validation<-function(DatasetV2,path,outname,xname,outpath){
  efdata<-list()
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  countrylist<-unique(eachC$country)
  rt<-do.call(rbind,lapply(countrylist,function(i){
    ee<-subset(eachC,eachC$country!=i)
    d1<-do.call(rbind,lapply(split(ee,ee$start),function(f){
      #R0
      sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
      si<-summary(sir)$random
      weight<-sir$w.random/sum(sir$w.random)
      r<-data.frame(start=f$start[1],par="R0",
                    strength=NA,
                    m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
      #air temperature
      sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
      si<-summary(sia)$random
      weight<-sia$w.random/sum(sia$w.random)
      t<-data.frame(start=f$start[1],par="Air Temperature",
                    strength=mean(f$strength_Tem),
                    m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight))
      #Epslion
      sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
      si<-summary(sie)$random
      weight<-sie$w.random/sum(sie$w.random)
      e<-data.frame(start=f$start[1],par="Epslion",
                    strength=1,
                    m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight))
      
      if(max(f$mean_SI)>0){
        ds<-subset(f,f$mean_SI>0)
        sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
        si<-summary(sim)$random
        weight<-sim$w.random/sum(sim$w.random)
        s<-data.frame(start=f$start[1],par="Stringency Index",
                      strength=mean(f$strength_SI),
                      m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight))
      }else{s<-NULL}
      if(is.null(f$mean_V)==F){
        if(max(f$mean_V)>0){
          dv<-subset(f,f$mean_V>0)
          vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
          va<-summary(vm)$random
          weight<-vm$w.random/sum(vm$w.random)
          v<-data.frame(start=dv$start[1],par="Vaccination",
                        strength=mean(dv$strength_V),
                        m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
        }else{v<-NULL}
        if(max(f$median_Int)>0){
          dI<-subset(f,f$median_Int>0)
          vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab =  dI$country)
          va<-summary(vm)$random
          weight<-vm$w.random/sum(vm$w.random)
          i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                        strength=mean(dI$strength_Int),
                        m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
        }else{i<-NULL}
        X<-do.call(rbind,list(r,t,e,s,v,i))
      }else{
        X<-do.call(rbind,list(r,t,e,s))
      }
      X$Rt<-mean(f$Rt)   #Rt
      return(X)
      print(paste0(unique(f$start),"has been processed"))
    }))
    Rtpre<-do.call(rbind,lapply(split(d1,d1$start),function(t){
      d<-subset(DatasetV2,DatasetV2$location==i)
      d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
      coun<-subset(d,d$Date>=t$start[1]&d$Date<(t$start[1]+30))
      r0<-coun$R0
      SI<-coun$StringencyIndex*t$m[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vac<-coun$Fully_vaccinated_effect*t$m[which(t$par=="Vaccination")]
        Int<-coun$Interaction*t$m[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vac<-coun$Fully_vaccinated_effect
        Int<-coun$Interaction
      }
      Tem<-coun$Tem*t$m[which(t$par=="Air Temperature")]
      e<-t$m[which(t$par=="Epslion")]
      a<-SI+Vac+Int+Tem+e
      rt<-exp(-a)*r0
      
      SIupper<-coun$StringencyIndex*t$upper[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vacupper<-coun$Fully_vaccinated_effect*t$upper[which(t$par=="Vaccination")]
        Intupper<-coun$Interaction*t$upper[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vacupper<-coun$Fully_vaccinated_effect
        Intupper<-coun$Interaction
      }
      Temupper<-coun$Tem*t$upper[which(t$par=="Air Temperature")]
      eupper<-t$upper[which(t$par=="Epslion")]
      aupper<-SIupper+Vacupper+Intupper+Temupper+eupper
      
      SIlower<-coun$StringencyIndex*t$lower[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vaclower<-coun$Fully_vaccinated_effect*t$lower[which(t$par=="Vaccination")]
        Intlower<-coun$Interaction*t$lower[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vaclower<-coun$Fully_vaccinated_effect
        Intlower<-coun$Interaction
      }
      Temlower<-coun$Tem*t$lower[which(t$par=="Air Temperature")]
      elower<-t$lower[which(t$par=="Epslion")]
      alower<-SIlower+Vaclower+Intlower+Temlower+elower
      
      rt_low<-exp(-alower)*r0
      rt_high<-exp(-aupper)*r0
      p<-data.frame("Rt"=coun$Rt,"Rt_pre"=rt,"Rt_pre_low"=rt_low,"Rt_pre_high"=rt_high,"Date"=coun$Date)
      return(p)
    }))
    meltr<-melt(Rtpre[,c("Rt","Rt_pre","Date")],id="Date")
    ggthemr('fresh')
    c<-as.data.frame(t(caret::postResample(Rtpre$Rt, Rtpre$Rt_pre)))
    c$R2N<-R2(Rtpre$Rt, Rtpre$Rt_pre)
    rtfig<-ggplot()+
      geom_ribbon(data=Rtpre,aes(x=as.Date(Date),ymin=Rt_pre_low,ymax=Rt_pre_high),fill="grey93",alpha=0.7)+
      geom_point(data=meltr,aes(x=as.Date(Date),y=value,color=variable),alpha=0.5,size=0.3)+
      geom_xspline(data=meltr,aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      scale_color_manual(values=c("#643d20","#5686bf"))+
      annotate("text",as.Date("2020-09-01"),max(meltr$value)-0.011,parse = TRUE,label="R^2",size=3.4)+
      annotate("text",as.Date("2020-09-01")+45,max(meltr$value)-0.015,label=paste("=",round(c$R2N,2)),size=3.4)+
      annotate("text",as.Date("2020-09-01")+170,max(meltr$value)-0.012,label=paste0("RMSE = ",round(c$RMSE,2)),size=3.4)+
      labs(y =expression(R[t]),x = NULL,title=i)+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    pofig<-ggplot(Rtpre,aes(x=Rt,y=Rt_pre))+geom_point(alpha=0.3)+
      labs(y =expression("Prediction of "*R[t]),x = expression(R[t]),title=i)+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    ggsave(paste0(outpath,"/validation/LeaveOneOut_",i,".pdf"),rtfig,units="mm",width=75,height=60,device = cairo_pdf)
    ggsave(paste0(outpath,"/validation/Point_",i,".pdf"),pofig,units="mm",width=75,height=60,device = cairo_pdf)
    ggsave(paste0(outpath,"/validation/LeaveOneOut_",i,".png"),rtfig,units="mm",width=75,height=60)
    ggsave(paste0(outpath,"/validation/Point_",i,".png"),pofig,units="mm",width=75,height=60)
    Rtpre$validation<-i
    write.csv(d1,paste0(outpath,"/Meta_coefficient_without_",i,".csv"),row.names = F)
    return(Rtpre)
  }))
  pofig<-ggplot(rt,aes(x=Rt,y=Rt_pre))+geom_point(alpha=0.3,size=0.6,color="#008080")+
    labs(y =expression("Prediction of "*R[t]),x = expression(R[t]))+
    scale_y_continuous(limits=c(0,2),breaks=c(0,0.5,1,1.5),expand=c(0,0))+
    scale_x_continuous(limits=c(0,2.5),breaks=c(0,0.5,1,1.5,2),expand=c(0,0))+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
          axis.title.y= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.title.x= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/validation/ALL_Point.pdf"),pofig,units="mm",width=140,height=140,device = cairo_pdf)
  ggsave(paste0(outpath,"/validation/ALL_Point.png"),pofig,units="mm",width=140,height=140)
  val<-do.call(rbind,lapply(split(rt,rt$validation),function(k){
    c<-as.data.frame(t(caret::postResample(k$Rt, k$Rt_pre)))
    c$R2N<-R2(k$Rt, k$Rt_pre)
    c$val<-k$validation[1]
    c$vaccination<-max(DatasetV2$Fully_vaccinated_pre[which(DatasetV2$location==k$validation[1])])
    c$location<-k$validation[1]
    return(c)
  }))
  write.csv(val,paste0(outpath,"/RMSE_R2.csv"),row.names = F)
  print(summary(val))
  print(R2(rt$Rt, rt$Rt_pre))
}
######################################################
path<-"20200112_newR0V2/R0_calculate"
DatasetV2<-read.csv("20200112_newR0V2/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")
meta_validation(DatasetV2,path,outname,xname,outpath="20220112_resultV2")
###########population leave one out validation##############
pop_validation<-function(DatasetV2,path,outname,xname,outpath){
  conlist<-list.files(path)
  rt<-do.call(rbind,lapply(conlist,function(c){
    vadc<-strsplit(strsplit(c,"_")[[1]][3],".rds")[[1]][1]
    vadd<-subset(DatasetV2,DatasetV2$location==vadc)
    vadd$Tem<-(vadd$Tem-min(vadd$Tem))/(max(vadd$Tem)-min(vadd$Tem))
    fit<-readRDS(paste0(path,"/",c))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    Rtpre<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      
      coun<-subset(vadd,vadd$Date>=start&vadd$Date<end)
      r0<-coun$R0
      SI<-coun$StringencyIndex*pard$m[which(pard$parameter=="StringencyIndex")]
      Vac<-coun$Fully_vaccinated_effect*pard$m[which(pard$parameter=="Fully_vaccinated_effect")]
      Int<-coun$Interaction*pard$m[which(pard$parameter=="Interaction")]
      Tem<-coun$Tem*pard$m[which(pard$parameter=="Air Temperature")]
      e<-pard$m[which(pard$parameter=="Epslion")]
      a<-SI+Vac+Int+Tem+e
      rt<-exp(-a)*r0
      
      SIupper<-coun$StringencyIndex*pard$hh[which(pard$parameter=="StringencyIndex")]
      if (nrow(pard)>3){
        Vacupper<-coun$Fully_vaccinated_effect*pard$hh[which(pard$parameter=="Fully_vaccinated_effect")]
        Intupper<-coun$Interaction*pard$hh[which(pard$parameter=="Interaction")]
      }else{
        Vacupper<-coun$Fully_vaccinated_effect
        Intupper<-coun$Interaction
      }
      Temupper<-coun$Tem*pard$hh[which(pard$parameter=="Air Temperature")]
      eupper<-pard$hh[which(pard$parameter=="Epslion")]
      aupper<-SIupper+Vacupper+Intupper+Temupper+eupper
      
      SIlower<-coun$StringencyIndex*pard$ll[which(pard$parameter=="StringencyIndex")]
      if (nrow(pard)>3){
        Vaclower<-coun$Fully_vaccinated_effect*pard$ll[which(pard$parameter=="Fully_vaccinated_effect")]
        Intlower<-coun$Interaction*pard$ll[which(pard$parameter=="Interaction")]
      }else{
        Vaclower<-coun$Fully_vaccinated_effect
        Intlower<-coun$Interaction
      }
      Temlower<-coun$Tem*pard$ll[which(pard$parameter=="Air Temperature")]
      elower<-pard$ll[which(pard$parameter=="Epslion")]
      alower<-SIlower+Vaclower+Intlower+Temlower+elower
      
      rt_low<-exp(-alower)*r0
      rt_high<-exp(-aupper)*r0
      p<-data.frame("Rt"=coun$Rt,"Rt_pre"=rt,"Rt_pre_low"=rt_high,"Rt_pre_high"=rt_low,"Date"=coun$Date)
      return(p)
    }))
    meltr<-melt(Rtpre[,c("Rt","Rt_pre","Date")],id="Date")
    ggthemr('fresh')
    c<-as.data.frame(t(caret::postResample(Rtpre$Rt, Rtpre$Rt_pre)))
    c$R2N<-R2(Rtpre$Rt, Rtpre$Rt_pre)
    rtfig<-ggplot()+
      geom_ribbon(data=Rtpre,aes(x=as.Date(Date),ymin=Rt_pre_low,ymax=Rt_pre_high),fill="grey93",alpha=0.7)+
      geom_point(data=meltr,aes(x=as.Date(Date),y=value,color=variable),alpha=0.5,size=0.3)+
      geom_xspline(data=meltr,aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      scale_color_manual(values=c("#643d20","#5686bf"))+
      annotate("text",as.Date("2020-09-01"),max(meltr$value)-0.011,parse = TRUE,label="R^2",size=3.4)+
      annotate("text",as.Date("2020-09-01")+45,max(meltr$value)-0.015,label=paste("=",round(c$R2N,2)),size=3.4)+
      annotate("text",as.Date("2020-09-01")+170,max(meltr$value)-0.012,label=paste0("RMSE = ",round(c$RMSE,2)),size=3.4)+
      labs(y =expression(R[t]),x = NULL,title=vadc)+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    ggsave(paste0(outpath,"/pop_validation/LeaveOneOut_",vadc,".pdf"),rtfig,units="mm",width=75,height=60,device = cairo_pdf)
    ggsave(paste0(outpath,"/pop_validation/LeaveOneOut_",vadc,".png"),rtfig,units="mm",width=75,height=60)
    Rtpre$vadc<-vadc
    return(Rtpre)
  }))
  pofig<-ggplot(rt,aes(x=Rt,y=Rt_pre))+geom_point(alpha=0.3,size=0.6,color="#008080")+
    labs(y =expression("Prediction of "*R[t]),x = expression(R[t]))+
    scale_y_continuous(limits=c(0,2),breaks=c(0,0.5,1,1.5),expand=c(0,0))+
    scale_x_continuous(limits=c(0,2.5),breaks=c(0,0.5,1,1.5,2),expand=c(0,0))+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
          axis.title.y= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.title.x= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/pop_validation/ALL_Point_pop.pdf"),pofig,units="mm",width=140,height=140,device = cairo_pdf)
  ggsave(paste0(outpath,"/pop_validation/ALL_Point_pop.png"),pofig,units="mm",width=140,height=140)
  val<-do.call(rbind,lapply(split(rt,rt$vadc),function(k){
    c<-as.data.frame(t(caret::postResample(k$Rt, k$Rt_pre)))
    c$val<-k$vadc[1]
    c$R2N<-R2(k$Rt, k$Rt_pre)
    c$vaccination<-max(DatasetV2$Fully_vaccinated_pre[which(DatasetV2$location==k$vadc[1])])
    return(c)
  }))
  write.csv(val,paste0(outpath,"/pop_RMSE_R2.csv"),row.names = F)
  print(summary(val))
  print(R2(rt$Rt, rt$Rt_pre))
}
path<-"20220112_newR0_validation"
DatasetV2<-read.csv("20200112_newR0V2/R0pop_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")
outpath<-"20220112_resultV2"
pop_validation(DatasetV2,path,outname,xname,outpath)
#############meta forest plot#############



forest(vm,family="sans",fontsize=9,lwd=2,
       col.diamond.fixed="lightslategray",
       col.diamond.line.fixed="lightslategray",
       col.diamond.random = "maroon",col.diamond.lines.random = "maroon",
       col.square = "#b2b4c6",col.study = "lightslategray")

forest(metainf(vm, pooled="random"),family="sans",fontsize=9,lwd=2,
       col.diamond.fixed="lightslategray",
       col.diamond.line.fixed="lightslategray",
       col.diamond.random = "maroon",col.diamond.lines.random = "maroon",
       col.square = "#b2b4c6",col.study = "lightslategray")
##########Rt pre with priori###############
path="20200112_newR0V2/R0_calculate"
DatasetV2<-read.csv("20200112_newR0V2/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
xname=c("StringencyIndex","Fully_vaccinated_pre","Interaction")
outname<-"Prior&posterior_predictive_check"
outpath="20220112_resultV2"
piror<-function(DatasetV2,path,outname,xname){
  countryname<-c("France","Israel","Bulgaria","Croatia")
  countrycoff<-read.csv(paste0(outpath,"/Country_cofficient_20220112.csv"),stringsAsFactors = F)
  rt<-do.call(rbind,lapply(countryname,function(i){
    ee<-subset(countrycoff,countrycoff$country==i)
    ee$start<-as.Date(ee$start)
    Rtpre<-do.call(rbind,lapply(split(ee,ee$start),function(t){
      u<-runif(100,0,1)
      u<-mean(u[which(u>0)])
      alpha<-rgamma(3,u,1)
      beta<-rnorm(1,0,0.5)
      eli<-rnorm(1,0,0.5)
      d<-subset(DatasetV2,DatasetV2$location==i)
      d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
      coun<-subset(d,d$Date>=t$start[1]&d$Date<(t$start[1]+30))
      r0<-coun$R0
      SI<-coun$StringencyIndex*alpha[1]
      if (nrow(t)>3){
        Vac<-coun$Fully_vaccinated_pre*alpha[2]
        Int<-coun$Interaction*alpha[3]
      }else{
        Vac<-coun$Fully_vaccinated_pre
        Int<-coun$Interaction
      }
      Tem<-coun$Tem*beta
      e<-eli
      a<-SI+Vac+Int+Tem+e
      rt<-exp(-a)*r0
      p<-data.frame("Rt"=coun$Rt,"Priori"=rt,"Date"=coun$Date)
      SIp<-coun$StringencyIndex*t$m[which(t$parameter=="StringencyIndex")]
      if (nrow(t)>3){
        Vacp<-coun$Fully_vaccinated_pre*t$m[which(t$parameter=="Fully_vaccinated_pre")]
        Intp<-coun$Interaction*t$m[which(t$parameter=="Interaction")]
      }else{
        Vacp<-coun$Fully_vaccinated_pre
        Intp<-coun$Interaction
      }
      Temp<-coun$Tem*t$m[which(t$parameter=="Air Temperature")]
      ep<-t$m[which(t$parameter=="Epslion")]
      ap<-SIp+Vacp+Intp+Temp+ep
      p$Posterior<-exp(-ap)*r0
      
      return(p)
    }))
    meltr<-melt(Rtpre,id="Date")
    ggthemr('fresh')
    c1<-as.data.frame(t(caret::postResample(Rtpre$Rt, Rtpre$Priori)))
    c2<-as.data.frame(t(caret::postResample(Rtpre$Rt, Rtpre$Posterior)))
    print(do.call(rbind,list(c1,c2)))
    rtfig<-ggplot(data=meltr)+
      geom_point(aes(x=as.Date(Date),y=value,color=variable),alpha=0.2,size=0.4)+
      geom_xspline(aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      scale_color_manual(values=c("#896e6d","#e3a12b","#808000"))+
      annotate("text",as.Date("2021-02-01"),max(meltr$value)-0.011,parse = TRUE,label="Pirori:R^2",size=2.5)+
      annotate("text",as.Date("2021-02-01")+50,max(meltr$value)-0.015,label=paste("=",round(c1$Rsquared,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01")+150,max(meltr$value)-0.012,label=paste0("RMSE = ",round(c1$RMSE,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01"),max(meltr$value)-0.2,parse = TRUE,label="Posterior:R^2",size=2.5)+
      annotate("text",as.Date("2021-02-01")+70,max(meltr$value)-0.215,label=paste("=",round(c2$Rsquared,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01")+150,max(meltr$value)-0.212,label=paste0("RMSE = ",round(c2$RMSE,2)),size=2.5)+
      labs(y =expression(R[t]),x = NULL,title=i)+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    ggsave(paste0(outpath,"/validation/Piror&Posterior_",i,".pdf"),rtfig,units="mm",width=75,height=60,device = cairo_pdf)
    
  }))
  dev.off()
}
