####sensitivity analysis############
library("rstan")
library("bayesplot")
library("zoo")
library("dplyr")
library("reshape2")
library("scales")
library("ggridges")
library("ggthemes")
library("ggcor")
library("ggplot2")
library("gridExtra")
library("ggalt")
library("aomisc")
library("meta")
library("RColorBrewer")
library("grid")
library("Hmisc")
library("ggthemr")
library("caret")
setwd("E:/COVID19_vacciantion1210")#set up your setwd here
Sys.setlocale("LC_TIME","English")
source('code/main.R')
source('code/rstanmain.R')
RT<-read.csv("Dataset/owid-covid-data.csv")# Daily reproduction rate data (Rt)
Variants<-read.csv("Dataset/covid-variants.csv")# Weekly variant structure data
NPI<-"Dataset/OxCGRT_latest.csv" # Daily non-pharmaceutical interventions data (NPI)
POP<-"Dataset/pop_data_age_by_country.csv" # Total population number of each country
index<-'Dataset/index.csv'# Control variables, contained population density, age structre and health index of each country
Env<-'Dataset/20200120-20211201humidity&airtem.csv'# Control variables, contained temperature and humidity. Only air temperature were considered in our study
Vaccination<-'Dataset/vaccinations.csv' # Daily vaccination data 
Vaccman<-'Dataset/vaccinations-by-manufacturer.csv'# Weekly vaccination manufacturer structure
agedata<-"Dataset/pop_structure_data.csv"
school_holiday<-"Dataset/day_public_and_school_holidays_2010_2019.csv"
vaccine_effect<-"Dataset/vaccine_effectiveness_V1.csv"
variant_tran<-"Dataset/variant_transmission.csv"# 

###############for R0 prior value#############
r0<-read.csv("Dataset/R0_for_each_country.csv",stringsAsFactors = F)
R0calculateSE<-function(DatasetV2,source,mcon,xname,monthnum,r0){
  if (dir.exists(source)==F){dir.create(source)
  }else{print("This path has been exists")}
  lapply(split(DatasetV2,DatasetV2$iso_code),FUN=function(v){
    out<-paste0(source,unique(v$location),"_withinR0/")
    if (dir.exists(out)==F){dir.create(out)
    }else{print("This path has been exists")}
    output<-paste0(out,"all.rds")
    start<-as.Date("2020-08-01")
    end<-as.Date("2021-10-26")
    fit<-alpha_calculate_SEforR0(mcon,v,start,r0,end,output,xname,monthnum)
    gc()
    print(paste0(unique(v$location),start,"has been processed"))
  })
}

R0process<-function(RT,Variants,Vaccination,NPI,POP,index,Env,
                    vaccine_effect,variant_tran,i,outpath,
                    mcon,xname,monthnum,r0){
  Dataset<-merge_dataset(RT,Variants,Vaccination,NPI,POP,index,Env)
  Dataset<-subset(Dataset,Dataset$continent=="Europe"|Dataset$location=="Israel")
  gc()
  DatasetV2<-RatioVariable_merge(Dataset,vaccine_effect,variant_tran,list=c(1:length(unique(Dataset$location))))
  if (length(xname)>2){
    DatasetV2$Interaction<-DatasetV2[,xname[1]]*DatasetV2[,xname[2]]
  }
  write.csv(DatasetV2,paste0(outpath,"/Europe_dataset_1220withinR0.csv"),row.names = F)
  R0calculateSE(DatasetV2,source=paste0(outpath,"/R0_calculate/"),mcon,xname,monthnum,r0)
}
R0extract<-function(path){
  conlist<-list.files(path)
  datapath<-list.files(strsplit(path,"/")[[1]][1],".csv")
  Da<-read.csv(paste0(strsplit(path,"/")[[1]][1],"/",datapath),stringsAsFactors = F)
  condata<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(Da,Da$location==strsplit(c,"_")[[1]][1])
    k<-subset(k,k$Date>="2020-08-01"&k$Date<"2021-10-26")
    f<-readRDS(paste0(path,"/",c,"/all.rds"))
    R0<-as.data.frame(rstan::extract(f)$R0)
    colnames(R0)<-k$Date
    R0d<-mcmc_intervals_data(R0,prob = .5,prob_outer= .95,point_est="mean")
    k<-k[order(k$Date),]
    R0d<-R0d[order(R0d$parameter),]
    k$R0<-R0d$m
    k$R0_CI95low<-R0d$ll
    k$R0_CI95high<-R0d$hh
    k$R0_sd<-apply(R0,2,sd)
    return(k)
  }))
  write.csv(condata,paste0(strsplit(path,"/")[[1]][1],"/R0_",datapath))
  return(condata)
}

lapply(seq(1,2),function(k){
  r0s<-r0[,c(1,k+2)]
  outpath<-paste0("20200112_newR0V2_r0S",k)
  if (dir.exists(outpath)==F){dir.create(outpath)
  }else{print("This path has been exists")}
  R0process(RT,Variants,Vaccination,NPI,POP,index,Env,
            vaccine_effect,variant_tran,i,outpath,
            mcon=stan_model('stan_R0_withinModel_lastV2.stan'),
            xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),monthnum=15,r0s)
  R0extract(paste0("20200112_newR0V2_r0S",k,"/R0_calculate"))
})

######for Rt distribution#######
R0calculate_withineachcountry<-function(DatasetV2,source,mcon,xname,monthnum){
  if (dir.exists(source)==F){dir.create(source)
  }else{print("This path has been exists")}
  lapply(split(DatasetV2,DatasetV2$iso_code),FUN=function(v){
    out<-paste0(source,unique(v$location),"_withinR0/")
    if (dir.exists(out)==F){dir.create(out)
    }else{print("This path has been exists")}
    output<-paste0(out,"all.rds")
    start<-as.Date("2020-08-01")
    end<-as.Date("2021-10-26")
    fit<-alpha_calculate_withinR0_con(mcon,v,start,end,output,xname,monthnum)
    gc()
    print(paste0(unique(v$location),start,"has been processed"))
  })
}
R0process<-function(RT,Variants,Vaccination,NPI,POP,index,Env,
                    vaccine_effect,variant_tran,i,outpath,
                    mcon,xname,monthnum){
  Dataset<-merge_dataset(RT,Variants,Vaccination,NPI,POP,index,Env)
  Dataset<-subset(Dataset,Dataset$continent=="Europe"|Dataset$location=="Israel")
  gc()
  DatasetV2<-RatioVariable_merge(Dataset,vaccine_effect,variant_tran,list=c(1:length(unique(Dataset$location))))
  if (length(xname)>2){
    DatasetV2$Interaction<-DatasetV2[,xname[1]]*DatasetV2[,xname[2]]
  }
  write.csv(DatasetV2,paste0(outpath,"/Europe_dataset_1220withinR0.csv"),row.names = F)
  R0calculate_withineachcountry(DatasetV2,source=paste0(outpath,"/R0_calculate/"),mcon,xname,monthnum)
}
R0extract<-function(path){
  conlist<-list.files(path)
  datapath<-list.files(strsplit(path,"/")[[1]][1],".csv")
  Da<-read.csv(paste0(strsplit(path,"/")[[1]][1],"/",datapath),stringsAsFactors = F)
  condata<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(Da,Da$location==strsplit(c,"_")[[1]][1])
    k<-subset(k,k$Date>="2020-08-01"&k$Date<"2021-10-26")
    f<-readRDS(paste0(path,"/",c,"/all.rds"))
    R0<-as.data.frame(rstan::extract(f)$R0)
    colnames(R0)<-k$Date
    R0d<-mcmc_intervals_data(R0,prob = .5,prob_outer= .95,point_est="mean")
    k<-k[order(k$Date),]
    R0d<-R0d[order(R0d$parameter),]
    k$R0<-R0d$m
    k$R0_CI95low<-R0d$ll
    k$R0_CI95high<-R0d$hh
    k$R0_sd<-apply(R0,2,sd)
    return(k)
  }))
  write.csv(condata,paste0(strsplit(path,"/")[[1]][1],"/R0_",datapath))
  return(condata)
}

lapply(list("normal","weibull"),function(d){
  outpath<-paste0("20200112_newR0V2_Rtof",d)
  if (dir.exists(outpath)==F){dir.create(outpath)
  }else{print("This path has been exists")}
  R0process(RT,Variants,Vaccination,NPI,POP,index,Env,
            vaccine_effect,variant_tran,i,outpath,
            mcon=stan_model(paste0('stan_R0_withinModel_lastV2_',d,'.stan')),
            xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),monthnum=15)
  DatasetV2<-R0extract(paste0("20200112_newR0V2_Rtof",d,"/R0_calculate"))
})

################of var value#########

lapply(list("0.3","0.7"),function(d){
  outpath<-paste0("20200112_newR0V2_Varof",d)
  if (dir.exists(outpath)==F){dir.create(outpath)
  }else{print("This path has been exists")}
  R0process(RT,Variants,Vaccination,NPI,POP,index,Env,
            vaccine_effect,variant_tran,i,outpath,
            mcon=stan_model(paste0('stan_R0_withinModel_lastV2_',d,'.stan')),
            xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),monthnum=15)
  DatasetV2<-R0extract(paste0("20200112_newR0V2_Varof",d,"/R0_calculate"))
})


############
counresultplot<-function(DatasetV2,path,outname,xname,outpath){
  DatasetV2$Date<-as.Date(DatasetV2$Date)
  efdata<-list()
  conlist<-list.files(path)
  condata<-lapply(conlist,function(c){
    DD<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    DD$Tem<-(DD$Tem-min(DD$Tem))/(max(DD$Tem)-min(DD$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(DD,DD$Date>=start&DD$Date<(end+1))
      X<-as.data.frame(do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      })))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      for (k in c(xname,"Air Temperature","Epslion")){
        pars[,k]<- pars[,k]*X[,k]}
      pars$all_SI<-pars$StringencyIndex+pars$Interaction
      pars$all_V<-pars$Fully_vaccinated_effect+pars$Interaction
      #write.csv(pars,paste0("sensitivity_analysis/",outname,"_",c,"_",start,".csv"),row.names = F)
      pars$all<-apply(pars,1,sum)
      pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
      pars<-(1-exp(-pars))*100
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="mean")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      pard$strength[which(pard$parameter=="all_SI")]<-X[,"StringencyIndex"]
      pard$strength[which(pard$parameter=="all_V")]<-X[,"Fully_vaccinated_effect"]
      return(pard)
    }))
    return(d)
  })
  c<-do.call(rbind,condata)
  write.csv(c,paste0(outpath,"/SI_country_",outname,".csv"),row.names = F)
}
meta_R0<-function(DatasetV2,path,outname,outpath){
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    d<-do.call(rbind,lapply(split(k,k$Date),function(i){
      data<-data.frame(n=1,sd_R0=i$R0_sd,mean_R0=i$R0,
                       q1_R0=i$R0_CI95low,q3_R0=i$R0_CI95high,
                       country=strsplit(c,"_")[[1]][1],Date=unique(i$Date),
                       Rt=i$Rt)
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$Date),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(Date=unique(f$Date),par="R0",
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
    r$Rt<-mean(f$Rt)   #Rt
    return(r)
    print(paste0(unique(f$Date),"has been processed"))
  }))
  write.csv(d1,paste0(outpath,"/R0_meta_",outname,".csv"),row.names = F)
}
meta_alalysis<-function(DatasetV2,path,outname,xname,outpath){
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      for (k in c(xname,"Air Temperature","Epslion")){
        pars[,k]<- pars[,k]*X[,k]}
      pars$all<-apply(pars,1,sum)
      pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
      pars<-(1-exp(-pars))*100
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       min_SI=min(pars[,xname[1]]),max_SI=max(pars[,xname[1]]),
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       min_Int=min(pars[,xname[3]]),max_Int=max(pars[,xname[3]]),
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       min_V=min(pars[,xname[2]]),max_V=max(pars[,xname[2]]),
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       min_Tem=min(pars[,"Air Temperature"]),max_Tem=max(pars[,"Air Temperature"]),
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       min_Eli=min(pars[,"Epslion"]),max_Eli=max(pars[,"Epslion"]),
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$start),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(start=f$start[1],par="R0",
                  strength=NA,
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight),
                  min=NA,max=NA)
    #air temperature
    sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
    si<-summary(sia)$random
    weight<-sia$w.random/sum(sia$w.random)
    t<-data.frame(start=f$start[1],par="Air Temperature",
                  strength=mean(f$strength_Tem),
                  m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight),
                  min=sum(f$min_Tem*weight),max=sum(f$max_Tem*weight))
    #Epslion
    sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
    si<-summary(sie)$random
    weight<-sie$w.random/sum(sie$w.random)
    e<-data.frame(start=f$start[1],par="Epslion",
                  strength=1,
                  m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight),
                  min=sum(f$min_Eli*weight),max=sum(f$max_Eli*weight))
    
    if(max(f$median_SI)>0){
      ds<-subset(f,f$mean_SI>0)
      sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
      si<-summary(sim)$random
      weight<-sim$w.random/sum(sim$w.random)
      s<-data.frame(start=f$start[1],par="Stringency Index",
                    strength=mean(f$strength_SI),
                    m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight),
                    min=sum(f$min_SI*weight),max=sum(f$max_SI*weight))
    }else{s<-NULL}
    if(is.null(f$mean_V)==F){
      if(max(f$mean_V)>0){
        dv<-subset(f,f$mean_V>0)
        vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        v<-data.frame(start=dv$start[1],par="Vaccination",
                      strength=mean(dv$strength_V),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight),
                      min=sum(f$min_V*weight),max=sum(f$max_V*weight))
      }else{v<-NULL}
      if(max(f$median_Int)>0){
        dI<-subset(f,f$median_Int>0)
        vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab=dI$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                      strength=mean(dI$strength_Int),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight),
                      min=sum(f$min_Int*weight),max=sum(f$max_Int*weight))
      }else{i<-NULL}
      X<-do.call(rbind,list(r,t,e,s,v,i))
    }else{
      X<-do.call(rbind,list(r,t,e,s))
    }
    X$Rt<-mean(f$Rt)   #Rt
    return(X)
    print(paste0(unique(f$start),"has been processed"))
  }))
  write.csv(d1,paste0(outpath,"/Meta_",outname,".csv"),row.names = F)
}

xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")
path="20200112_newR0V2_Varof0.7/R0_calculate"
outpath<-"20200112_sensitivityResult"
outname="Sensitivity_anlaysis_Varof0.7"
if (dir.exists(outpath)==F){dir.create(outpath)
}else{print("This path has been exists")}
Da<-read.csv(paste0(strsplit(path,"/")[[1]][1],"/R0_Europe_dataset_1220withinR0.csv"),stringsAsFactors = F)
meta_alalysis(Da,path,outname,xname,outpath)
counresultplot(Da,path,outname,xname,outpath)
meta_R0(Da,path,outname,outpath)

########fig plot########
var<-c("DS","r0S1","r0S2","Rtofnormal","Rtofweibull","Varof0.3","Varof0.7")
par<-c("Stringency Index","Vaccination","Interaction of SI and Vaccination","Air Temperature","Epslion")
d<-do.call(rbind,lapply(var,function(vr){
  med<-read.csv(paste0(outpath,"/Meta_Sensitivity_anlaysis_",vr,".csv"))
  med$SE<-vr
  return(med)
}))
fd<-do.call(rbind,lapply(par,function(p){
  subd<-subset(d,d$par==p)
  subd$start1<-substring(subd$start,1,7)
  ggthemr('flat')
  g<-ggplot(subd)+
    geom_linerange(mapping = aes_(x=~start,ymin =~lower, ymax=~upper ,color= ~SE),show.legend = T,
                   size =1,position=position_dodge(width = 0.8))+
    geom_point(mapping = aes_(x=~start, y = ~m,color= ~SE),show.legend = T,fill="white",shape=21,
               size =1,position= position_dodge(width = 0.8))+
    scale_color_manual(values=c("#7E6148B2","#DC0000B2","#F39B7FB2","#00A087B2","#91D1C2B2","#3C5488B2","#8491B4B2"))+
    scale_y_continuous(limits=c(-50,50),breaks=c(-50,-25,0,25,50,75,100),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=1,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"))
  ggsave(paste0(outpath,"/SE_",p,".pdf"),g,units="mm",width=140,height=90,device = cairo_pdf)
  return(subd)
}))
