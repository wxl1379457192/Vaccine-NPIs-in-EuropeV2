library("ggplot2")
###########fig 1 a_1#############
DatasetV2<-read.csv("1220R0V2/Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
D<-subset(DatasetV2,DatasetV2$Date>="2020-08-01")
D<-D[,c("Date","iso_code","New_cases_smoothed")]
D$id<-1:nrow(D)
angle<-90-360*(D$id-0.5)/nrow(D)
basean <- do.call(rbind,lapply(split(D,D$iso_code),FUN = function(v){
  f<-data.frame(start=min(v$id),end=max(v$id),iso_code=unique(v$iso_code))
  f$mid<-(f$start +f$ end) / 2
  return(f)
}))

textangle<-angle[floor(basean$mid)]

colorpal<-c("#a18480","#5e7b7f","#a99fc6","#d2691e","#5e86c1","#a1793e",
            "#808000","#ebbe00","#8a322e","#d9e0c4","#506797","#bfac85",
            "#9084b4","#9c9c9c","#7f6358","#a0522d","#c4daee","#675f4c",
            "#c3aebf","#3c5140","#bcd1a2","#354b36","#868381","#b8977b",
            "#7c5335","#cac8b5","#fff1cd","#90e3ff","#ff9ce6","#963f00","#617600")
g<-ggplot(data=D,aes(id, New_cases_smoothed/1000,fill=iso_code))+
  geom_col(position = position_dodge2(),width = 0.9)+
  geom_segment(data=basean,aes(x=start,y=-5,xend=end,yend=-5,color=iso_code))+
  geom_text(data = basean, aes(x = mid, y = -10, label = iso_code), 
            angle=textangle,colour = "grey40",size=2) +
  coord_polar()+
  scale_fill_manual(values=colorpal)+
  scale_color_manual(values=colorpal)+
  scale_y_continuous(limits=c(-100,60),expand=c(0,0))+
  theme(plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
    legend.position = "",
    panel.background = element_blank(),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    panel.grid = element_blank())
ggsave(g, filename = "picture/fig1a-1.pdf",unit="mm",device = cairo_pdf)

dv<-subset(DatasetV2,DatasetV2$Date=="2021-10-25")
dv1<-dv[,c("location","Fully_vaccinated_effect","Fully_vaccinated_pre")]
D$month<-substring(D$Date,0,7)
d1<-D[,c("month","New_cases_smoothed")]%>%dplyr::group_by(month)%>%dplyr::summarize_each(funs(sum))
###########fig 1 a_2#############

library("sf")
library("rnaturalearth")
library("rnaturalearthdata")
library("dplyr")
library("mapproj")
library("fiftystater")
world<-map_data("world")
Dataset<-do.call(rbind,lapply(split(DatasetV2,DatasetV2$location),function(x){
  data.frame(iso=unique(x$iso_code),region=unique(x$location),Vaccination_Fully=max(x$Fully_vaccinated_pre))
}))
Dataset$region[which(Dataset$region=="Czechia")]<-"Czech Republic"
Dataset$region[which(Dataset$region=="United Kingdom")]<-"UK"
world<-full_join(world,Dataset,by="region")

world$w<-1
world$w[which(is.na(world$iso_code))]<-0
world$w<-as.factor(world$w)
p1<-ggplot()+
  geom_polygon(data = world,aes(x=long,y=lat,group=group,fill=Vaccination_Fully),color="white",size=0.1, inherit.aes = F)+  
  #scale_fill_manual(values =c("#eceae4","#576897"))+ 
  scale_fill_gradientn(colors =c("#bfcee5","#c5c8e8","#0b59be"),na.value  = "#ededed",)+
  coord_map("ortho",orientation = c(50,10,0))+
  theme(legend.position = "bottom",
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background = element_blank(),
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        panel.border = element_blank())
ggsave(p1, filename = "picture/fig1a-2.pdf",width=300,heigh=300,unit="mm",device = cairo_pdf)

###########fig 1 b#############
Dataset<-subset(DatasetV2,DatasetV2$Date>="2020-08-01")
var<-Dataset[,c("Date","alphaN","betaN","gammaN","deltaN",
                  "etaN","kappaN","baseN")]
Dataset$Date<-as.Date(Dataset$Date)
var_mean<-group_by(var,Date)%>%summarize_each(funs(mean))

v<-melt(var_mean,id=c("Date"))
v1<-subset(v,v$Date=="2021-01-31")
v1$Date<-"2021-01-30"
v<-do.call(rbind,list(v,v1))
#v<-subset(v,v$Date<="2021-09-16")
v$value[which(v$value==0)]<-NA

var<-ggplot(v,aes(x=as.Date(Date),y=variable))+
  geom_tile(aes(fill=value),
            color="white",lwd=0.1,
            linetype=1)+
  scale_fill_gradientn(colours= brewer.pal(7,"YlGnBu"),na.value="grey99",
                       values=c(0,0.01,0.3,0.6,1.0))+
  scale_x_date(limits=as.Date(c("2020-08-01",max(v$Date))),
               breaks=("1 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  labs(y =NULL,x = NULL)+theme_light()+
  theme(legend.position = "right",
        legend.title=element_blank(),
        legend.key.height=unit(0.4,'cm'),
        legend.key.width =unit(0.1,'cm'),
        #panel.grid=element_line(color="transparent",size=0.01),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_text(color="black",size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.5,0.5,0.5,0.5),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/variant_distribution.pdf",var,width=180,height=40,units="mm",device = cairo_pdf)
dev.off()
###########fig 1 c#############
vv<-DatasetV2[,c("Date","Johnson.Johnson","Moderna","Oxford.AstraZeneca","Pfizer.BioNTech",
                 "Sputnik.V","Sinopharm.Beijing")]
 

vv1<-group_by(vv,Date)%>%summarize_each(funs(mean))

vc<-melt(vv1,id=c("Date"))
vc1<-subset(vc,vc$Date=="2021-01-31")
vc1$Date<-"2021-01-30"
vc<-do.call(rbind,list(vc,vc1))
#vc<-subset(vc,vc$Date<="2021-07-25")
vc$value[which(vc$value==0)]<-NA
vacman<-ggplot(vc,aes(x=as.Date(Date),y=variable))+
  geom_tile(aes(fill=value),
            color="white",lwd=0.1,
            linetype=1)+
  scale_fill_gradientn(#colours=c("#4575B4","#E0F3F8","#FFFFD4","#FEE090","#D73027"),
                       colours= brewer.pal(7,"YlGnBu"),
                       na.value="grey99",
                       values=c(0,0.05,0.2,0.5,0.75,1.0))+
  #scale_fill_gradientn(colours= c("white","#829abf","#3d5985","#425066"), values=c(0,0.02,0.3,1))+
  scale_x_date(limits=as.Date(c("2020-08-01",max(v$Date))),
               breaks=("1 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  labs(y =NULL,x = NULL)+theme_light()+
  theme(legend.position = "right",
        legend.title=element_blank(),
        legend.key.height=unit(0.3,'cm'),
        legend.key.width =unit(0.1,'cm'),
        plot.title = element_text(color="black",size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/vaccine_distribution.pdf",vacman,width=180,height=35,units="mm",device = cairo_pdf)
###########fig 1 d#############

c<-Dataset[,c("Date","location","StringencyIndex","Fully_vaccinated_pre")]
c$Fully_vaccinated_pre<-c$Fully_vaccinated_pre*100
c$StringencyIndex<-c$StringencyIndex*100
cs<-c[,c("Date","location","StringencyIndex")]

cpcol1 <- c("#697fa0", "#526582", "#4682b4", "#4682b4", "#5e86c1", 
           "#97c0e2", "#5b94c2", "#80acd0", "#2eaec6","#2f5a7f", "#0f3c62", 
           "#6587bf", "#9bb1d4", "#2e73c6","#36517d", "#7b8ca9",
           "#b3bccc",  "#8d8fb3", "#8674a1", "#8d8fb3", "#666999", 
           "#cacbdd",  "#78699f", "#b9b1cd", "#778899", "#719fda", "#496e9c",
           "#5686bf","#a099b2","#248f97","#2888e8")
cpcol3<-c("#d9d7cb","#e2dec2","#ece5b8","#fbf1a9","#fae780","#f8c43f",
          "#c59007","#fafb94","#f8fa70","#eaeaae","#d5d661","#c29b32",
          "#ffe6a3","#dcce8f","#d6c499","#c2b54c","#d1c13d","#f0ebc1",
          "#d8ca88","#87772c","#fdeb86","#c4a603","#fbd509","#dfd4c5",
          "#eed6b6","#e0b376","#b0a586")
cpcol2 <- c("#e5d7dd", "#d1b9c5", "#c19fb0", "#9a6580", "#7f5369", "#bc6e57",
           "#eadfe5", "#ddcad1", "#c9abb6", "#af8393", "#986276", "#8c3840",
           "#dfced2", "#c7a9b0", "#ae848e", "#b35b70", "#853d4e", "#b0636a",
           "#cc9090", "#dcb2b2", "#a13030", "#9f6e92", "#a78b8d","#8e645d",
           "#836063", "#cdbcbc", "#e1a893", "#719fda", "#70341f","#f5e2db","#c5927d")

f1<-ggplot(data=c)+
  geom_step(aes(x=as.Date(Date),y=Fully_vaccinated_pre,color=location),size=0.3,alpha=0.1)+
  geom_smooth(aes(x=as.Date(Date),y=Fully_vaccinated_pre),
              color="#602029",fill="#d4aaae",span=0.5,size=0.9)+
  scale_color_manual(values=cpcol2)+
  scale_x_date(limits=as.Date(c("2020-08-01",max(Dataset$Date))),
               breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  scale_y_continuous(limits=c(0,100),expand = c(0,0),breaks=seq(0,100,20))+
  labs(y ="Intensity (%)",x = NULL)+theme_light()+
  theme(legend.position = "none",
        #panel.grid.major = element_line(colour = "transparent"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/fig1b-1.pdf",f1,width=100,height=80,units="mm",device = cairo_pdf)
f2<-ggplot(data=c)+
  geom_step(aes(x=as.Date(Date),y=StringencyIndex,color=location),size=0.3,alpha=0.1)+
  geom_smooth(aes(x=as.Date(Date),y=StringencyIndex),linetype=2,color="#606bbc",fill="#b9bad8",
              span=0.5,size=0.9)+
  scale_color_manual(values=cpcol1)+
  scale_x_date(limits=as.Date(c("2020-08-01",max(Dataset$Date))),
               breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  scale_y_continuous(limits=c(0,100),expand = c(0,0),breaks=seq(0,100,20))+
  labs(y ="Intensity (%)",x = NULL)+theme_light()+
  theme(legend.position = "none",
        #panel.grid.major = element_line(colour = "transparent"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/fig1b-2.pdf",f2,width=100,height=80,units="mm",device = cairo_pdf)
###########fig 1 e#############
###########plot R0 and Rt##################
Dataset<-subset(DatasetV2,DatasetV2$Date>="2020-08-01")
c<-Dataset[,c("Date","location","Rt")]
R<-Dataset[,c("Date","R0","Rt")]
R1<-R%>%dplyr::group_by(Date)%>%summarize_each(funs(mean))
cbPalette <- c("#f5ead6", "#e6c68e", "#deb368", "#d1952e", "#8e661f", 
               "#d3c6b1", "#bba886", "#a78e62", "#89734d", "#52452e", 
               "#d8d1ca", "#c7bdb3", "#aa9b8d", "#7e6d5d", "#726040", 
               "#e5be9e", "#daa172", "#ce8346", "#ad672e", "#895224", 
               "#feeab4", "#fdde87", "#fcd055", "#ebae05", "#7d5d02","#a27c3c")

f<-ggplot(data=R1)+
  geom_smooth(aes(x=as.Date(Date),y=Rt),color="#60868d",span=0.4,size=0.9,alpha=0.4)+
  geom_smooth(aes(x=as.Date(Date),y=R0),color="#9cbcbc",span=0.4,size=0.9,alpha=0.4,linetype=4)
gg1 <- ggplot_build(f)

# extract data for the loess lines from the 'data' slot
df2 <- data.frame(x = gg1$data[[1]]$x,
                  ymin = gg1$data[[1]]$y,
                  ymax = gg1$data[[2]]$y) 
f2<-f+
  geom_ribbon(data=df2,aes(x=as.Date(x), ymin = ymin, ymax = ymax),fill="#c6e7e6",
              alpha = 0.3)+
  scale_x_date(limits=as.Date(c("2020-08-01",max(Dataset$Date))),
               breaks=("2 month"),labels=date_format("%b\n%Y"))+
  scale_y_continuous(limits=c(0,5),expand = c(0,0),breaks=seq(0,5,1))+
  geom_vline(aes(xintercept=as.Date("2020-12-22"),color="#d2dde4",alpha=0.3))+
  geom_vline(aes(xintercept=as.Date("2021-05-04"),color="#d2dde4",alpha=0.3))+
  labs(y ="Repoduction number",x = NULL)+theme_clean()+
  scale_color_manual(values=cbPalette)+
  theme(legend.position = "",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("0924picture/fig2a-2.pdf",f2,width=90,height=30,units="mm",device = cairo_pdf)

fig3plotfunction<-function(figpath){
  rd<-read.csv(paste0(figpath,"/countryresult_all.csv"),stringsAsFactors = F)
  l<-rd[,c("median_SI","strength_SI","median_V","strength_V","start","country")]
  l1<-rd[,c("median_SI","strength_SI","strength_V")]
  colnames(l1)<-c("m","s","v")
  l2<-rd[,c("median_V","strength_SI","strength_V")]
  colnames(l2)<-c("m","s","v")
  l1$par<-"Stringency Index"
  l2$par<-"Fully vaccination"
  l<-do.call(rbind,list(l1,l2))
  l$v1<-cut(l$v*100,breaks=seq(0,60,20))
  l$s1<-cut(l$s*100,breaks=seq(20,80,10))
  l<-l[complete.cases(l),]
  l$m<-(1-exp(-l$m))
  l$label<-"After vaccination"
  l$label[which(l$v==0)]<-"Before vaccination"
  lfig<-subset(l,l$v>0)
  lfig3<-subset(l,l$v==0)
  lfig3<-subset(lfig3,lfig3$par=="Stringency Index")
  lfig1<-subset(lfig,lfig$par=="Stringency Index")
  lfig1<-subset(lfig1,lfig1$m>0.01)
  lfig2<-subset(lfig,lfig$par=="Fully vaccination")
  my_comparisons <- list(c("(0,15]", "(15,30]"), c("(0,15]", "(30,45]"), c("(0,15]", "(45,60]"),
                         c("(15,30]", "(30,45]"), c("(15,30]", "(45,60]"), c("(30,45]", "(45,60]")) 
  #my_comparisons <- list(c("(0,20]", "(20,40]"), c("(0,20]", "(40,60]"),  c("(20,40]", "(40,60]"))
  #my_comparisons <- list(c("(0,10]", "(10,20]"), c("(0,10]", "(20,30]"), c("(0,10]", "(30,40]"),c("(0,10]", "(40,50]"), c("(0,10]", "(50,60]"),
  #                       c("(10,20]", "(20,30]"), c("(10,20]", "(30,40]"),c("(10,20]", "(40,50]"), c("(10,20]", "(50,60]"),
  #                       c("(20,30]", "(30,40]"), c("(20,30]", "(40,50]"), c("(20,30]", "(50,60]"),
  #                       c("(30,40]", "(40,50]"),c("(30,40]", "(50,60]"),c("(40,50]", "(50,60]")) 
  fig3a<-ggplot()+
    geom_flat_violin(data=lfig3,aes(x=as.factor(v1),y=m*100),fill ="#7f97bd", 
                     alpha=0.4, color="black",width=1)+
    geom_flat_violin(data=lfig1,aes(x=as.factor(v1),y=m*100),fill ="#7f97bd", 
                     alpha=0.4, color="black",width=1)+
    geom_boxplot(data=lfig2,aes(x=as.factor(v1),y=m*100),width=0.2,position=position_nudge(x=0.5),color="#723f39",fill="#d4afaa",alpha=0.4)+
    geom_jitter(data=lfig1,aes(x=as.factor(v1),y=m*100,color=s),position=position_nudge(x=-0.05),size=0.5,alpha=0.8)+
    geom_jitter(data=lfig3,aes(x=as.factor(v1),y=m*100,color=s),position=position_nudge(x=-0.05),size=0.5,alpha=0.8)+
    scale_color_gradientn(colours=brewer.pal(7,"PuBuGn"),breaks=c(min(lfig1$s),max(lfig1$s)))+
    scale_fill_gradientn(colours=  c("grey95","#7b2625"),breaks=c(0,max(lfig2$v)))+
    labs(y = paste0("Reduction in R0,t","(%)"),x = "Vaccination rate (%)")+
    scale_y_continuous(limits=c(0,80),expand=c(0,0))+
    theme_clean()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = 10),
          axis.title.x= element_text(color="black",size = 10),
          axis.text.x = element_text(color="black",size = 10),
          axis.title.y= element_text(color="black",size = 10),
          axis.text.y = element_text(color="black",size = 10),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(figpath,"/fig3a.pdf"),fig3a,units="mm",width=120,height=100,device = cairo_pdf)
  
  mydata2<-do.call(rbind,lapply(split(lfig1,lfig1$s1),function(data){
    k<-do.call(rbind,lapply(my_comparisons,function(m){
      d<-do.call(rbind,split(data,data$v1)[m])
      if(length(unique(d$v1))>1){
        c<-compare_means( m ~ v1, data = d,method="anova" )
        c$par<-paste(as.vector(m)[1],as.vector(m)[2])
      }else{c<-NULL}
      return(c)
    }))
    return(k)
  }))
  write.csv(mydata2,paste0(figpath,"/fig3b.csv"),row.names = F)
  fig3b<-ggplot()+
    geom_boxplot(data=lfig1,aes(x=s1,y=m*100,fill=v1,color=v1), 
                 alpha=0.5,width=1)+
    scale_fill_manual(values = c("#cec2d6","#fde590",
                                 "#f7a95f","#14a1a7",
                                 "#9bbeda","#6e6e4b",
                                 "#e3c6c2","#c4c3be"
    ))+
    scale_color_manual(values = c("#cec2d6","#fde590",
                                  "#f7a95f","#14a1a7",
                                  "#9bbeda","#6e6e4b",
                                  "#e3c6c2","#c4c3be"))+
    labs(y = paste0("Reduction in R0,t","(%)"),
         x = "Stringency index intensity")+
    theme_clean()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = 10),
          axis.title.x= element_text(color="black",size = 10),
          axis.text.x = element_text(color="black",size = 10),
          axis.title.y= element_text(color="black",size = 10),
          axis.text.y = element_text(color="black",size = 10),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",
                                        colour = NA))
  ggsave(paste0(figpath,"/fig3b.pdf"),fig3b,units="mm",width=100,height=120,device = cairo_pdf)
  
  
  ################plot fig2b-2##############
  D<-DatasetV2[,c("Fully_vaccinated_effect","Date","location")]
  D$Date<-as.Date(D$Date)
  D$m<-cut(D$Date,breaks=seq(as.Date("2020-08-01"),max(D$Date)+30,30))
  D<-D[complete.cases(D),]
  D<-D%>%dplyr::group_by(m,location)%>%dplyr::summarise(Fully_vaccinated_effect=mean(Fully_vaccinated_effect))
  D$v1<-cut(D$Fully_vaccinated_effect*100,breaks=seq(-10,90,10))
  
  D$m<-as.Date(D$m)
  conv<-D[,c("m","v1","location")]%>%dplyr::group_by(v1,location)%>%dplyr::summarise(min=min(m),max=max(m))
  conv<-conv[complete.cases(conv),]
  Variants[is.na(Variants)]<-0
  Variants$date<-as.Date(Variants$date)
  Variants<-do.call(rbind,split(Variants,Variants$location)[unique(D$location)])
  
  dv<-lapply(seq(1,10),function(n){
    v<-split(conv,conv$v1)[[n]]
    if(n>1){
      v1<-split(conv,conv$v1)[[n-1]]
    }
    if (nrow(v)>0){
      vlist<-lapply(1:length(split(v,v$location)),function(m){
        l<-split(v,v$location)[[m]]
        if(n>1){min<-v1$max[which(v1$location==l$location)]}else(min<-l$min)
        k<-subset(Variants,Variants$date<=l$max&Variants$date>l$min)
        k<-k[,-c(1,2)]%>%dplyr::group_by(variant)%>%dplyr::summarise_each(funs(sum))
        return(k)
      })
      i<-do.call(rbind,vlist)
      if (nrow(i>0)){
        i<-i[,-3]%>%dplyr::group_by(variant)%>%dplyr::summarise_each(funs(sum))
        alphaN<- i$num_sequences[which(i$variant=="Alpha")]/i$num_sequences_total[1]
        betaN<-i$num_sequences[which(i$variant=="Beta")]/i$num_sequences_total[1]
        gammaN<-i$num_sequences[which(i$variant=="Gamma")]/i$num_sequences_total[1]
        deltaN<-i$num_sequences[which(i$variant=="Delta")]/i$num_sequences_total[1]
        etaN<-i$num_sequences[which(i$variant=="Eta")]/i$num_sequences_total[1]
        kappaN<-i$num_sequences[which(i$variant=="Kappa")]/i$num_sequences_total[1]
        baseN<-1-alphaN-betaN-gammaN-deltaN-etaN-kappaN
        r<-data.frame(alpha=alphaN,beta=betaN,
                      gamma=gammaN,delta=deltaN,eta=etaN,kappa=kappaN,
                      base=baseN,v=as.vector(unique(v$v1)))
      }else{r<-NULL}
    }else{r<-NULL}
    return(r)
  })
  varD<-do.call(rbind,dv)
  varD$v<-unique(conv$v1)[-c(8,9)]
  varD<-melt(varD,id="v")
  fig2b4<-ggplot(data=varD,aes(v,value,fill=variable))+geom_bar(stat="identity",position="stack")+
    scale_fill_manual(values=  c("#d2dde4","#f5ba93","#80bfb0","#ead4e2","#75cbe8","#f6dd6e","#fff7ee"))+
    labs(y = paste0("Proportion of variant","(*100%)"),x = "Vaccination rate (%)")+
    scale_y_continuous(limits=c(0,1),expand=c(0,0))+
    theme_clean()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = 10),
          axis.title.x= element_text(color="black",size = 10),
          axis.text.x = element_text(color="black",size = 10),
          axis.title.y= element_text(color="black",size = 10),
          axis.text.y = element_text(color="black",size = 10),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(figpath,"/fig3a-2.pdf"),fig2b4,units="mm",width=120,height=50,device = cairo_pdf)

}
fig4plotfunction<-function(risk,figpath){
  risk<-do.call(rbind,split(risk,risk$CountryName)[unique(DatasetV2$location)])
  risk$Date<-as.Date(risk$Date)
  risk<-subset(risk,risk$Date>="2020-08-01")
  rd<-read.csv(paste0(figpath,"/countryresult_all.csv"),stringsAsFactors = F)
  l<-rd[,c("median_SI","strength_SI","median_V","strength_V","start","country")]
  dda<-max(DatasetV2$Date)
  Rtdata<-DatasetV2[,c("iso_code","Date","R0","Rt","Fully_vaccinated_effect","StringencyIndex")]
  Rtdata<-subset(Rtdata,Rtdata$Date==dda)
  Rtdata<-Rtdata%>%distinct(iso_code,Date,.keep_all = T)
  Rt<-Rtdata
  Rt<-Rtdata[,-2]%>%dplyr::group_by(iso_code)%>%dplyr::summarise_each(funs(mean))
  Rt$Reduction<-(Rt$Rt-1)/Rt$R0*100
  Rt$Open<-abs(Rt$Reduction)^(1/0.93)
  Rt$Open[which(Rt$Reduction<0)]<--Rt$Open[which(Rt$Reduction<0)]
  write.csv(Rt,paste0(figpath,"/fig4a_result.csv"),row.names = F)
  colnames(Rt)<-c("adm0_a3",names(Rt)[-1])
  world <- ne_countries(scale = "medium",type = 'map_units', returnclass = "sf")
  class(world)
  world<-full_join(world,Rt,by="adm0_a3")
  world<-world[-which(world$adm0_a3=="ATA"),]
  p1<-ggplot() +geom_sf(data = world,aes(fill=Open), inherit.aes = F)+  
    scale_fill_gradientn(colors =c("#51a1b5","#fddc8c","#a62b1f"),na.value  = "#ededed")+
    coord_sf(expand = FALSE,crs=4326) +
    scale_x_continuous(limits=c(-25,45))+
    scale_y_continuous(limits=c(25,75))+
    theme_bw()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          legend.text = element_text(size = 10),
          legend.background = element_rect(fill="transparent",color=NA),
          legend.key=element_rect(fill=NA),
          plot.title = element_text(color="black",hjust = 0,vjust=0, size=10),
          axis.ticks= element_line(color="black"),
          axis.text = element_text(color="black",vjust=0,hjust=0, size=9),
          panel.background=element_rect(fill = "transparent",colour = NA),
          axis.line = element_line(size=0.05),
          axis.title = element_text(color="black", size=9))
  ggsave(p1, filename = paste0(figpath,"/fig4a.pdf"),width=120,heigh=90,unit="mm",device = cairo_pdf)
  
  dda<-as.Date("2021-03-04")
  Rtdata<-DatasetV2[,c("location","Date","R0","Rt","Fully_vaccinated_effect","StringencyIndex")]
  Rtdata<-subset(Rtdata,Rtdata$Date==dda)
  Rtdata<-Rtdata%>%distinct(location,Date,.keep_all = T)
  Rt<-Rtdata
  Rt<-Rtdata[,-2]%>%dplyr::group_by(location)%>%dplyr::summarise_each(funs(mean))
  Rt$Reduction<-(Rt$Rt-1)/Rt$R0*100
  Rt$Open<-abs(Rt$Reduction)^(1/0.93)
  Rt$Open[which(Rt$Reduction<0)]<--Rt$Open[which(Rt$Reduction<0)]
  r<-subset(risk,risk$Date==dda)[,-c(1,2)]
  r1<-r[,-2]%>%dplyr::group_by(CountryName)%>%dplyr::summarise_each(funs(mean))
  colnames(r1)<-c("location",names(r1)[-1])
  r<-merge(Rt,r1,by="location")
  g2<-ggplot(r,aes(x=Open,y=openness_risk))+geom_point(aes(color=StringencyIndex,size=Fully_vaccinated_effect))+
    geom_vline(aes(xintercept=0),linetype=2)+geom_hline(aes(yintercept=0.5),linetype=2)+
    geom_text(aes(label=location), nudge_y = 0.04,size=3)+
    theme_bw()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          legend.text = element_text(size = 10),
          legend.background = element_rect(fill="transparent",color=NA),
          legend.key=element_rect(fill=NA),
          plot.title = element_text(color="black",hjust = 0,vjust=0, size=10),
          axis.ticks= element_line(color="black"),
          axis.text = element_text(color="black",vjust=0,hjust=0, size=9),
          panel.background=element_rect(fill = "transparent",colour = NA),
          axis.line = element_line(size=0.05),
          axis.title = element_text(color="black", size=9))
  ggsave(g2, filename = paste0(figpath,"/fig4b.pdf"),width=110,heigh=90,unit="mm",device = cairo_pdf)
  return(r)
}




