library("rstan")
library("bayesplot")
library("ggplot2")
###########Priori and Posterior plot##########
setwd("E:/COVID19_vacciantion1210")
f<-readRDS("20220329_V2normal(0,0.3)0.5/R0_calculate/Austria_withinR0/all.rds")

out<-rstan::extract(f)
u<-as.data.frame(out$u)
colnames(u)<-"Posterior"
u$Priori<-runif(nrow(u),0,1)
plot_title <- ggtitle("Priori distributions of u~uniform(0,1) \nwith mean and 95% intervals")

N = length(u$Priori) 
mean = mean(u$Priori)
sd = sd(u$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(u$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=dense,aes(x,y),
            colour="#606882",fill="#c8d5e5",size=0.5)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=0.5)+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
#ggsave("picture/Distribution_of_u.pdf",pp,units="mm",width=70,height=50,device = cairo_pdf)
outpath<-"20220329_V2normal(0,0.3)0.5result"
if (dir.exists(outpath)==F){dir.create(outpath)
}else{print("This path has been exists")}

alpha<-as.data.frame(as.data.frame(out$alpha)[,1])
colnames(alpha)<-"Posterior"
alpha$Priori<-rgamma(nrow(alpha),mean(u$Posterior),1)
plot_title <- ggtitle(expression("Priori distributions of "*alpha*"~gamma(u,1)"))

N = length(alpha$Priori) 
mean = mean(alpha$Priori)
sd = sd(alpha$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(alpha$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=dense,aes(x,y),
            colour="#606882",fill="#c8d5e5",size=0.5)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+labs(y = paste0("Density"),x = "")+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=0.5)+
  scale_x_continuous(limits=c(0,max(dense$x)))+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave(paste0(outpath,"/Distribution_of_alpha.pdf"),pp,units="mm",width=70,height=50,device = cairo_pdf)

beta<-as.data.frame(as.data.frame(out$alpha)[,2])
colnames(beta)<-"Posterior"
beta$Priori<-rgamma(nrow(beta),mean(u$Posterior),1)
plot_title <- ggtitle(expression("Priori distributions of "*beta*"~gamma(u,1)"))
N = length(beta$Priori) 
mean = mean(beta$Priori)
sd = sd(beta$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(beta$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=dense,aes(x,y),
            colour="#606882",fill="#c8d5e5",size=0.5)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+labs(y = paste0("Density"),x = "")+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=0.5)+
  scale_x_continuous(limits=c(0,max(dense$x)))+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave(paste0(outpath,"/Distribution_of_beta.pdf"),pp,units="mm",width=70,height=50,device = cairo_pdf)

lambda<-as.data.frame(as.data.frame(out$alpha)[,3])
colnames(lambda)<-"Posterior"
lambda$Priori<-rgamma(nrow(lambda),mean(u$Posterior),1)
plot_title <- ggtitle(expression("Priori distributions of "*lambda*"~gamma(u,1)"))
N = length(lambda$Priori) 
mean = mean(lambda$Priori)
sd = sd(lambda$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(lambda$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=dense,aes(x,y),
            colour="#606882",fill="#c8d5e5",size=0.5)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+labs(y = paste0("Density"),x = "")+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=0.5)+
  scale_x_continuous(limits=c(0,max(dense$x)))+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave(paste0(outpath,"/Distribution_of_lambda.pdf"),pp,units="mm",width=70,height=50,device = cairo_pdf)

u1<-mean(out$u1)
phi<-as.data.frame(out$beta)
colnames(phi)<-"Posterior"
phi$Priori<-rnorm(nrow(phi),0,u1)
plot_title <- ggtitle(expression("Priori distributions of "*varphi*"~normal(0,k)"))
N = length(phi$Priori) 
mean = mean(phi$Priori)
sd = sd(phi$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(phi$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=dense,aes(x,y),
            colour="#606882",fill="#c8d5e5",size=0.5)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+labs(y = paste0("Density"),x = "")+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=0.5)+
  scale_x_continuous(limits=c(min(dense$x),max(dense$x)))+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave(paste0(outpath,"/Distribution_of_phi.pdf"),pp,units="mm",width=70,height=50,device = cairo_pdf)

u2<-mean(out$u2)
eli<-as.data.frame(out$eli)
colnames(eli)<-"Posterior"
eli$Priori<-rnorm(nrow(eli),0,u2)
plot_title <- ggtitle(expression("Priori distributions of "*Delta*"~normal(0,k)"))
N = length(eli$Priori) 
mean = mean(eli$Priori)
sd = sd(eli$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(eli$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=dense,aes(x,y),
            colour="#606882",fill="#c8d5e5",size=0.5)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+labs(y = paste0("Density"),x = "")+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=0.5)+
  scale_x_continuous(limits=c(min(dense$x),max(dense$x)))+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave(paste0(outpath,"/Distribution_of_epslion.pdf"),pp,units="mm",width=70,height=50,device = cairo_pdf)

k<-as.data.frame(out$k)
colnames(k)<-"Posterior"
r<-rnorm(nrow(k)*3,0,0.5)
k$Priori<-r[which(r>0)][1:nrow(k)]
plot_title <- ggtitle(paste0("Priori distributions of k~normal(0,0.5)"))
N = length(k$Priori) 
mean = mean(k$Priori)
sd = sd(k$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(k$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=dense,aes(x,y),
            colour="#606882",fill="#c8d5e5",size=1)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+labs(y = paste0("Density"),x = "")+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=1)+
  scale_x_continuous(limits=c(min(dense$x),max(dense$x)))+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
#ggsave(paste0(outpath,"/Distribution_of_k.pdf"),pp,units="mm",width=70,height=50,device = cairo_pdf)

r0<-read.csv("dataset/R0_for_each_country.csv",stringsAsFactors = F)
r0<-r0$R01[which(r0$country_territory=="United Kingdom")]
R0<-as.data.frame(out$R0_base)
colnames(R0)<-"Posterior"
r<-rgamma(nrow(R0)*3,r0,mean(k$Posterior))
R0$Priori<-r[which(r>1)][1:nrow(R0)]
plot_title <- ggtitle(expression("Priori distributions of "*R[0]*"~gamma(max"*R[t]*", k)"))
N = length(R0$Priori) 
mean = mean(R0$Priori)
sd = sd(R0$Priori)
se = sd/sqrt(N) 
dense = data.frame(density(R0$Priori)[c('x','y')])
pp<-ggplot()+
  geom_area(data=subset(dense,x>=1.5),aes(x,y),
            colour="#606882",fill="#c8d5e5",size=1)+
  #mcmc_areas(u,#par=c("Priori","Posterior"),par=c("Priori"),prob = 0.95) + 
  plot_title+labs(y = paste0("Density"),x = expression("R"["0"]))+
  geom_vline(aes(xintercept=mean),
             color="#606882", linetype="dashed", size=1)+
  scale_x_continuous(limits=c(0,max(dense$x)),breaks = c(0,5,10,15,20))+
  theme_classic()+
  theme(legend.position = "none",
        legend.background = element_rect(fill=NA),
        legend.key.size = unit(9, "pt"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
        axis.text.x= element_text(color="black",size = unit(9, "pt")),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave(paste0(outpath,"/Distribution_of_R0.pdf"),pp,units="mm",width=70,height=50,device = cairo_pdf)
ggsave(paste0(outpath,"/Distribution_of_R0.png"),pp,units="mm",width=100,height=75)
