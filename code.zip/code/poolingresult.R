
library("rstan")
library("bayesplot")
library("zoo")
library("dplyr")
library("reshape2")
library("scales")
library("ggridges")
library("ggthemes")
library("ggcor")
library("ggplot2")
library("gridExtra")
library("ggalt")
library("aomisc")
library("meta")
library("RColorBrewer")
library("grid")
library("Hmisc")
library("ggthemr")
library("caret")
setwd("E:/COVID19_vacciantion1210")#set up your setwd here
source('code/main.R')
fit<-readRDS("pooling_witheachcountry/R0_calculate/all.rds")
out<-rstan::extract(fit)

alc<-as.data.frame(out$aic)
bec<-as.data.frame(out$bec)
elc<-as.data.frame(out$elic)
DD<-read.csv("pooling_witheachcountry/Europe_dataset_withinR0_pooling.csv")
xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")
outpath<-""
outname<-"pooingResult"
plot<-lapply(seq(1,length(unique(DD$iso_code))),function(n){
  start<-as.Date("2020-08-01")
  alcc<-alc[,((n-1)*45+1):(n*45)]
  becc<-bec[,((n-1)*15+1):(n*15)]
  elcc<-elc[,((n-1)*15+1):(n*15)]
  DDD<-subset(DD,DD$iso_code==unique(DD$iso_code)[n])
  d<-do.call(rbind,lapply(seq(1,15),function(i){
    start<-start+30*(i-1)
    end<-start+30
    al<-alcc[,((i-1)*3+1):(i*3)]
    be<-becc[,i]
    el<-elcc[,i]
    pars<-do.call(cbind,list(al,be,el))
    colnames(pars)<-c(xname,"Air Temperature","Epslion")
    k1<-subset(DDD,DDD$Date>=start&DDD$Date<(end+1))
    X<-as.data.frame(do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
      if(x=="Epslion"){m<-1}else{
        m<-mean(k1[,x])
      }
      return(m)
    })))
    colnames(X)<-c(xname,"Air Temperature","Epslion")
    #for (k in c(xname,"Air Temperature","Epslion")){
    #  pars[,k]<- pars[,k]*X[,k]}
    pars$all_SI<-pars$StringencyIndex+pars$Interaction
    pars$all_V<-pars$Fully_vaccinated_effect+pars$Interaction
    #write.csv(pars,paste0("sensitivity_analysis/",outname,"_",c,"_",start,".csv"),row.names = F)
    pars$all<-apply(pars,1,sum)
    pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
    pars<-(1-exp(-pars))*100
    pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="mean")
    pard$start<-start
    pard$end<-end
    pard$strength<-0
    for (i in c(xname,"Air Temperature","Epslion")){
      pard$strength[which(pard$parameter==i)]<-X[,i]
    }
    pard$strength[which(pard$parameter=="all_SI")]<-X[,"StringencyIndex"]
    pard$strength[which(pard$parameter=="all_V")]<-X[,"Fully_vaccinated_effect"]
    pard$country<-unique(DDD$location)
    return(pard)
  }))
  rg<-subset(d,d$parameter=="Fully_vaccinated_effect"|d$parameter=="StringencyIndex"|d$parameter=="Interaction")
  rg$start[which(rg$parameter=="Fully_vaccinated_effect")]<-rg$start[which(rg$parameter=="Fully_vaccinated_effect")]+10
  rg$start[which(rg$parameter=="Interaction")]<-rg$start[which(rg$parameter=="Interaction")]+20
  g<-ggplot(data=rg)+
    geom_bar(aes(x=as.Date(start),y=strength*100,fill=parameter),stat="identity",
             position=position_dodge(width=0),alpha=0.2,width=8,size=0.1)+
    geom_xspline(aes(x=as.Date(start),y=m,color=parameter),size=0.1)+
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~l, ymax=~h, x=~as.Date(start),color= ~parameter),
                  show.legend = T,alpha=0.7,width=8,
                  size=0.5)+
    geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1)+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("4 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_shape_manual(values = c(21,24,4))+
    scale_color_manual(values=c("#0b5c9e","#880208","#80581d"))+
    scale_fill_manual(values=c("#0b5c9e","#880208","#80581d"))+
    scale_size_continuous(breaks=c(0,0.2,0.4,0.6,0.8,1.0))+
    scale_y_continuous(limits=c(-10,100),breaks=c(0,25,50,75,100),expand=c(0,0))+
    labs(y =paste0("Reduction in Rt","(%)"),x = NULL,title=unique(DDD$location))+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "",
          panel.grid.major = element_line(colour = "white"),
          panel.grid.minor = element_line(colour = "white"),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.x = element_text(color="black",size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.border= element_rect(color=NA,fill=NA),
          panel.background=element_rect(fill = "transparent",colour = NA))
  #ggsave(paste0("pooling_witheachcountry/fig_",unique(DDD$location),"_0.5.png"),g,
  #       units="mm",width=75,height=50)
  return(g)
})

for(i in 1:length(plot)){
  if(i%%2==1){
    plot[[i]]<-plot[[i]]+theme(axis.ticks.y=element_line(color="black"),
                               axis.title.y= element_text(color="black",angle=90,size = unit(9, "pt")),
                               axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")))}
}
legend<-plot[[1]]+guides(color=guide_legend(ncol=1))+
  theme(legend.position = "right",legend.title=element_blank(),
        legend.text = element_text(size = unit(9, "pt")),
        legend.background = element_rect(fill=NA,color=NA),
        legend.key=element_rect(fill="transparent"))
plot[[32]]<-g_legend(legend)
for (i in seq(1,32,2)){
  pl<-grid.arrange(plot[[i]],plot[[i+1]],ncol =2)
  ggsave(paste0(outpath,"/",outname,i,".pdf"),pl,units="mm",width=140,height=50,device = cairo_pdf)
  ggsave(paste0(outpath,"/",outname,i,".png"),pl,units="mm",width=140,height=50)
}
