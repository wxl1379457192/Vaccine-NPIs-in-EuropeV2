Vaccination_complementation<-function(Vaccination){
  V1<-read.csv(Vaccination,stringsAsFactors = F)
  V1<-do.call(rbind,lapply(split(V1,V1$iso_code),FUN=function(x){
    x$date<-as.Date(x$date)
    startdate <- min(x$date)
    enddate <-max(x$date)
    date2 <- as.data.frame(seq.Date(from = startdate,to=enddate,by="days"))
    colnames(date2)<-"Date"
    date2$location<-unique(x$location)
    date2$iso_code<-unique(x$iso_code)
    date2$total_vaccinations<-0
    date2$people_vaccinated<-0
    date2$people_fully_vaccinated<-0
    date2$boosters<-0
    date2$daily_vaccinations_raw<-0
    date2$daily_vaccinations<-0
    date2$total_vaccinations_per_hundred<-0
    date2$people_vaccinated_per_hundred<-0
    date2$people_fully_vaccinated_per_hundred<-0
    date2$total_boosters_per_hundred<-0
    date2$daily_vaccinations_per_million<-0
    date2$daily_people_vaccinated<-0
    date2$daily_people_vaccinated_per_hundred<-0
    for(i in 4:ncol(x)){
      for(j in 1:nrow(x)){
        d<-x$date[j]
        date2[which(date2$Date==d),i]<-x[j,i]
      }
    }
    return(date2)
  }))
  #write.csv(V1,file = 'Dataset/vaccinations.csv',row.names = F)
  return(V1)
}
nafill<-function(x){
  if(length(which(is.na(x)))>0){
    list<-which(is.na(x))
    for (i in 1:length(list)){
      ii<-list[i]%%7
      l<-seq(ii,length(x),7)
      data<-zoo(x[l])
      x[l]<-na.fill(data,"extend")
    }
    return(x)
  }else(return(x))
}
facial_mask_add<-function(DatasetV2,facialpath="facial/"){
  fclist<-list.files(facialpath,".csv")
  name<-strsplit(fclist,".csv")
  D<-do.call(rbind,lapply(name,function(n){
    d<-subset(DatasetV2,DatasetV2$location==n)
    f<-read.csv(paste0(facialpath,n,".csv"),stringsAsFactors = F)
    colnames(f)<-c("Date","facial.mask")
    f$Date<-as.Date(f$Date)
    d$Facial.mask<-0
    datelist<-split(f,f$Date)
    for (i in datelist){
      if((unique(i$Date)-6>=min(d$Date))&(unique(i$Date)<=max(d$Date))){
        d$Facial.mask[(which(d$Date==unique(i$Date))-6):which(d$Date==unique(i$Date))]<-
          as.numeric(i$facial.mask)/100
      }
    }
    print(paste(unique(d$location),"has been processed"))
    return(d)
  }))
  return(D)
}

mobility_add<-function(DatasetV2,google_mobility){
  mob<-read.csv(google_mobility,nrows = F)
  D<-do.call(rbind,lapply(split(DatasetV2,DatasetV2$iso_code),FUN=function(s){
    m<-subset(mob,mob$country_region==unique(s$location))
    m<-subset(m,m$sub_region_1=="")
    m$date<-as.Date(m$date)
    m<-m[,-8:-1]
    colnames(m)<-c("Date","Retail and recreation","Grocery and pharmacy","Parks","Transit stations","Workplaces","Residential")
    for(i in 2:(ncol(m)-1)){
      m[,i]<-nafill(m[,i])
      m[,i]<--m[,i]/100}
    m[,"Residential"]<-nafill(m[,"Residential"])
    m[,"Residential"]<-m[,"Residential"]/100
    s$Date<-as.Date(s$Date)
    s1<-merge(m,s,by="Date")
    return(s1)
  }))
  return(D)
}
mobility_add_smoothdata<-function(DatasetV2,google_mobility){
  mob<-read.csv(google_mobility,nrows = F)
  D<-do.call(rbind,lapply(split(DatasetV2,DatasetV2$iso_code),FUN=function(s){
    m<-subset(mob,mob$Entity==unique(s$location))
    m$Day<-as.Date(m$Day)
    m<-m[,-c(1,2)]
    colnames(m)<-c("Date","Retail and recreation","Grocery and pharmacy","Residential","Transit stations","Parks","Workplaces")
    for(i in 2:ncol(m)){
      m[,i]<-nafill(m[,i])
      m[,i]<--m[,i]/100}
    m[,"Residential"]<--m[,"Residential"]
    s$Date<-as.Date(s$Date)
    s1<-merge(m,s,by="Date")
    return(s1)
  }))
  return(D)
}
approx_sd<-function(x1,x2){
  (x2-x1)/(qnorm(0.95)-qnorm(0.05))
}
#vartran$sd<-approx_sd(vartran$IQR.,vartran$IQR..1)
variant_add<-function(RT,Variants){
  #RT<-RT[,c("iso_code","continent","location","date","reproduction_rate","total_cases","new_cases_smoothed")]
  RT<-RT[,c("iso_code","continent","location","date","reproduction_rate","new_cases","new_cases_smoothed")]
  RT$date<-as.Date(RT$date)
  #vartran<-read.csv("Dataset/variant_tranmission.csv")
  Variants[is.na(Variants)]<-0
  Variants$date<-as.Date(Variants$date)
  colnames(RT)<-c("iso_code","continent","location","Date","Rt","Total_cases","New_cases_smoothed")
  list<-lapply(split(RT,RT$location),FUN = function(v){
    V<-subset(Variants,Variants$location==unique(v$location))
    v[is.na(v)]<-0
    #r0<-R0_base$R0[which(R0_base$location==unique(v$location))]
    if (nrow(V)>0){
      v$alphaN<-as.numeric(0)
      v$betaN<-as.numeric(0)
      v$gammaN<-as.numeric(0)
      v$etaN<-as.numeric(0)
      v$kappaN<-as.numeric(0)
      v$deltaN<-as.numeric(0)
      v$baseN<-as.numeric(1)
      datelist<-split(V,V$date)
      for (i in datelist){
        if(unique(i$date)-14>=min(v$Date)){
          v$alphaN[(which(v$Date==unique(i$date))-13):which(v$Date==unique(i$date))]<-
            as.numeric(i$perc_sequences[which(i$variant=="Alpha")])/100
          v$betaN[(which(v$Date==unique(i$date))-13):which(v$Date==unique(i$date))]<-
            as.numeric(i$perc_sequences[which(i$variant=="Beta")])/100
          v$gammaN[(which(v$Date==unique(i$date))-13):which(v$Date==unique(i$date))]<-
            as.numeric(i$perc_sequences[which(i$variant=="Gamma")])/100
          v$deltaN[(which(v$Date==unique(i$date))-13):which(v$Date==unique(i$date))]<-
            as.numeric(i$perc_sequences[which(i$variant=="Delta")])/100
          v$etaN[(which(v$Date==unique(i$date))-13):which(v$Date==unique(i$date))]<-
            as.numeric(i$perc_sequences[which(i$variant=="Eta")])/100
          v$kappaN[(which(v$Date==unique(i$date))-13):which(v$Date==unique(i$date))]<-
            as.numeric(i$perc_sequences[which(i$variant=="Kappa")])/100
          a<-1-as.numeric(i$perc_sequences[which(i$variant=="Alpha")])/100-
            as.numeric(i$perc_sequences[which(i$variant=="Beta")])/100-
            as.numeric(i$perc_sequences[which(i$variant=="Gamma")])/100-
            as.numeric(i$perc_sequences[which(i$variant=="Delta")])/100-
            as.numeric(i$perc_sequences[which(i$variant=="Eta")])/100-
            as.numeric(i$perc_sequences[which(i$variant=="Kappa")])/100
          v$baseN[(which(v$Date==unique(i$date))-13):which(v$Date==unique(i$date))]<-ifelse(a>=0,a,0)
        }
        if(max(v$Date)>max(V$date)){
          v$deltaN[which(v$Date>max(V$date))]<-v$deltaN[which(v$Date==max(V$date))]
          v$alphaN[which(v$Date>max(V$date))]<-v$alphaN[which(v$Date==max(V$date))]
          v$betaN[which(v$Date>max(V$date))]<-v$betaN[which(v$Date==max(V$date))]
          v$gammaN[which(v$Date>max(V$date))]<-v$gammaN[which(v$Date==max(V$date))]
          v$etaN[which(v$Date>max(V$date))]<-v$etaN[which(v$Date==max(V$date))]
          v$kappaN[which(v$Date>max(V$date))]<-v$kappaN[which(v$Date==max(V$date))]
          v$baseN[which(v$Date>max(V$date))]<-v$baseN[which(v$Date>max(V$date))]-
            v$alphaN[which(v$Date==max(V$date))]-v$betaN[which(v$Date==max(V$date))]-
            v$gammaN[which(v$Date==max(V$date))]-v$etaN[which(v$Date==max(V$date))]-
            v$kappaN[which(v$Date==max(V$date))]-v$deltaN[which(v$Date==max(V$date))]
        }
      }
      m <- v[complete.cases(v),]
      print(paste(unique(m$location),"has been processed"))
      return(m)
    }else{return(NULL)}
  })
  data<-do.call(rbind,list)
  return(data)
}
vaccine_ratio_cal<-function(Vman,V1){
  Vman$date<-as.Date(Vman$date)
  V1$Date<-as.Date(V1$Date)
  V1<-V1[,1:4]
  V1$total_vaccinations[is.na(V1$total_vaccinations)]<-0
  colnames(Vman)<-c("location","Date","vaccine","total_vaccinations")
  list<-lapply(split(Vman,Vman$location),FUN = function(v){
    vac<-subset(V1,V1$location==unique(v$location))
    vac$total_vaccinations<-cummax(vac$total_vaccinations)
    if (nrow(vac)>0){
      vac$'Johnson&Johnson'<-as.numeric(0)
      vac$'Moderna'<-as.numeric(0)
      vac$'Oxford/AstraZeneca'<-as.numeric(0)
      vac$'Pfizer/BioNTech'<-as.numeric(0)
      vac$'Sinovac'<-as.numeric(0)
      vac$'CanSino'<-as.numeric(0)
      vac$'Sputnik V'<-as.numeric(0)
      vac$'Sinopharm/Beijing'<-as.numeric(0)
      datelist<-unique(v$Date)
      for (i in seq(1,length(datelist))){
        l<-subset(v,v$Date==datelist[i])
        if(datelist[i]>=min(vac$Date)&datelist[i]<=max(vac$Date)){
          name<-unique(l$vaccine)
          total<-sum(l$total_vaccinations)
          for(k in 1:length(name)){
            if(i==1){
              if(total>0){vac[which(vac$Date>=min(vac$Date)&vac$Date<datelist[i]),name[k]]<-
                round(as.numeric(l$total_vaccinations[which(l$vaccine==name[k])])/total,2)}else{
                  vac[which(vac$Date>=min(vac$Date)&vac$Date<datelist[i]),name[k]]<-0
                }
            }else{
              vac[which(vac$Date>=datelist[i-1]&vac$Date<datelist[i]),name[k]]<-
                round(as.numeric(l$total_vaccinations[which(l$vaccine==name[k])])/total,2)}
          }
        }
      }
      print(paste(unique(v$location),"has been processed"))
      return(vac)
    }
    return(NULL)
  })
  list2<-lapply(c("United Kingdom","Israel"), function(i){
    vac<-subset(V1,V1$location==i)
    vac$total_vaccinations<-cummax(vac$total_vaccinations)
    vac$Date<-as.Date(vac$Date)
    if (nrow(vac)>0){
      vac$'Johnson&Johnson'<-as.numeric(0)
      vac$'Moderna'<-as.numeric(0)
      vac$'Oxford/AstraZeneca'<-as.numeric(0)
      vac$'Pfizer/BioNTech'<-as.numeric(0)
      vac$'Sinovac'<-as.numeric(0)
      vac$'CanSino'<-as.numeric(0)
      vac$'Sputnik V'<-as.numeric(0)
      vac$'Sinopharm/Beijing'<-as.numeric(0)
      if(i=="United Kingdom"){
        vac$Moderna[which(vac$Date>="2021-04-07")]<-17/157
        vac$`Oxford/AstraZeneca`[which(vac$Date>="2021-04-07")]<-100/157
        vac$`Oxford/AstraZeneca`[which(vac$Date<"2021-04-07")]<-100/140
        vac$`Pfizer/BioNTech`[which(vac$Date>="2021-04-07")]<-40/157
        vac$`Pfizer/BioNTech`[which(vac$Date<"2021-04-07")]<-40/140
      }else{
        vac$`Pfizer/BioNTech`<-1
      }
    return(vac)
    }
  })
  data<-do.call(rbind,c(list,list2))[,-3]
  return(data)
}
pop_age_calculate<-function(agedata){
  age<-read.csv(agedata,stringsAsFactors = F)
  aa<-do.call(rbind,lapply(split(age,age$Country.or.Area),FUN=function(a){
    if(length(unique(a$Source.Year))>1){
      a<-a[!duplicated(a$Age), ]
    }
    total<-a$Value[which(a$Age=="Total")]
    a$Age<-as.numeric(a$Age)
    age0_17<-sum(a$Value[which(a$Age<18)])
    age18_60<-sum(a$Value[which(a$Age>=18&a$Age<60)])
    age60up<-sum(a$Value[which(a$Age>=60)])
    d<-as.data.frame(do.call(cbind,list(unique(a$Country.or.Area))))
    d$age0_17<-round(age0_17/total,2)
    d$age18_60<-round(age18_60/total,2)
    d$age60up<-round(age60up/total,2)
    return(d)
  }))
  return(aa)
}
CI95lowfun<-function(data){
  if(sd(data)>0){
    k<-t.test(data)$conf.int[1]
  }else{k<-0}
  return(k)
}
CI95highfun<-function(data){
  if(sd(data)>0){
    k<-t.test(data)$conf.int[2]
  }else{k<-0}
  return(k)
}
RatioVariable_merge<-function(Dataset,vaccine_effect,variant_tran,list){
  effect<-read.csv(vaccine_effect,stringsAsFactors = F)
  vv<-read.csv(variant_tran,stringsAsFactors = F)
  effect<-effect[,c(1:4)]
  effect[,2:ncol(effect)]<-effect[,2:ncol(effect)]/100
  effect_mean<-effect[,c("base")]
  effect_sd<-approx_sd(effect$IQR.,effect$IQR..1)
  V_SARS_CoV_2<-vector()
  for(j in 1:8){
    V_SARS_CoV_2[j]<-rnorm(1,effect_mean[j],effect_sd[j])
  }
  Dataset$Fully_vaccinated_effect<-Dataset$Fully_vaccinated_pre*
    (Dataset[,21]*V_SARS_CoV_2[1]+Dataset[,22]*V_SARS_CoV_2[2]+
     Dataset[,23]*V_SARS_CoV_2[3]+Dataset[,24]*V_SARS_CoV_2[4]+
     Dataset[,25]*V_SARS_CoV_2[5]+Dataset[,26]*V_SARS_CoV_2[6]+
     Dataset[,27]*V_SARS_CoV_2[7]+Dataset[,28]*V_SARS_CoV_2[8])
  return(Dataset)
}

select_data<-function(school_holiday){
  SH<-read.csv(school_holiday, stringsAsFactors = FALSE)
  SH<-subset(SH,SH$Year>=2019)
  SH$Date<-as.Date(SH$Date)+365
  SH<-SH[,c(1:3,13)]
  new<-SH
  new$Date<-as.Date(new$Date)+365
  SH<-do.call(rbind,list(SH,new))
  colnames(SH)<-c("iso_code","Date","CountryName","Holiday")
  return(SH)
}
COR<-function(N){
  p1<-quickcor(N, cor.test = TRUE)+geom_star(data = get_data(type = "upper" ,show.diag = FALSE))+
    geom_mark(data = get_data(type = "lower", show.diag = FALSE),size=2.5)+
    geom_abline(size=0.5,slope=-1,intercept =8)+
    scale_fill_gradient2(midpoint = 0, low = "#00498d", mid = "white", high = "#74230a",space="Lab")+
    theme(legend.position = "right",
          legend.text = element_text(color="black",size=unit(9, "pt")),
          legend.title = element_text(color="black",size=unit(9, "pt")),
          legend.key.height=unit(10,'mm'),
          legend.key.width=unit(2,'mm'),
          axis.text = element_text(color="black",size=unit(9, "pt")))
  return(p1)
  #ggsave("picture/cor.pdf",p1,width=200,height=200,units="mm",device = cairo_pdf)
}
Npidataset<-function(NPI){
  SH<-select_data(school_holiday)
  N<-read.csv(NPI,stringsAsFactors = F)
  N[is.na(N)]<-0
  N<-N[-which(N$RegionName>0),]
  N<-N[,c("CountryName","CountryCode","Date",
          "C1_School.closing","C2_Workplace.closing","C3_Cancel.public.events",
          "C4_Restrictions.on.gatherings","C5_Close.public.transport",
          "C6_Stay.at.home.requirements","C7_Restrictions.on.internal.movement",
          "C8_International.travel.controls", "H6_Facial.Coverings","StringencyIndex")]
  colnames(N)<-c("location","iso_code","Date",
                 "School closure",
                 "Workplace closure",
                 "Public events closure",
                 "Gathering restrictions",
                 "Public transport closure",
                 "Stay-at-home order",
                 "Internal movement restrictions",
                 "International travel controls",
                 "Facial covering","StringencyIndex")
  N$Date<-as.Date.character(N$Date,format="%Y%m%d")
  return(N)
}

merge_dataset<-function(RT,Variants,Vaccination,NPI,POP,index,Env){
  #pop_age<-pop_age_calculate(agedata)
  Var<-variant_add(RT,Variants)
  N<-Npidataset(NPI)
  P<-read.csv(POP,stringsAsFactors = F)
  I<-read.csv(index,stringsAsFactors = F)
  I$aging<-as.numeric(sub("%","",I$aging))
  E<-read.csv(Env,stringsAsFactors = F)
  colnames(E)<-c("iso_code","Date","Hum","Tem")
  E$Date<-as.Date(E$Date)
  V1<-Vaccination_complementation(Vaccination)
  V<-V1[,c(1,2,3,5,6)]
  colnames(V)<-c("Date","location","iso_code","vaccinated","fully_vaccinated")
  V$Date<-as.Date(V$Date)
  Vman<-read.csv(Vaccman,stringsAsFactors = F)
  vaccine_ratio<-vaccine_ratio_cal(Vman,V1)
  Dataset<-do.call(rbind,lapply(split(Var,Var$iso_code),FUN=function(r){
    vac_ratio<-subset(vaccine_ratio,vaccine_ratio$location==unique(r$location))[,-c(2,3)]
    npi<-subset(N,N$iso_code==unique(r$iso_code))[,-c(1:2)]
    e<-subset(E,E$iso_code==unique(r$iso_code))[,-1]
    v<-subset(V,V$iso_code==unique(r$iso_code))[,-c(2,3)]
    v[is.na(v)]<-0
    v$vaccinated<-cummax(v$vaccinated)
    v$fully_vaccinated<-cummax(v$fully_vaccinated)
    if(min(c(nrow(vac_ratio), nrow(r), nrow(npi), nrow(e),nrow(v)))>0){
      r$POP<-P$T_pop_2020[which(P$iso3c==unique(r$iso_code))]
      r$Popdensity<-I$popdensity[which(I$iso3c==unique(r$iso_code))]
      r$HealthIndex<-I$Health_index[which(I$iso3c==unique(r$iso_code))]
      r$Aging<-I$aging[which(I$iso3c==unique(r$iso_code))]
      r<-merge(r,e,by="Date")
      r<-merge(r,vac_ratio,by="Date",all=T)
      r[is.na(r)]<-0
      r<-merge(r,npi,by="Date")
      r<-merge(r,v,by="Date",all=T)
      r<-r[0:which(r$Date==max(r$Date[which(r$vaccinated!=0)])),]
      r[is.na(r)]<-0
      r$Vaccinated_pre<-r$vaccinated/r$POP
      r$Fully_vaccinated_pre<-r$fully_vaccinated/r$POP
      r<-subset(r,r$iso_code!=0)
      r$Total_cases_per<-r$Total_cases/r$POP
      #r$Total_cases_per<-0
      #r$Total_cases_per[15:nrow(r)]<- r$Total_cases[0:(nrow(r)-14)]/r$POP[1]
      return(r)
    }
  }))
  Dataset$StringencyIndex<-Dataset$StringencyIndex/100
  return(Dataset)
}

Leave_one_out_Validation<-function(Datapath,outpath,mcon,xname){
  DatasetV2<-read.csv(paste0(Datapath,"/R0_Europe_dataset_1220withinR0.csv"),stringsAsFactors = F)
  lapply(unique(DatasetV2$location),function(x){
    D<-subset(DatasetV2,DatasetV2$location!=x)
    out<-paste0(outpath,"/all_without_",x,".rds")
    start<-as.Date("2020-08-01")
    end<-as.Date("2021-10-26")
    fit<-alpha_calculate_withinR0_all(mcon,D,start,end,out,xname,monthnum=15)
    gc()
    print(paste("Validation without",x,"has been processed"))
  })
}

R0calculate_withineachcountry<-function(DatasetV2,source,mcon,xname,monthnum){
  if (dir.exists(source)==F){dir.create(source)
  }else{print("This path has been exists")}
  lapply(split(DatasetV2,DatasetV2$iso_code),FUN=function(v){
    out<-paste0(source,unique(v$location),"_withinR0/")
    if (dir.exists(out)==F){dir.create(out)
    }else{print("This path has been exists")}
    output<-paste0(out,"all.rds")
    start<-as.Date("2020-08-01")
    end<-as.Date("2021-10-26")
    fit<-alpha_calculate_withinR0_con(mcon,v,start,end,output,xname,monthnum)
    gc()
    print(paste0(unique(v$location),start,"has been processed"))
  })
}
R0process<-function(RT,Variants,Vaccination,NPI,POP,index,Env,
                    vaccine_effect,variant_tran,i,outpath,
                    mcon,xname,monthnum){
  Dataset<-merge_dataset(RT,Variants,Vaccination,NPI,POP,index,Env)
  Dataset<-subset(Dataset,Dataset$continent=="Europe"|Dataset$location=="Israel")
  gc()
  DatasetV2<-RatioVariable_merge(Dataset,vaccine_effect,variant_tran,list=c(1:length(unique(Dataset$location))))
  if (length(xname)>2){
    DatasetV2$Interaction<-DatasetV2[,xname[1]]*DatasetV2[,xname[2]]
  }
  write.csv(DatasetV2,paste0(outpath,"/Europe_dataset_1220withinR0.csv"),row.names = F)
  R0calculate_withineachcountry(DatasetV2,source=paste0(outpath,"/R0_calculate/"),mcon,xname,monthnum)
}
R0extract<-function(path){
  conlist<-list.files(path)
  datapath<-list.files(strsplit(path,"/")[[1]][1],".csv")
  Da<-read.csv(paste0(strsplit(path,"/")[[1]][1],"/",datapath),stringsAsFactors = F)
  condata<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(Da,Da$location==strsplit(c,"_")[[1]][1])
    k<-subset(k,k$Date>="2020-08-01"&k$Date<"2021-10-26")
    f<-readRDS(paste0(path,"/",c,"/all.rds"))
    R0<-as.data.frame(rstan::extract(f)$R0)
    colnames(R0)<-k$Date
    R0d<-mcmc_intervals_data(R0,prob = .5,prob_outer= .95,point_est="mean")
    k<-k[order(k$Date),]
    R0d<-R0d[order(R0d$parameter),]
    k$R0<-R0d$m
    k$R0_CI95low<-R0d$ll
    k$R0_CI95high<-R0d$hh
    k$R0_sd<-apply(R0,2,sd)
    return(k)
  }))
  write.csv(condata,paste0(strsplit(path,"/")[[1]][1],"/R0_",datapath))
  return(condata)
}

counresultplot<-function(DatasetV2,path,outname,xname,outpath){
  DatasetV2$Date<-as.Date(DatasetV2$Date)
  efdata<-list()
  conlist<-list.files(path)
  condata<-lapply(conlist,function(c){
    DD<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    DD$Tem<-(DD$Tem-min(DD$Tem))/(max(DD$Tem)-min(DD$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(DD,DD$Date>=start&DD$Date<(end+1))
      X<-as.data.frame(do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      })))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      for (k in c(xname,"Air Temperature","Epslion")){
        pars[,k]<- pars[,k]*X[,k]}
      pars$all_SI<-pars$StringencyIndex+pars$Interaction
      pars$all_V<-pars$Fully_vaccinated_effect+pars$Interaction
      #write.csv(pars,paste0("sensitivity_analysis/",outname,"_",c,"_",start,".csv"),row.names = F)
      pars$all<-apply(pars,1,sum)
      pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
      pars<-(1-exp(-pars))*100
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="mean")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      pard$strength[which(pard$parameter=="all_SI")]<-X[,"StringencyIndex"]
      pard$strength[which(pard$parameter=="all_V")]<-X[,"Fully_vaccinated_effect"]
      return(pard)
    }))
    return(d)
  })
  c<-do.call(rbind,condata)
  write.csv(c,paste0(outpath,"/SI_country_",outname,".csv"),row.names = F)
  plot<-lapply(condata,function(r){
    rg<-subset(r,r$parameter=="Fully_vaccinated_effect"|r$parameter=="StringencyIndex"|r$parameter=="Interaction")
    rg$start[which(rg$parameter=="Fully_vaccinated_effect")]<-rg$start[which(rg$parameter=="Fully_vaccinated_effect")]+10
    rg$start[which(rg$parameter=="Interaction")]<-rg$start[which(rg$parameter=="Interaction")]+20
    g<-ggplot(data=rg)+
      geom_bar(aes(x=as.Date(start),y=strength*100,fill=parameter),stat="identity",
               position=position_dodge(width=0),alpha=0.2,width=8,size=0.1)+
      geom_xspline(aes(x=as.Date(start),y=m,color=parameter),size=0.1)+
      theme_clean()+
      geom_errorbar(mapping = aes_(ymin =~l, ymax=~h, x=~as.Date(start),color= ~parameter),
                    show.legend = T,alpha=0.7,width=8,
                    size=0.5)+
      geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1)+
      scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                   breaks=("4 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
      scale_shape_manual(values = c(21,24,4))+
      scale_color_manual(values=c("#0b5c9e","#880208","#80581d"))+
      scale_fill_manual(values=c("#0b5c9e","#880208","#80581d"))+
      scale_size_continuous(breaks=c(0,0.2,0.4,0.6,0.8,1.0))+
      scale_y_continuous(limits=c(-10,100),breaks=c(0,25,50,75,100),expand=c(0,0))+
      labs(y =paste0("Reduction in Rt","(%)"),x = NULL,title=unique(rg$country))+
      guides(color=guide_legend(nrow=1,byrow=TRUE))+
      theme(legend.position = "",
            panel.grid.major = element_line(colour = "white"),
            panel.grid.minor = element_line(colour = "white"),
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
            axis.title.x= element_text(color="black",size = unit(9, "pt")),
            axis.text.x = element_text(color="black",size = unit(9, "pt")),
            axis.title.y= element_blank(),
            axis.text.y = element_blank(),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.border= element_rect(color=NA,fill=NA),
            panel.background=element_rect(fill = "transparent",colour = NA))
    return(g)
  })
  for(i in 1:length(plot)){
    if(i%%2==1){
      plot[[i]]<-plot[[i]]+theme(axis.ticks.y=element_line(color="black"),
                                 axis.title.y= element_text(color="black",angle=90,size = unit(9, "pt")),
                                 axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")))}
  }
  legend<-plot[[1]]+guides(color=guide_legend(ncol=1))+
    theme(legend.position = "right",legend.title=element_blank(),
          legend.text = element_text(size = unit(9, "pt")),
          legend.background = element_rect(fill=NA,color=NA),
          legend.key=element_rect(fill="transparent"))
  plot[[32]]<-g_legend(legend)
  for (i in seq(1,32,2)){
    pl<-grid.arrange(plot[[i]],plot[[i+1]],ncol =2)
    ggsave(paste0(outpath,"/",outname,i,".pdf"),pl,units="mm",width=140,height=50,device = cairo_pdf)
    ggsave(paste0(outpath,"/",outname,i,".png"),pl,units="mm",width=140,height=50)
  }
  
  dev.off()
  pod<-subset(c,c$parameter=="Fully_vaccinated_pre")
  po<-ggplot(data=pod)+geom_point(aes(x=strength*100,y=m),size=0.6)+ theme_clean()+
    scale_y_continuous(limits=c(0,50),breaks=c(0,10,20,30,40,50),expand=c(0.1,0.1))+
    labs(y =paste0("Reduction in Rt","(%)"),x = "Vaccinated rate")+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "",
          panel.grid.major = element_line(colour = "white"),
          panel.grid.minor = element_line(colour = "white"),
          legend.title=element_blank(),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/vaccination_",outname,".pdf"),po,units="mm",width=100,height=80,device = cairo_pdf)
  
}
R0plot<-function(DatasetV2,outname,outpath){
  DatasetV2$Date<-as.Date(DatasetV2$Date)
  plot<-lapply(split(DatasetV2,DatasetV2$iso_code),function(r){
    rg<-r[,c("Date","R0","Rt")]
    rg<-melt(rg,id="Date")
    g<-ggplot()+
      geom_errorbar(data=r,mapping = aes_(ymin =~R0_CI95low, ymax=~R0_CI95high, x=~as.Date(Date)),color="grey80",
                    show.legend = T,alpha=0.9,width=1,size=0.2, position =  position_dodge(width=0.2))+
      geom_xspline(data=rg,aes(x=as.Date(Date),y=value,color=variable))+
      theme_clean()+
      geom_point(data=rg,aes(x=as.Date(Date),y=value,color=variable),size=0.5,shape=12)+
      #geom_smooth(aes(x=as.Date(start),y=real),span=0.4,color="#8d8e96",linetype = "dashed")+
      scale_x_date(limits=as.Date(c("2020-07-15","2021-10-25")),
                   breaks=("4 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
      scale_y_continuous(limits=c(0,6),breaks=c(0,1,2,3),expand=c(0,0))+
      scale_color_manual(values=c("#a18f72","#723f39","#7f97bd"))+
      scale_fill_manual(values=c("#a18f72","#723f39","#7f97bd"))+
      labs(y ="Rt",x = NULL,title=unique(r$location))+
      guides(color=guide_legend(nrow=1,byrow=TRUE))+
      theme(legend.position = "",
            panel.grid.major = element_line(colour = "white"),
            panel.grid.minor = element_line(colour = "white"),
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_blank(),
            axis.title.y= element_blank(),
            axis.text.y = element_blank(),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    return(g)
  })
  for(i in 1:length(plot)){
    if(i%%4==1){
      plot[[i]]<-plot[[i]]+theme(axis.ticks.y=element_line(color="black"),
                                 axis.title.y= element_text(color="black",angle=90,size = unit(9, "pt")),
                                 axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")))}
    if(i>27){
      plot[[i]]<-plot[[i]]+theme(axis.title.x= element_text(color="black",size = unit(9, "pt")),
                                 axis.text.x = element_text(color="black",size = unit(9, "pt")))}
  }
  legend<-plot[[1]]+theme(legend.position = "bottom",
                          legend.title=element_blank(),
                          legend.text = element_text(size = unit(9, "pt")),
                          legend.key.height=unit(0.2,'cm'),
                          legend.key.width=unit(1,'cm'),
                          legend.background = element_rect(fill="transparent"),
                          legend.key=element_rect(fill="transparent"))
  mylegend<-g_legend(legend)
  plot<-grid.arrange(mylegend,arrangeGrob(grobs =plot,ncol =4,widths=c(2.8,2.5,2.5,2.5)),heights = c(0.5,10))
  ggsave(paste0(outpath,"/R0_",outname,".pdf"),plot,units="mm",width=240,height=320,device = cairo_pdf)
  dev.off()
}
meta_alalysis<-function(DatasetV2,path,outname,xname,outpath){
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      for (k in c(xname,"Air Temperature","Epslion")){
        pars[,k]<- pars[,k]*X[,k]}
      pars$all<-apply(pars,1,sum)
      pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
      pars<-(1-exp(-pars))*100
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$start),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(start=f$start[1],par="R0",
                  strength=NA,
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
    #air temperature
    sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
    si<-summary(sia)$random
    weight<-sia$w.random/sum(sia$w.random)
    t<-data.frame(start=f$start[1],par="Air Temperature",
                  strength=mean(f$strength_Tem),
                  m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight))
    #Epslion
    sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
    si<-summary(sie)$random
    weight<-sie$w.random/sum(sie$w.random)
    e<-data.frame(start=f$start[1],par="Epslion",
                  strength=1,
                  m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight))
    
    if(max(f$median_SI)>0){
      ds<-subset(f,f$mean_SI>0)
      sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
      si<-summary(sim)$random
      weight<-sim$w.random/sum(sim$w.random)
      s<-data.frame(start=f$start[1],par="Stringency Index",
                    strength=mean(f$strength_SI),
                    m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight))
    }else{s<-NULL}
    if(is.null(f$mean_V)==F){
      if(max(f$mean_V)>0){
        dv<-subset(f,f$mean_V>0)
        vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        v<-data.frame(start=dv$start[1],par="Vaccination",
                      strength=mean(dv$strength_V),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{v<-NULL}
      if(max(f$median_Int)>0){
        dI<-subset(f,f$median_Int>0)
        vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab=dI$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                      strength=mean(dI$strength_Int),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{i<-NULL}
      X<-do.call(rbind,list(r,t,e,s,v,i))
    }else{
      X<-do.call(rbind,list(r,t,e,s))
    }
    X$Rt<-mean(f$Rt)   #Rt
    return(X)
    print(paste0(unique(f$start),"has been processed"))
  }))
  all<-do.call(rbind,lapply(split(d1,d1$start),function(x){
    x1<-subset(x,x$par!="R0")
    x1$m<- -log(1-x1$m/100)
    x1$lower<- -log(1-x1$lower/100)
    x1$upper<- -log(1-x1$upper/100)
    all1<-data.frame(start=unique(x1$start),par="all",
                     strength=NA,
                     m=(1-exp(-sum(x1$m)))*100,lower=(1-exp(-sum(x1$lower)))*100,upper=(1-exp(-sum(x1$upper)))*100)
    all2<-data.frame(start=unique(x1$start),par="all_SI&V",
                     strength=NA,
                     m=(1-exp(-sum(x1$m[which(x1$par!="Air Temperature"&x1$par!="Epslion")])))*100,
                     lower=(1-exp(-sum(x1$lower[which(x1$par!="Air Temperature"&x1$par!="Epslion")])))*100,
                     upper=(1-exp(-sum(x1$upper[which(x1$par!="Air Temperature"&x1$par!="Epslion")])))*100)
    all3<-data.frame(start=unique(x1$start),par="all_SI",
                     strength=NA,
                     m=(1-exp(-sum(x1$m[which(x1$par=="Stringency Index"|
                                                x1$par=="Interaction of SI and Vaccination")])))*100,
                     lower=(1-exp(-sum(x1$lower[which(x1$par=="Stringency Index"|
                                                        x1$par=="Interaction of SI and Vaccination")])))*100,
                     upper=(1-exp(-sum(x1$upper[which(x1$par=="Stringency Index"|
                                                        x1$par=="Interaction of SI and Vaccination")])))*100)
    all4<-data.frame(start=unique(x1$start),par="all_V",
                     strength=NA,
                     m=(1-exp(-sum(x1$m[which(x1$par=="Vaccination"|
                                                x1$par=="Interaction of SI and Vaccination")])))*100,
                     lower=(1-exp(-sum(x1$lower[which(x1$par=="Vaccination"|
                                                        x1$par=="Interaction of SI and Vaccination")])))*100,
                     upper=(1-exp(-sum(x1$upper[which(x1$par=="Vaccination"|
                                                        x1$par=="Interaction of SI and Vaccination")])))*100)
    all<-do.call(rbind,list(all1,all2,all3,all4))
    all$Rt<-unique(x1$Rt)
    return(all)}))
  meta<-do.call(rbind,list(d1,all))
  write.csv(meta,paste0(outpath,"/Meta_",outname,".csv"),row.names = F)
  #write.csv(eachC,paste0("picture/countryresult_result_",outname,".csv"),row.names = F)
  d2<-subset(meta,meta$par=="Stringency Index"|meta$par=="Vaccination"|meta$par=="Interaction of SI and Vaccination"|
               meta$par=="all_SI&V"|meta$par=="all_SI"|meta$par=="all_V")
  d2$shape<-"Individual"
  d2$shape[which(d2$par=="all_SI"|d2$par=="all_V")]<-"Combined"
  d2$parameter<-"NPIs"
  d2$parameter[which(d2$par=="Vaccination"|d2$par=="all_V")]<-"Vaccination"
  d2$parameter[which(d2$par=="Interaction of SI and Vaccination")]<-"Interaction"
  d2$parameter[which(d2$par=="all_SI&V")]<-"Combined effect of NPIs and vaccination"
  Sys.setlocale("LC_TIME","English")
  d2$start[which(d2$parameter=="NPIs")]<-d2$start[which(d2$parameter=="NPIs")]+10
  d2$start[which(d2$parameter=="Vaccination")]<-d2$start[which(d2$parameter=="Vaccination")]+20
  g<-ggplot(data=d2)+
    geom_xspline(aes(x=as.Date(start),y=m,color=parameter,linetype=shape),size=0.2)+
    #geom_col(aes(x=as.Date(start),y=strength*100,fill=par),alpha=0.1)
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~parameter),
                  show.legend = T,width=6,size=0.2,alpha=0.3)+
    #position =  position_dodge(width=0.2))+
    geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1.2)+
    #geom_smooth(aes(x=as.Date(start),y=real),span=0.4,color="#8d8e96",linetype = "dashed")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    #602029��ɫ 606bbc��ɫ 4c753��ɫ dda203��ɫ
    scale_linetype_manual(values = c("dashed","solid"))+
    scale_shape_manual(values = c(15,4,21,24))+
    scale_color_manual(values=c("black","#80581d","#0b5c9e","#880208"))+
    scale_fill_manual(values=c("black","#80581d","#0b5c9e","#880208"))+
    scale_y_continuous(limits=c(0,65),breaks=c(0,20,40,60),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_mainpar_",outname,".pdf"),g,units="mm",width=140,height=90,device = cairo_pdf)
  ##############fig 2#######################
  d2<-subset(meta,meta$par=="all_SI&V"|meta$par=="all_SI"|meta$par=="all_V")
  d2$parameter<-"NPIs"
  d2$parameter[which(d2$par=="all_V")]<-"Vaccination"
  d2$parameter[which(d2$par=="all_SI&V")]<-"Combined effect of NPIs and vaccination"
  Sys.setlocale("LC_TIME","English")
  d2$start[which(d2$parameter=="NPIs")]<-d2$start[which(d2$parameter=="NPIs")]+10
  d2$start[which(d2$parameter=="Vaccination")]<-d2$start[which(d2$parameter=="Vaccination")]+20
  g1<-ggplot(data=d2)+
    geom_xspline(aes(x=as.Date(start),y=m,color=parameter),size=0.2)+
    #geom_col(aes(x=as.Date(start),y=strength*100,fill=par),alpha=0.1)
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~parameter),
                  show.legend = T,width=6,size=0.2,alpha=0.3)+
    #position =  position_dodge(width=0.2))+
    geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1.2)+
    #geom_smooth(aes(x=as.Date(start),y=real),span=0.4,color="#8d8e96",linetype = "dashed")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    #602029��ɫ 606bbc��ɫ 4c753��ɫ dda203��ɫ
    scale_shape_manual(values = c(15,21,24))+
    scale_color_manual(values=c("black","#0b5c9e","#880208"))+
    scale_fill_manual(values=c("black","#0b5c9e","#880208"))+
    scale_y_continuous(limits=c(0,65),breaks=c(0,20,40,60),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_mainpar_fig2_",outname,".pdf"),g1,units="mm",width=140,height=90,device = cairo_pdf)
  
  #########fig 3 subfigure############
  d2<-subset(meta,meta$par=="Stringency Index"|meta$par=="Vaccination"|meta$par=="Interaction of SI and Vaccination")
  d2$parameter<-"NPIs"
  d2$parameter[which(d2$par=="Vaccination")]<-"Vaccination"
  d2$parameter[which(d2$par=="Interaction of SI and Vaccination")]<-"Interaction of NPIs and Vaccination"
  Sys.setlocale("LC_TIME","English")
  d2$start[which(d2$parameter=="NPIs")]<-d2$start[which(d2$parameter=="NPIs")]+10
  d2$start[which(d2$parameter=="Vaccination")]<-d2$start[which(d2$parameter=="Vaccination")]+20
  g2<-ggplot(data=d2)+
    geom_xspline(aes(x=as.Date(start),y=m,color=parameter),size=0.2)+
    #geom_col(aes(x=as.Date(start),y=strength*100,fill=par),alpha=0.1)
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~parameter),
                  show.legend = T,width=6,size=0.2,alpha=0.3)+
    geom_point(aes(x=as.Date(start),y=m,color=parameter,shape=parameter),size=1.2)+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_shape_manual(values = c(4,21,24))+
    scale_color_manual(values=c("#a06f24","#0b5c9e","#880208"))+
    scale_fill_manual(values=c("#a06f24","#0b5c9e","#880208"))+
    scale_y_continuous(limits=c(0,60),breaks=c(0,10,20,30,40,50),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  #ggsave(paste0("picture/",outname,".png"),g,units="mm",width=160,height=120)
  ggsave(paste0(outpath,"/Meta_mainpar_fig3_",outname,".pdf"),g2,units="mm",width=75,height=90,device = cairo_pdf)
  dev.off()
  
  d3<-subset(meta,meta$par=="Air Temperature")
  d3$start<-d3$start+15
  g3<-ggplot(data=d3)+
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~par),
                  show.legend = T,width=6,size=0.2,alpha=0.5)+
    geom_xspline(aes(x=as.Date(start),y=m,color=par),size=0.2)+
    geom_point(aes(x=as.Date(start),y=m),shape=12,size=1.2,color="#080e12")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_color_manual(values=c("#2b343d"))+
    scale_fill_manual(values=c("#2b343d"))+
    scale_y_continuous(limits=c(-20,20),breaks=c(-10,0,10),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "top",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_unseenFactors_tem_",outname,".pdf"),g3,units="mm",width=140,height=90,device = cairo_pdf)
  
  
  d3<-subset(meta,meta$par=="Epslion")
  d3$start<-d3$start+15
  g3<-ggplot(data=d3)+
    theme_clean()+
    geom_errorbar(mapping = aes_(ymin =~lower, ymax=~upper, x=~as.Date(start),
                                 color= ~par),
                  show.legend = T,width=6,size=0.2,alpha=0.5)+
    geom_xspline(aes(x=as.Date(start),y=m,color=par),size=0.2)+
    geom_point(aes(x=as.Date(start),y=m),shape=12,size=1.2,color="#080e12")+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_color_manual(values=c("#4c5b6b"))+
    scale_fill_manual(values=c("#4c5b6b"))+
    scale_y_continuous(limits=c(-15,35),breaks=c(-10,0,10,20,30),expand=c(0,0))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = NULL)+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "top",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Meta_unseenFactors_e_",outname,".pdf"),g3,units="mm",width=140,height=90,device = cairo_pdf)
  
  pod<-subset(meta,meta$par=="Vaccination"|meta$par=="all_V")
  pod<-subset(pod,pod$m!=0)
  pod$strength[which(pod$par=="all_V")]<-pod$strength[which(pod$par=="Vaccination")]
  po<-ggplot(data=pod)+geom_point(aes(x=strength*100,y=m,color=par),size=1,shape=21)+ theme_clean()+
    scale_y_continuous(limits=c(0,40),breaks=c(0,10,20,30,40),expand=c(0.01,0))+
    scale_color_manual(values=c("#a6a07d","#69491A"))+
    labs(y =expression("\u0394"*R[t]*"(%)"),x = "Practical vaccination rate")+
    guides(color=guide_legend(nrow=1,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "white"),
          panel.grid.minor = element_line(colour = "white"),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9, "pt")),
          legend.title=element_blank(),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/vaccination_meta_",outname,".pdf"),po,units="mm",width=75,height=90,device = cairo_pdf)
  dev.off()
}
meta_R0<-function(DatasetV2,path,outname,outpath){
  efdata<-list()
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    d<-do.call(rbind,lapply(split(k,k$Date),function(i){
      data<-data.frame(n=1,sd_R0=i$R0_sd,mean_R0=i$R0,
                       q1_R0=i$R0_CI95low,q3_R0=i$R0_CI95high,
                       country=strsplit(c,"_")[[1]][1],Date=unique(i$Date),
                       Rt=i$Rt)
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$Date),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(Date=unique(f$Date),par="R0",
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
    r$Rt<-mean(f$Rt)   #Rt
    return(r)
    print(paste0(unique(f$Date),"has been processed"))
  }))
  write.csv(d1,paste0(outpath,"/R0_meta_",outname,".csv"),row.names = F)
  #write.csv(eachC,paste0("picture/countryresult_result_",outname,".csv"),row.names = F)
  g<-ggplot(data=d1)+
    geom_ribbon(aes(x=as.Date(Date),ymin=lower,ymax=upper),fill="grey93",alpha=0.7)+
    geom_ribbon(aes(x=as.Date(Date),ymin=Rt,ymax=m),fill="#A8D8CD",alpha=0.4)+
    geom_line(aes(x=as.Date(Date),y=Rt),size=0.2,color="#377375")+
    geom_line(aes(x=as.Date(Date),y=m),size=0.2,linetype="dashed",color="#2A484E")+
    theme_clean()+
    scale_x_date(limits=as.Date(c("2020-07-15","2021-10-30")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
    scale_y_continuous(limits=c(0.5,4),breaks=c(1,2,3),expand=c(0,0))+
    labs(y =expression("Observed variation of"*"  "*R["0,t"]),x = NULL)+
    guides(color=guide_legend(nrow=2,byrow=TRUE))+
    theme(legend.position = "bottom",
          panel.grid.major = element_line(colour = "transparent"),
          panel.grid.minor = element_line(colour = "transparent"),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = 10),
          axis.title.x= element_blank(),
          axis.text.x = element_text(color="black",hjust=0.5,size = 10),
          axis.title.y= element_text(color="black",size = 10),
          axis.text.y= element_text(color="black",hjust=1,size = 10),
          plot.margin=unit(c(0.2,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  #ggsave(paste0("picture/",outname,".png"),g,units="mm",width=160,height=120)
  ggsave(paste0(outpath,"/",outname,"_R0.pdf"),g,units="mm",width=140,height=50,device = cairo_pdf)
  dev.off()
}
country_coefficient<-function(DatasetV2,path,outname,xname,outpath){
  DatasetV2$Date<-as.Date(DatasetV2$Date)
  efdata<-list()
  conlist<-list.files(path)
  condata<-lapply(conlist,function(c){
    DD<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    DD$Tem<-(DD$Tem-min(DD$Tem))/(max(DD$Tem)-min(DD$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(DD,DD$Date>=start&DD$Date<(end+1))
      X<-as.data.frame(do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      })))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="mean")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      return(pard)
    }))
    return(d)
  })
  c<-do.call(rbind,condata)
  write.csv(c,paste0(outpath,"/Country_cofficient_",outname,".csv"),row.names = F)
}
meta_coefficient<-function(DatasetV2,path,outname,xname,outpath){
  efdata<-list()
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  d1<-do.call(rbind,lapply(split(eachC,eachC$start),function(f){
    #R0
    sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
    si<-summary(sir)$random
    weight<-sir$w.random/sum(sir$w.random)
    r<-data.frame(start=f$start[1],par="R0",
                  strength=NA,
                  m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
    #air temperature
    sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
    si<-summary(sia)$random
    weight<-sia$w.random/sum(sia$w.random)
    t<-data.frame(start=f$start[1],par="Air Temperature",
                  strength=mean(f$strength_Tem),
                  m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight))
    #Epslion
    sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
    si<-summary(sie)$random
    weight<-sie$w.random/sum(sie$w.random)
    e<-data.frame(start=f$start[1],par="Epslion",
                  strength=1,
                  m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight))
    
    if(max(f$mean_SI)>0){
      ds<-subset(f,f$mean_SI>0)
      sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
      si<-summary(sim)$random
      weight<-sim$w.random/sum(sim$w.random)
      s<-data.frame(start=f$start[1],par="Stringency Index",
                    strength=mean(f$strength_SI),
                    m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight))
    }else{s<-NULL}
    if(is.null(f$mean_V)==F){
      if(max(f$mean_V)>0){
        dv<-subset(f,f$mean_V>0)
        vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        v<-data.frame(start=dv$start[1],par="Vaccination",
                      strength=mean(dv$strength_V),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{v<-NULL}
      if(max(f$median_Int)>0){
        dI<-subset(f,f$median_Int>0)
        vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab =  dI$country)
        va<-summary(vm)$random
        weight<-vm$w.random/sum(vm$w.random)
        i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                      strength=mean(dI$strength_Int),
                      m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
      }else{i<-NULL}
      X<-do.call(rbind,list(r,t,e,s,v,i))
    }else{
      X<-do.call(rbind,list(r,t,e,s))
    }
    X$Rt<-mean(f$Rt)   #Rt
    return(X)
    print(paste0(unique(f$start),"has been processed"))
  }))
  write.csv(d1,paste0(outpath,"/Meta_coefficient_",outname,".csv"),row.names = F)
}
g_legend<-function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}
r2<-function(lm){
  pred <- predict(lm)
  n <- length(pred)
  res <- resid(lm)
  w <- weights(lm)
  if (is.null(w)) w <- rep(1, n)
  rss <- sum(w * res ^ 2)
  resp <- pred + res
  center <- weighted.mean(resp, w)
  r.df <- summary(lm)$df[2]
  int.df <- 1
  tss <- sum(w * (resp - center)^2)
  r.sq <- 1 - rss/tss
  adj.r.sq <- 1 - (1 - r.sq) * (n - int.df) / r.df
  return(r.sq)
}
expression_equationV1<-function(lm,m1){
  r.sq<-round(modelr::rsquare(lm, m1),3)
  par<-as.data.frame(summary(lm)$coefficients)
  a<-round(par$Estimate[1],2)
  eq<-substitute(italic(y)==italic(x)^a~","~~italic(r)^2~"="~r2,
                 list(a=format(a),
                      r2=format(r.sq)))
  return(eq)
}
expression_equationV2<-function(lm,m1){
  r.sq<-round(modelr::rsquare(lm, m1),3)
  mse<-
  par<-as.data.frame(summary(lm)$coefficients)
  a<-round(par$Estimate[1],2)
  b<-round(par$Estimate[2],2)
  eq<-substitute(italic(y)==a%.%italic(x)^b~","~~italic(r)^2~"="~r2,
                 list(a=format(a),
                      b=format(b),
                      r2=format(r.sq)))
  return(eq)
}
strengthcalculate<-function(lm_s,effect){
  coff<-as.data.frame(summary(lm_s)$coefficients)
  a<-coff$Estimate
  effect[which(effect<0)]<-0
  strength<-exp(log(effect)/a)
}
"%||%" <- function(a, b) {
  if (!is.null(a)) a else b
}

geom_flat_violin <- function(mapping = NULL, data = NULL, stat = "ydensity",
                             position = "dodge", trim = TRUE, scale = "area",
                             show.legend = NA, inherit.aes = TRUE, ...) {
  layer(
    data = data,
    mapping = mapping,
    stat = stat,
    geom = GeomFlatViolin,
    position = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params = list(
      trim = trim,
      scale = scale,
      ...
    )
  )
}
GeomFlatViolin <-
  ggproto("GeomFlatViolin", Geom,
          setup_data = function(data, params) {
            data$width <- data$width %||%
              params$width %||% (resolution(data$x, FALSE) * 0.9)
            
            # ymin, ymax, xmin, and xmax define the bounding rectangle for each group
            data %>%
              group_by(group) %>%
              mutate(ymin = min(y),
                     ymax = max(y),
                     xmin = x,
                     xmax = x + width / 2)
            
          },
          
          draw_group = function(data, panel_scales, coord) {
            # Find the points for the line to go all the way around
            data <- transform(data, xminv = x,
                              xmaxv = x + violinwidth * (xmax - x)) #����transform����Ϊ���ݿ�mydata��������
            
            newdata <- rbind(plyr::arrange(transform(data, x = xmaxv), -y),plyr::arrange(transform(data, x = xminv), y))
            newdata_Polygon <- rbind(newdata, newdata[1,])
            newdata_Polygon$colour<-NA
            
            newdata_Path <- plyr::arrange(transform(data, x = xmaxv), -y)
            
            ggplot2:::ggname("geom_flat_violin", grobTree(
              GeomPolygon$draw_panel(newdata_Polygon, panel_scales, coord),
              GeomPath$draw_panel(newdata_Path, panel_scales, coord))
            )
          },
          
          draw_key = draw_key_polygon,
          
          default_aes = aes(weight = 1, colour = "grey20", fill = "white", size = 0.5,
                            alpha = NA, linetype = "solid"),
          
          required_aes = c("x", "y")
  )
