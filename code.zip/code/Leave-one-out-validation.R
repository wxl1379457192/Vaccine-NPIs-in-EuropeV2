###Leave one out validation###
library("rstan")
library("bayesplot")
library("zoo")
library("dplyr")
library("reshape2")
library("scales")
library("ggridges")
library("ggthemr")
library("ggcor")
library("ggplot2")
library("gridExtra")
library("ggalt")
library("aomisc")
library("meta")
library("grid")
library("Hmisc")
library("caret")
library("ggthemes")
setwd("E:/COVID19_vacciantion1210")#set up your setwd here
Sys.setlocale("LC_TIME","English")
R2<-function(x,y){
  xm<-mean(x)
  ssres<-sum((x-xm)^2)
  ssreg<-sum((y-x)^2)
  return(ssreg/(ssres+ssreg))
}
CI95lowfun<-function(data){
  if(sd(data)>0){
    k<-t.test(data)$conf.int[1]
  }else{k<-0}
  return(k)
}
CI95highfun<-function(data){
  if(sd(data)>0){
    k<-t.test(data)$conf.int[2]
  }else{k<-0}
  return(k)
}
###########meta leave one out validation##############

meta_validation<-function(DatasetV2,path,outname,xname,outpath){
  efdata<-list()
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  countrylist<-unique(eachC$country)
  rt<-do.call(rbind,lapply(countrylist,function(i){
    ee<-subset(eachC,eachC$country!=i)
    d1<-do.call(rbind,lapply(split(ee,ee$start),function(f){
      #R0
      sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
      si<-summary(sir)$random
      weight<-sir$w.random/sum(sir$w.random)
      r<-data.frame(start=f$start[1],par="R0",
                    strength=NA,
                    m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
      #air temperature
      sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
      si<-summary(sia)$random
      weight<-sia$w.random/sum(sia$w.random)
      t<-data.frame(start=f$start[1],par="Air Temperature",
                    strength=mean(f$strength_Tem),
                    m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight))
      #Epslion
      sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
      si<-summary(sie)$random
      weight<-sie$w.random/sum(sie$w.random)
      e<-data.frame(start=f$start[1],par="Epslion",
                    strength=1,
                    m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight))
      
      if(max(f$mean_SI)>0){
        ds<-subset(f,f$mean_SI>0)
        sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
        si<-summary(sim)$random
        weight<-sim$w.random/sum(sim$w.random)
        s<-data.frame(start=f$start[1],par="Stringency Index",
                      strength=mean(f$strength_SI),
                      m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight))
      }else{s<-NULL}
      if(is.null(f$mean_V)==F){
        if(max(f$mean_V)>0){
          dv<-subset(f,f$mean_V>0)
          vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
          va<-summary(vm)$random
          weight<-vm$w.random/sum(vm$w.random)
          v<-data.frame(start=dv$start[1],par="Vaccination",
                        strength=mean(dv$strength_V),
                        m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
        }else{v<-NULL}
        if(max(f$median_Int)>0){
          dI<-subset(f,f$median_Int>0)
          vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab =  dI$country)
          va<-summary(vm)$random
          weight<-vm$w.random/sum(vm$w.random)
          i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                        strength=mean(dI$strength_Int),
                        m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
        }else{i<-NULL}
        X<-do.call(rbind,list(r,t,e,s,v,i))
      }else{
        X<-do.call(rbind,list(r,t,e,s))
      }
      X$Rt<-mean(f$Rt)   #Rt
      return(X)
      print(paste0(unique(f$start),"has been processed"))
    }))
    Rtpre<-do.call(rbind,lapply(split(d1,d1$start),function(t){
      d<-subset(DatasetV2,DatasetV2$location==i)
      d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
      coun<-subset(d,d$Date>=t$start[1]&d$Date<(t$start[1]+30))
      r0<-coun$R0
      SI<-coun$StringencyIndex*t$m[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vac<-coun$Fully_vaccinated_effect*t$m[which(t$par=="Vaccination")]
        Int<-coun$Interaction*t$m[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vac<-coun$Fully_vaccinated_effect
        Int<-coun$Interaction
      }
      Tem<-coun$Tem*t$m[which(t$par=="Air Temperature")]
      e<-t$m[which(t$par=="Epslion")]
      a<-SI+Vac+Int+Tem+e
      rt<-exp(-a)*r0
      
      SIupper<-coun$StringencyIndex*t$upper[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vacupper<-coun$Fully_vaccinated_effect*t$upper[which(t$par=="Vaccination")]
        Intupper<-coun$Interaction*t$upper[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vacupper<-coun$Fully_vaccinated_effect
        Intupper<-coun$Interaction
      }
      Temupper<-coun$Tem*t$upper[which(t$par=="Air Temperature")]
      eupper<-t$upper[which(t$par=="Epslion")]
      aupper<-SIupper+Vacupper+Intupper+Temupper+eupper
      
      SIlower<-coun$StringencyIndex*t$lower[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vaclower<-coun$Fully_vaccinated_effect*t$lower[which(t$par=="Vaccination")]
        Intlower<-coun$Interaction*t$lower[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vaclower<-coun$Fully_vaccinated_effect
        Intlower<-coun$Interaction
      }
      Temlower<-coun$Tem*t$lower[which(t$par=="Air Temperature")]
      elower<-t$lower[which(t$par=="Epslion")]
      alower<-SIlower+Vaclower+Intlower+Temlower+elower
      
      rt_low<-exp(-alower)*r0
      rt_high<-exp(-aupper)*r0
      p<-data.frame("Rt"=coun$Rt,"Rt_pre"=rt,"Rt_pre_low"=rt_low,"Rt_pre_high"=rt_high,"Date"=coun$Date)
      return(p)
    }))
    meltr<-melt(Rtpre[,c("Rt","Rt_pre","Date")],id="Date")
    ggthemr('fresh')
    c<-as.data.frame(t(caret::postResample(Rtpre$Rt, Rtpre$Rt_pre)))
    c$R2N<-R2(Rtpre$Rt, Rtpre$Rt_pre)
    rtfig<-ggplot()+
      geom_ribbon(data=Rtpre,aes(x=as.Date(Date),ymin=Rt_pre_low,ymax=Rt_pre_high),fill="#8491B4B2",alpha=0.3)+
      geom_point(data=meltr,aes(x=as.Date(Date),y=value,color=variable),alpha=0.5,size=0.3)+
      geom_xspline(data=meltr,aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      scale_color_manual(values=c("grey50","#3C5488B2"))+
      annotate("text",as.Date("2020-09-01"),max(meltr$value)-0.011,parse = TRUE,label="R^2",size=3.4)+
      annotate("text",as.Date("2020-09-01")+45,max(meltr$value)-0.015,label=paste("=",round(c$R2N,2)),size=3.4)+
      annotate("text",as.Date("2020-09-01")+170,max(meltr$value)-0.012,label=paste0("RMSE = ",round(c$RMSE,2)),size=3.4)+
      labs(y =expression(R[t]),x = NULL,title=i)+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    ggsave(paste0(outpath,"/LeaveOneOut_",i,".pdf"),rtfig,units="mm",width=75,height=60,device = cairo_pdf)
    ggsave(paste0(outpath,"/LeaveOneOut_",i,".png"),rtfig,units="mm",width=75,height=60)
    Rtpre$validation<-i
    write.csv(d1,paste0(outpath,"/Meta_coefficient_without_",i,".csv"),row.names = F)
    return(Rtpre)
  }))
  pofig<-ggplot(rt,aes(x=Rt,y=Rt_pre))+geom_point(alpha=0.3,size=0.6,color="#008080")+
    labs(y =expression("Prediction of "*R[t]),x = expression(R[t]))+
    scale_y_continuous(limits=c(0,2),breaks=c(0,0.5,1,1.5),expand=c(0,0))+
    scale_x_continuous(limits=c(0,2.5),breaks=c(0,0.5,1,1.5,2),expand=c(0,0))+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
          axis.title.y= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.title.x= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/ALL_Point.pdf"),pofig,units="mm",width=140,height=140,device = cairo_pdf)
  ggsave(paste0(outpath,"/ALL_Point.png"),pofig,units="mm",width=140,height=140)
  val<-do.call(rbind,lapply(split(rt,rt$validation),function(k){
    c<-as.data.frame(t(caret::postResample(k$Rt, k$Rt_pre)))
    c$R2N<-R2(k$Rt, k$Rt_pre)
    c$val<-k$validation[1]
    c$vaccination<-max(DatasetV2$Fully_vaccinated_pre[which(DatasetV2$location==k$validation[1])])
    c$location<-k$validation[1]
    return(c)
  }))
  write.csv(val,paste0(outpath,"/RMSE_R2.csv"),row.names = F)
  print(summary(val))
  print(R2(rt$Rt, rt$Rt_pre))
}
meta_validation2<-function(DatasetV2,path,outname,xname,outpath){
  efdata<-list()
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  countrylist<-unique(eachC$country)
  rt<-do.call(rbind,lapply(countrylist,function(i){
    ee<-subset(eachC,eachC$country!=i)
    d1<-do.call(rbind,lapply(split(ee,ee$start),function(f){
      #R0
      sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
      si<-summary(sir)$random
      weight<-sir$w.random/sum(sir$w.random)
      r<-data.frame(start=f$start[1],par="R0",
                    strength=NA,
                    m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight))
      #air temperature
      sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
      si<-summary(sia)$random
      weight<-sia$w.random/sum(sia$w.random)
      t<-data.frame(start=f$start[1],par="Air Temperature",
                    strength=mean(f$strength_Tem),
                    m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight))
      #Epslion
      sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
      si<-summary(sie)$random
      weight<-sie$w.random/sum(sie$w.random)
      e<-data.frame(start=f$start[1],par="Epslion",
                    strength=1,
                    m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight))
      
      if(max(f$mean_SI)>0){
        ds<-subset(f,f$mean_SI>0)
        sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
        si<-summary(sim)$random
        weight<-sim$w.random/sum(sim$w.random)
        s<-data.frame(start=f$start[1],par="Stringency Index",
                      strength=mean(f$strength_SI),
                      m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight))
      }else{s<-NULL}
      if(is.null(f$mean_V)==F){
        if(max(f$mean_V)>0){
          dv<-subset(f,f$mean_V>0)
          vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
          va<-summary(vm)$random
          weight<-vm$w.random/sum(vm$w.random)
          v<-data.frame(start=dv$start[1],par="Vaccination",
                        strength=mean(dv$strength_V),
                        m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
        }else{v<-NULL}
        if(max(f$median_Int)>0){
          dI<-subset(f,f$median_Int>0)
          vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab =  dI$country)
          va<-summary(vm)$random
          weight<-vm$w.random/sum(vm$w.random)
          i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                        strength=mean(dI$strength_Int),
                        m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight))
        }else{i<-NULL}
        
        X<-do.call(rbind,list(r,t,e,s,v,i))
      }else{
        X<-do.call(rbind,list(r,t,e,s))
      }
      X$Rt<-mean(f$Rt)   #Rt
      return(X)
      print(paste0(unique(f$start),"has been processed"))
    }))
    Rtpre<-do.call(rbind,lapply(split(d1,d1$start),function(t){
      d<-subset(DatasetV2,DatasetV2$location==i)
      d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
      coun<-subset(d,d$Date>=t$start[1]&d$Date<(t$start[1]+30))
      r0<-coun$R0
      SI<-coun$StringencyIndex*t$m[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vac<-coun$Fully_vaccinated_effect*t$m[which(t$par=="Vaccination")]
        Int<-coun$Interaction*t$m[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vac<-coun$Fully_vaccinated_effect
        Int<-coun$Interaction
      }
      Tem<-coun$Tem*t$m[which(t$par=="Air Temperature")]
      e<-t$m[which(t$par=="Epslion")]
      a<-SI+Vac+Int+Tem+e
      rt<-exp(-a)*r0
      
      SIupper<-coun$StringencyIndex*t$upper[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vacupper<-coun$Fully_vaccinated_effect*t$upper[which(t$par=="Vaccination")]
        Intupper<-coun$Interaction*t$upper[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vacupper<-coun$Fully_vaccinated_effect
        Intupper<-coun$Interaction
      }
      Temupper<-coun$Tem*t$upper[which(t$par=="Air Temperature")]
      eupper<-t$upper[which(t$par=="Epslion")]
      aupper<-SIupper+Vacupper+Intupper+Temupper+eupper
      
      SIlower<-coun$StringencyIndex*t$lower[which(t$par=="Stringency Index")]
      if (nrow(t)>3){
        Vaclower<-coun$Fully_vaccinated_effect*t$lower[which(t$par=="Vaccination")]
        Intlower<-coun$Interaction*t$lower[which(t$par=="Interaction of SI and Vaccination")]
      }else{
        Vaclower<-coun$Fully_vaccinated_effect
        Intlower<-coun$Interaction
      }
      Temlower<-coun$Tem*t$lower[which(t$par=="Air Temperature")]
      elower<-t$lower[which(t$par=="Epslion")]
      alower<-SIlower+Vaclower+Intlower+Temlower+elower
      
      rt_low<-exp(-alower)*r0
      rt_high<-exp(-aupper)*r0
      p<-data.frame("Rt"=coun$Rt,"Rt_pre"=rt,"Rt_pre_low"=rt_low,"Rt_pre_high"=rt_high,"Date"=coun$Date)
      return(p)
    }))
    meltr<-melt(Rtpre[,c("Rt","Rt_pre","Date")],id="Date")
    ggthemr('fresh')
    c<-as.data.frame(t(caret::postResample(Rtpre$Rt, Rtpre$Rt_pre)))
    c$R2N<-R2(Rtpre$Rt, Rtpre$Rt_pre)
    Rtpre$validation<-i
    #write.csv(d1,paste0(outpath,"/Meta_coefficient_without_",i,".csv"),row.names = F)
    return(Rtpre)
  }))
  val<-do.call(rbind,lapply(split(rt,rt$validation),function(k){
    c<-as.data.frame(t(caret::postResample(k$Rt, k$Rt_pre)))
    c$R2N<-R2(k$Rt, k$Rt_pre)
    c$val<-k$validation[1]
    c$vaccination<-max(DatasetV2$Fully_vaccinated_pre[which(DatasetV2$location==k$validation[1])])
    c$location<-k$validation[1]
    return(c)
  }))
  write.csv(val,paste0(outpath,"/RMSE_R2.csv"),row.names = F)
  sum<-as.data.frame(summary(val))
  sum$popR2<-R2(rt$Rt, rt$Rt_pre)
  print(summary(val))
  print(R2(rt$Rt, rt$Rt_pre))
  write.csv(sum,paste0(outpath,"/summary_of_",substring(path,18,25),".csv"),row.names = F)

}
path<-"20220329_V2normal(0,0.3)0.5/R0_calculate"
DatasetV2<-read.csv("20220329_V2normal(0,0.3)0.5/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")
#meta_validation(DatasetV2,path,outname,xname,outpath="20220112_resultV2")
dir.create(file.path(getwd(),"20220329_V2normal(0,0.3)0.5result","validation"),recursive = TRUE)
meta_validation(DatasetV2,path,outname,xname,outpath="20220329_V2normal(0,0.3)0.5result/validation")

###########population leave one out validation##############
pop_validation<-function(DatasetV2,path,outname,xname,outpath){
  conlist<-list.files(path)
  rt<-do.call(rbind,lapply(conlist,function(c){
    vadc<-strsplit(strsplit(c,"_")[[1]][3],".rds")[[1]][1]
    vadd<-subset(DatasetV2,DatasetV2$location==vadc)
    vadd$Tem<-(vadd$Tem-min(vadd$Tem))/(max(vadd$Tem)-min(vadd$Tem))
    fit<-readRDS(paste0(path,"/",c))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    Rtpre<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      
      coun<-subset(vadd,vadd$Date>=start&vadd$Date<end)
      r0<-coun$R0
      SI<-coun$StringencyIndex*pard$m[which(pard$parameter=="StringencyIndex")]
      Vac<-coun$Fully_vaccinated_effect*pard$m[which(pard$parameter=="Fully_vaccinated_effect")]
      Int<-coun$Interaction*pard$m[which(pard$parameter=="Interaction")]
      Tem<-coun$Tem*pard$m[which(pard$parameter=="Air Temperature")]
      e<-pard$m[which(pard$parameter=="Epslion")]
      a<-SI+Vac+Int+Tem+e
      rt<-exp(-a)*r0
      
      SIupper<-coun$StringencyIndex*pard$hh[which(pard$parameter=="StringencyIndex")]
      if (nrow(pard)>3){
        Vacupper<-coun$Fully_vaccinated_effect*pard$hh[which(pard$parameter=="Fully_vaccinated_effect")]
        Intupper<-coun$Interaction*pard$hh[which(pard$parameter=="Interaction")]
      }else{
        Vacupper<-coun$Fully_vaccinated_effect
        Intupper<-coun$Interaction
      }
      Temupper<-coun$Tem*pard$hh[which(pard$parameter=="Air Temperature")]
      eupper<-pard$hh[which(pard$parameter=="Epslion")]
      aupper<-SIupper+Vacupper+Intupper+Temupper+eupper
      
      SIlower<-coun$StringencyIndex*pard$ll[which(pard$parameter=="StringencyIndex")]
      if (nrow(pard)>3){
        Vaclower<-coun$Fully_vaccinated_effect*pard$ll[which(pard$parameter=="Fully_vaccinated_effect")]
        Intlower<-coun$Interaction*pard$ll[which(pard$parameter=="Interaction")]
      }else{
        Vaclower<-coun$Fully_vaccinated_effect
        Intlower<-coun$Interaction
      }
      Temlower<-coun$Tem*pard$ll[which(pard$parameter=="Air Temperature")]
      elower<-pard$ll[which(pard$parameter=="Epslion")]
      alower<-SIlower+Vaclower+Intlower+Temlower+elower
      
      rt_low<-exp(-alower)*r0
      rt_high<-exp(-aupper)*r0
      p<-data.frame("Rt"=coun$Rt,"Rt_pre"=rt,"Rt_pre_low"=rt_high,"Rt_pre_high"=rt_low,"Date"=coun$Date)
      return(p)
    }))
    meltr<-melt(Rtpre[,c("Rt","Rt_pre","Date")],id="Date")
    ggthemr('fresh')
    c<-as.data.frame(t(caret::postResample(Rtpre$Rt, Rtpre$Rt_pre)))
    c$R2N<-R2(Rtpre$Rt, Rtpre$Rt_pre)
    rtfig<-ggplot()+
      geom_ribbon(data=Rtpre,aes(x=as.Date(Date),ymin=Rt_pre_low,ymax=Rt_pre_high),fill="#8491B4B2",alpha=0.3)+
      geom_point(data=meltr,aes(x=as.Date(Date),y=value,color=variable),alpha=0.5,size=0.3)+
      geom_xspline(data=meltr,aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      scale_color_manual(values=c("grey50","#3C5488B2"))+
      annotate("text",as.Date("2020-09-01"),max(meltr$value)-0.011,parse = TRUE,label="R^2",size=3.4)+
      annotate("text",as.Date("2020-09-01")+45,max(meltr$value)-0.015,label=paste("=",round(c$R2N,2)),size=3.4)+
      annotate("text",as.Date("2020-09-01")+170,max(meltr$value)-0.012,label=paste0("RMSE = ",round(c$RMSE,2)),size=3.4)+
      labs(y =expression(R[t]),x = NULL,title=c)+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    ggsave(paste0(outpath,"/pop_LeaveOneOut_",vadc,".pdf"),rtfig,units="mm",width=75,height=60,device = cairo_pdf)
    ggsave(paste0(outpath,"/pop_LeaveOneOut_",vadc,".png"),rtfig,units="mm",width=75,height=60)
    Rtpre$vadc<-vadc
    return(Rtpre)
  }))
  pofig<-ggplot(rt,aes(x=Rt,y=Rt_pre))+geom_point(alpha=0.3,size=0.6,color="#008080")+
    labs(y =expression("Prediction of "*R[t]),x = expression(R[t]))+
    scale_y_continuous(limits=c(0,2.5),breaks=c(0,0.5,1,1.5,2),expand=c(0,0))+
    scale_x_continuous(limits=c(0,2.5),breaks=c(0,0.5,1,1.5,2),expand=c(0,0))+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
          axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
          axis.title.y= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.title.x= element_text(color="black",vjust=0,size = unit(9,"pt")),
          axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/pop_ALL_Point_pop.pdf"),pofig,units="mm",width=100,height=100,device = cairo_pdf)
  ggsave(paste0(outpath,"/pop_ALL_Point_pop.png"),pofig,units="mm",width=100,height=100)
  val<-do.call(rbind,lapply(split(rt,rt$vadc),function(k){
    c<-as.data.frame(t(caret::postResample(k$Rt, k$Rt_pre)))
    c$val<-k$vadc[1]
    c$R2N<-R2(k$Rt, k$Rt_pre)
    c$vaccination<-max(DatasetV2$Fully_vaccinated_pre[which(DatasetV2$location==k$vadc[1])])
    return(c)
  }))
  write.csv(val,paste0(outpath,"/pop_RMSE_R2.csv"),row.names = F)
  print(summary(val))
  print(R2(rt$Rt, rt$Rt_pre))
}
path<-"20220112_newR0_validation"
DatasetV2<-read.csv("20200112_newR0V2/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")
outpath<-"20220329_V2normal(0,0.3)0.5result"
pop_validation(DatasetV2,path,outname,xname,outpath)
#############meta forest plot#############
source('code/forestplot.R')
xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")
path="20220329_V2normal(0,0.3)0.5/R0_calculate"
outpath<-"20220329_V2normal(0,0.3)0.5result"
DatasetV2<-read.csv("20220329_V2normal(0,0.3)0.5/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
forestplot(DatasetV2,path,xname,outpath)
##########Rt pre with priori###############
source('code/main.R')
compare_piror_post<-function(DatasetV2,path,outname,xname){
  countryname<-c("France","Israel","Bulgaria","Croatia")
  countrycoff<-read.csv(paste0(outpath,"/Country_cofficient_20220330.csv"),stringsAsFactors = F)
  lapply(countryname,function(i){
    ee<-subset(countrycoff,countrycoff$country==i)
    ee$start<-as.Date(ee$start)
    d<-subset(DatasetV2,DatasetV2$location==i)
    d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
    fit<-readRDS(paste0(path,"/",i,"_withinR0/all.rds"))
    out<-rstan::extract(fit)
    r0<-as.data.frame(t(out$R0))
    r0$date<-d$Date[order(d$Date)]
    rtlist<-lapply(split(ee,ee$start),function(t){
      coun<-subset(d,d$Date>=t$start[1]&d$Date<(t$start[1]+30))
      SIp<-coun$StringencyIndex*t$m[which(t$parameter=="StringencyIndex")]
      if (nrow(t)>3){
        Vacp<-coun$Fully_vaccinated_pre*t$m[which(t$parameter=="Fully_vaccinated_pre")]
        Intp<-coun$Interaction*t$m[which(t$parameter=="Interaction")]
      }else{
        Vacp<-coun$Fully_vaccinated_pre
        Intp<-coun$Interaction
      }
      Temp<-coun$Tem*t$m[which(t$parameter=="Air Temperature")]
      ep<-t$m[which(t$parameter=="Epslion")]
      ap<-SIp+Vacp+Intp+Temp+ep
      R0t<-subset(r0,r0$date>=t$start[1]&r0$date<(t$start[1]+30))

      postrt<-do.call(rbind,lapply(seq(1,length(ap)),function(n){
        data.frame(date=R0t$date[n],R0t=R0t[n,-c(10001)]*exp(-ap[n]))
      }))
        
      Rtpre<-do.call(cbind,lapply(seq(1,10000),function(f){
        u<-runif(1,0,1)
        u1<-rnorm(30,0,0.3)
        u2<-rnorm(30,0,0.3)
        u1<-mean(u1[which(u1>=0)])
        u2<-mean(u2[which(u2>=0)])
        alpha1<-mean(rgamma(1,u,1))
        alpha2<-mean(rgamma(1,u,1))
        alpha3<-mean(rgamma(1,u,1))
        beta<-mean(rnorm(1,0,u1))
        eli<-mean(rnorm(1,0,u2))
        d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
        SI<-coun$StringencyIndex*alpha1
        if (nrow(t)>3){
          Vac<-coun$Fully_vaccinated_pre*alpha2
          Int<-coun$Interaction*alpha3
        }else{
          Vac<-coun$Fully_vaccinated_pre
          Int<-coun$Interaction
        }
        Tem<-coun$Tem*beta
        e<-eli
        a<-SI+Vac+Int+Tem+e
        r0<-coun$R0
        rt<-exp(-a)*r0
        return(rt)
      }))
      Rtmean<-as.vector(apply(Rtpre,1,quantile)[3,])
      Rtq1<-as.vector(apply(Rtpre,1,quantile)[2,])
      Rtq3<-as.vector(apply(Rtpre,1,quantile)[4,])
      p<-data.frame("Rt"=coun$Rt,"Priori_median"=Rtmedian,"Priori_q1"=Rtq1,
                    "Priori_q3"=Rtq3,"Date"=coun$Date)

      p$Posterior<-as.vector(apply(postrt[,-c(1)],1,quantile)[3,])
      p$Posterior_q1<-as.vector(apply(postrt[,-c(1)],1,quantile)[2,])
      p$Posterior_q3<-as.vector(apply(postrt[,-c(1)],1,quantile)[4,])
      return(list(p,as.data.frame(Rtpre),postrt))
    })
    
    RT_pre<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[1]]
    }))
    prior0t<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[2]]
    }))
    postr0t<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[3]]
    }))
    y<-RT_pre[,c("Rt","Date")]
    y$Date<-as.Date(y$Date)
    
  
    prior0t$date<-as.Date(unique(RT_pre$Date))
    r0<-melt(prior0t,id="date")
    #pdf(paste0(outpath,"/Priori_r0tDistributionPlot_",i,".pdf"),height=8,width=6,onefile = T)
    lapply(seq(9,1),function(d){
      y1<-subset(y,y$Date<(min(y$Date)+50*d)&y$Date>=(min(y$Date)+50*(d-1)))
      r01<-subset(r0,r0$date<(min(r0$date)+50*d)&r0$date>=(min(r0$date)+50*(d-1)))
      fg<-ggplot()+
        geom_density_ridges2(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
                                     color="#eaeff6",
                                     scale=5,alpha=0.5)+
        geom_point(data=y1,aes(x=Rt,y=as.factor(Date)),size=0.5,alpha=0.8,color="grey30")+
        theme_classic()+
        scale_fill_cyclical(values = c("#bbc8dd", "#47659e"))+
        scale_x_continuous(limits=c(0,8),breaks=c(0,2,4,6),expand=c(0,0))+
        labs(y =NULL,x =expression("Priori predicted"*"  "*R["t"]))+
        theme(legend.position = "none",
              legend.background = element_rect(fill=NA),
              legend.key.size = unit(9, "pt"),
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              legend.title=element_blank(),
              plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
              axis.text.x= element_text(color="black",size = unit(9, "pt")),
              plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
              panel.background=element_rect(fill = "transparent",colour = NA))
      ggsave(paste0(outpath,"/Priori_r0tDistributionPlot_",i,d,".pdf"),fg,units="mm",width=50,height=80,device = cairo_pdf)
    })
    #dev.off()
    
    postr0t$date<-as.Date(postr0t$date)
    postr0t<-melt(postr0t,id="date")
    #pdf(paste0(outpath,"/Posterior_r0tDistributionPlot_",i,".pdf"), height=8,width=6,onefile = T)
    lapply(seq(9,1),function(d){
      r01<-subset(postr0t,postr0t$date<(min(postr0t$date)+50*d)&postr0t$date>=(min(postr0t$date)+50*(d-1)))
      y1<-subset(y,y$Date<(min(y$Date)+50*d)&y$Date>=(min(y$Date)+50*(d-1)))
      fg<-ggplot()+
        geom_density_ridges2(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
                                     color="#eaeff6",size=0.2,
                                     scale=5,alpha=0.5)+
        #stat_density_ridges(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
        #                    quantile_lines = TRUE, quantiles = 2,color="#eaeff6",
        #                    scale=5,alpha=0.5)+
        geom_point(data=y1,aes(x=Rt,y=as.factor(Date)),size=0.3,alpha=0.8,color="grey30")+
        theme_classic()+
        scale_fill_cyclical(values = c("#bbc8dd", "#47659e"))+
        scale_x_continuous(limits=c(0,3),breaks=c(0,1,2),expand=c(0,0))+
        labs(y =NULL,x =expression("Posterior predicted"*"  "*R["t"]))+
        theme(legend.position = "none",
              legend.background = element_rect(fill=NA),
              legend.key.size = unit(9, "pt"),
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              legend.title=element_blank(),
              plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
              axis.text.x= element_text(color="black",size = unit(9, "pt")),
              plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
              panel.background=element_rect(fill = "transparent",colour = NA))
      ggsave(paste0(outpath,"/Posterior_r0tDistributionPlot_",i,d,".pdf"),fg,units="mm",width=50,height=80,device = cairo_pdf)
      
    })

    
    meltr<-melt(RT_pre,id="Date")
    #ggthemr('fresh')
    c1<-as.data.frame(t(caret::postResample(RT_pre$Rt, RT_pre$Priori_median)))
    c2<-as.data.frame(t(caret::postResample(RT_pre$Rt, RT_pre$Posterior)))
    print(do.call(rbind,list(c1,c2)))
    me<-subset(meltr,meltr$variable=="Rt"|meltr$variable=="Priori_median"|meltr$variable=="Posterior")
    me2<-RT_pre[,c("Date","Priori_q1","Priori_q3")]
    me3<-RT_pre[,c("Date","Posterior_q1","Posterior_q3")]

    rtfig<-ggplot(data=me)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      geom_ribbon(data=me2,aes(x=as.Date(Date), ymin = Priori_q1, ymax = Priori_q3,fill = "Priori IQR"),
                  alpha = 0.3)+
      geom_ribbon(data=me3,aes(x=as.Date(Date), ymin = Posterior_q1, ymax = Posterior_q3,fill="Posterior IQR"),
                  alpha = 0.2)+
      scale_fill_manual(values=c("#c9e4e7","#eae3d1"))+
      #geom_point(aes(x=as.Date(Date),y=value,color=variable),alpha=0.2,size=0.4)+
      geom_xspline(aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_color_manual(values=c("grey10","#ae9a65","#6894b9"),labels=c("Rt"=expression(R["0,t"]),
                                                                         "Priori_mean"=expression("Priori predicted"*"  "*R["0,t"]),
                                                                         "Posterior"=expression("Posterior predicted"*"  "*R["0,t"])))+
      annotate("text",as.Date("2021-02-01"),max(meltr$value)-0.011,parse = TRUE,label="Pirori:R^2",size=2.5)+
      annotate("text",as.Date("2021-02-01")+50,max(meltr$value)-0.015,label=paste("=",round(c1$Rsquared,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01")+150,max(meltr$value)-0.012,label=paste0("RMSE = ",round(c1$RMSE,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01"),max(meltr$value)-0.2,parse = TRUE,label="Posterior:R^2",size=2.5)+
      annotate("text",as.Date("2021-02-01")+70,max(meltr$value)-0.215,label=paste("=",round(c2$Rsquared,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01")+150,max(meltr$value)-0.212,label=paste0("RMSE = ",round(c2$RMSE,2)),size=2.5)+
      labs(y =expression(R[t]),x = NULL,title=i)+
      theme_clean()+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    ggsave(paste0(outpath,"/Piror&Posterior_",i,".pdf"),rtfig,units="mm",width=75,height=60,device = cairo_pdf)
  })
}
compare_piror_postV2<-function(DatasetV2,path,outname,xname,inpath){
  countryname<-c("France","Israel","Bulgaria","Croatia")
  countrycoff<-read.csv(paste0(inpath,"/Country_cofficient_20220330.csv"),stringsAsFactors = F)
  lapply(countryname,function(i){
    ee<-subset(countrycoff,countrycoff$country==i)
    ee$start<-as.Date(ee$start)
    d<-subset(DatasetV2,DatasetV2$location==i)
    d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
    fit<-readRDS(paste0(path,"/",i,"_withinR0/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    #r0<-as.data.frame(t(out$R0))
    #r0$date<-d$Date[order(d$Date)]
    
    datelist<-unique(ee$start)
    rtlist<-lapply(seq(1,15),function(t){
      start<-datelist[t]
      end<-start+30
      coun<-subset(d,d$Date>=start&d$Date<end)
      
      al<-alpha[,((t-1)*3+1):(t*3)]
      be<-beta[,t]
      el<-eli[,t]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      X<-coun[,c(xname,"Tem")]
      X$eli<-1
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      r0<-coun$R0[1]
      postrt<-do.call(rbind,lapply(seq(1,nrow(X)),function(x){
        ada<-as.data.frame(do.call(rbind,lapply(c(xname,"Air Temperature","Epslion"),function(nn){
          pars[,nn]*X[x,nn]
        })))
        R0t<-data.frame(t(r0*exp(-apply(ada,2,sum))))
        R0t$date=unique(coun$Date)[x]
        #data.frame(date=unique(coun$Date)[x],R0t=r0[n]*exp(-apply(ada,2,sum)))
        return(R0t)
      }))
      #postrt<-do.call(rbind,lapply(seq(1,length(r0)),function(n){
      #  R0t=r0[n]*exp(-ap)
      #}))
      
      Rtpre<-do.call(cbind,lapply(seq(1,10000),function(f){
        u<-runif(1,0,1)
        u1<-rnorm(30,0,0.3)
        u2<-rnorm(30,0,0.3)
        u1<-mean(u1[which(u1>=0)])
        u2<-mean(u2[which(u2>=0)])
        alpha1<-rgamma(1,u,1)
        alpha2<-rgamma(1,u,1)
        alpha3<-rgamma(1,u,1)
        beta<-rnorm(1,0,u1)
        eli<-rnorm(1,0,u2)
        SI<-coun$StringencyIndex*alpha1
        Vac<-coun$Fully_vaccinated_pre*alpha2
        Int<-coun$Interaction*alpha3
        Tem<-coun$Tem*beta
        e<-eli
        a<-SI+Vac+Int+Tem+e
        r0<-coun$R0[1]
        rt<-exp(-a)*r0
        return(rt)
      }))
      Rtmedian<-as.vector(apply(Rtpre,1,quantile)[3,])
      Rtq1<-as.vector(apply(Rtpre,1,quantile)[2,])
      Rtq3<-as.vector(apply(Rtpre,1,quantile)[4,])
      p<-data.frame("Rt"=coun$Rt,"Priori_median"=Rtmedian,"Priori_q1"=Rtq1,
                    "Priori_q3"=Rtq3,"Date"=coun$Date)
      
      p$Posterior<-as.vector(apply(postrt[,-c(10001)],1,quantile)[3,])
      p$Posterior_q1<-as.vector(apply(postrt[,-c(10001)],1,quantile)[2,])
      p$Posterior_q3<-as.vector(apply(postrt[,-c(10001)],1,quantile)[4,])
      return(list(p,as.data.frame(Rtpre),postrt))
    })
    
    RT_pre<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[1]]
    }))
    prior0t<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[2]]
    }))
    postr0t<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[3]]
    }))
    y<-RT_pre[,c("Rt","Date")]
    y$Date<-as.Date(y$Date)
    
    
    prior0t$date<-as.Date(unique(RT_pre$Date))
    r0<-melt(prior0t,id="date")
    priolist<-lapply(seq(9,1),function(d){
      y1<-subset(y,y$Date<(min(y$Date)+50*d)&y$Date>=(min(y$Date)+50*(d-1)))
      r01<-subset(r0,r0$date<(min(r0$date)+50*d)&r0$date>=(min(r0$date)+50*(d-1)))
      y1$poi<-"1"
      fg<-ggplot()+
        geom_density_ridges2(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
                             color="#eaeff6",
                             scale=5,alpha=0.5)+
        geom_point(data=y1,aes(x=Rt,y=as.factor(Date),color=poi),size=0.5,alpha=0.8, show.legend =T)+
                   #,color="grey30")+
        theme_classic()+
        scale_fill_cyclical(values = c("#bbc8dd", "#47659e"))+
        scale_color_manual(values = c("grey30"),labels=c("1"=expression(R["t"])))+
        scale_x_continuous(limits=c(0,5),breaks=c(0,2,4),expand=c(0,0))+
        labs(y =NULL,x =NULL)+
        #labs(y =NULL,x =expression("Priori predicted"*"  "*R["t"]))+
        theme(legend.position = "none",
              legend.background = element_rect(fill=NA),
              legend.key.size = unit(9, "pt"),
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              legend.title=element_blank(),
              plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
              #axis.text.x= element_text(color="black",size = unit(9, "pt")),
              axis.text.x= element_blank(),
              #axis.text.y=element_blank(),
              axis.text.y= element_text(color="black",size = unit(7, "pt")),
              plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
              panel.background=element_rect(fill = "transparent",colour = NA))
      #ggsave(paste0(outpath,"/Priori_r0tDistributionPlot_",i,d,".pdf"),fg,units="mm",width=50,height=80,device = cairo_pdf)
      return(fg)
    })
    for(u in 1:length(priolist)){
      if(u>6){
        priolist[[u]]<-priolist[[u]]+theme(axis.title.x= element_text(color="black",size =unit(9, "pt")),
                                   axis.text.x = element_text(color="black",size = unit(9, "pt")))}
    }
    legend<-priolist[[1]]+theme(legend.position = "bottom",
                                legend.title=element_blank(),
                                legend.text = element_text(size = unit(9, "pt")),
                                legend.key.height=unit(0.1,'cm'),
                                legend.key.width=unit(0.5,'cm'),
                                legend.key.size = unit(9, "pt"),
                                legend.background = element_rect(fill="transparent"),
                                legend.key=element_blank())
    mylegend<-g_legend(legend)
    
    pdf(paste0(outpath,"/Priori_",i,"plot.pdf"),onefile = T)
    grid.arrange(mylegend,arrangeGrob(grobs = priolist,ncol = 3),heights = c(0.5,9),
                       top=textGrob(paste0("Priori of ",i)))
    dev.off()
    
    ggsave(paste0("0924picture/sensitivity_delta.pdf"),plot,units="mm",width=240,height=320,device = cairo_pdf)
    
    #dev.off()
    write.csv(prior0t,paste0(outpath,"/Pori_r0tDistributiondata.csv"))
    
    postr0t$date<-as.Date(postr0t$date)
    write.csv(postr0t,paste0(outpath,"/post_r0tDistributiondata.csv"))
    postr0t<-melt(postr0t,id="date")
    #pdf(paste0(outpath,"/Posterior_r0tDistributionPlot_",i,".pdf"), height=8,width=6,onefile = T)
    lapply(seq(9,1),function(d){
      r01<-subset(postr0t,postr0t$date<(min(postr0t$date)+50*d)&postr0t$date>=(min(postr0t$date)+50*(d-1)))
      y1<-subset(y,y$Date<(min(y$Date)+50*d)&y$Date>=(min(y$Date)+50*(d-1)))
      y1$poi<-"1"
      fg<-ggplot()+
        geom_density_ridges2(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
                             color="#eaeff6",size=0.2,
                             scale=5,alpha=0.5)+
        #stat_density_ridges(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
        #                    quantile_lines = TRUE, quantiles = 2,color="#eaeff6",
        #                    scale=5,alpha=0.5)+
        geom_point(data=y1,aes(x=Rt,y=as.factor(Date),color=poi),size=0.5,alpha=0.8, show.legend =T)+
        #geom_point(data=y1,aes(x=Rt,y=as.factor(Date)),size=0.3,alpha=0.8,color="grey30")+
        theme_classic()+
        scale_fill_cyclical(values = c("#bbc8dd", "#47659e"))+
        scale_x_continuous(limits=c(0,3),breaks=c(0,1,2),expand=c(0,0))+
        scale_color_manual(values = c("grey30"),labels=c("1"=expression(R["t"])))+
        labs(y =NULL,x =NULL)+
        #labs(y =NULL,x =expression("Posterior predicted"*"  "*R["t"]))+
        theme(legend.position = "none",
              legend.background = element_rect(fill=NA),
              legend.key.size = unit(9, "pt"),
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              legend.title=element_blank(),
              plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
              #axis.text.x= element_text(color="black",size = unit(9, "pt")),
              axis.text.x= element_blank(),
              axis.text.y=element_blank(),
              #axis.text.y= element_text(color="black",size = unit(9, "pt")),
              plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
              panel.background=element_rect(fill = "transparent",colour = NA))
      #ggsave(paste0(outpath,"/Posterior_r0tDistributionPlot_",i,d,".pdf"),fg,units="mm",width=50,height=80,device = cairo_pdf)
      return(fg)
    })
    
    
    
    
    meltr<-melt(RT_pre,id="Date")
    #ggthemr('fresh')
    c1<-as.data.frame(t(caret::postResample(RT_pre$Rt, RT_pre$Priori_median)))
    c2<-as.data.frame(t(caret::postResample(RT_pre$Rt, RT_pre$Posterior)))
    print(do.call(rbind,list(c1,c2)))
    me<-subset(meltr,meltr$variable=="Rt"|meltr$variable=="Priori_median"|meltr$variable=="Posterior")
    me2<-RT_pre[,c("Date","Priori_q1","Priori_q3")]
    me3<-RT_pre[,c("Date","Posterior_q1","Posterior_q3")]
    
    rtfig<-ggplot(data=me)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      geom_ribbon(data=me2,aes(x=as.Date(Date), ymin = Priori_q1, ymax = Priori_q3,fill = "Priori IQR"),
                  alpha = 0.3)+
      geom_ribbon(data=me3,aes(x=as.Date(Date), ymin = Posterior_q1, ymax = Posterior_q3,fill="Posterior IQR"),
                  alpha = 0.2)+
      scale_fill_manual(values=c("#c9e4e7","#eae3d1"))+
      #geom_point(aes(x=as.Date(Date),y=value,color=variable),alpha=0.2,size=0.4)+
      geom_xspline(aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_color_manual(values=c("grey10","#ae9a65","#6894b9"),labels=c("Rt"=expression(R["t"]),
                                                                         "Priori_mean"=expression("Priori predicted"*"  "*R["t"]),
                                                                         "Posterior"=expression("Posterior predicted"*"  "*R["t"])))+
      annotate("text",as.Date("2021-02-01"),max(meltr$value)-0.011,parse = TRUE,label="Pirori:R^2",size=2.5)+
      annotate("text",as.Date("2021-02-01")+50,max(meltr$value)-0.015,label=paste("=",round(c1$Rsquared,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01")+150,max(meltr$value)-0.012,label=paste0("RMSE = ",round(c1$RMSE,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01"),max(meltr$value)-0.2,parse = TRUE,label="Posterior:R^2",size=2.5)+
      annotate("text",as.Date("2021-02-01")+70,max(meltr$value)-0.215,label=paste("=",round(c2$Rsquared,2)),size=2.5)+
      annotate("text",as.Date("2021-02-01")+150,max(meltr$value)-0.212,label=paste0("RMSE = ",round(c2$RMSE,2)),size=2.5)+
      labs(y =expression(R[t]),x = NULL,title=i)+
      theme_clean()+
      theme(legend.position = "bottom",
            legend.title=element_blank(),
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_rect(fill = "transparent",colour = NA))
    ggsave(paste0(outpath,"/Piror&Posterior_",i,".pdf"),rtfig,units="mm",width=75,height=60,device = cairo_pdf)
  })
}
plot_piror_post<-function(DatasetV2,path,outname,xname,inpath){
  countryname<-unique(DatasetV2$location)
  countrycoff<-read.csv(paste0(inpath,"/Country_cofficient_20220330.csv"),stringsAsFactors = F)
  pdf(paste0(outpath,"/Prio&Post_DistributionPlot.pdf"),onefile = T,width=9,height = 15)
  lapply(countryname,function(i){
    ee<-subset(countrycoff,countrycoff$country==i)
    ee$start<-as.Date(ee$start)
    d<-subset(DatasetV2,DatasetV2$location==i)
    d$Tem<-(d$Tem-min(d$Tem))/(max(d$Tem)-min(d$Tem))
    fit<-readRDS(paste0(path,"/",i,"_withinR0/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    #r0<-as.data.frame(t(out$R0))
    #r0$date<-d$Date[order(d$Date)]
    
    datelist<-unique(ee$start)
    rtlist<-lapply(seq(1,15),function(t){
      start<-datelist[t]
      end<-start+30
      coun<-subset(d,d$Date>=start&d$Date<end)
      
      al<-alpha[,((t-1)*3+1):(t*3)]
      be<-beta[,t]
      el<-eli[,t]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      X<-coun[,c(xname,"Tem")]
      X$eli<-1
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      r0<-coun$R0[1]
      postrt<-do.call(rbind,lapply(seq(1,nrow(X)),function(x){
        ada<-as.data.frame(do.call(rbind,lapply(c(xname,"Air Temperature","Epslion"),function(nn){
          pars[,nn]*X[x,nn]
        })))
        R0t<-data.frame(t(r0*exp(-apply(ada,2,sum))))
        R0t$date=unique(coun$Date)[x]
        #data.frame(date=unique(coun$Date)[x],R0t=r0[n]*exp(-apply(ada,2,sum)))
        return(R0t)
      }))
      #postrt<-do.call(rbind,lapply(seq(1,length(r0)),function(n){
      #  R0t=r0[n]*exp(-ap)
      #}))
      
      Rtpre<-do.call(cbind,lapply(seq(1,10000),function(f){
        u<-runif(1,0,1)
        u1<-rnorm(30,0,0.3)
        u2<-rnorm(30,0,0.3)
        u1<-mean(u1[which(u1>=0)])
        u2<-mean(u2[which(u2>=0)])
        alpha1<-rgamma(1,u,1)
        alpha2<-rgamma(1,u,1)
        alpha3<-rgamma(1,u,1)
        beta<-rnorm(1,0,u1)
        eli<-rnorm(1,0,u2)
        SI<-coun$StringencyIndex*alpha1
        Vac<-coun$Fully_vaccinated_pre*alpha2
        Int<-coun$Interaction*alpha3
        Tem<-coun$Tem*beta
        e<-eli
        a<-SI+Vac+Int+Tem+e
        r0<-coun$R0[1]
        rt<-exp(-a)*r0
        return(rt)
      }))
      Rtmedian<-as.vector(apply(Rtpre,1,quantile)[3,])
      Rtq1<-as.vector(apply(Rtpre,1,quantile)[2,])
      Rtq3<-as.vector(apply(Rtpre,1,quantile)[4,])
      p<-data.frame("Rt"=coun$Rt,"Priori_median"=Rtmedian,"Priori_q1"=Rtq1,
                    "Priori_q3"=Rtq3,"Date"=coun$Date)
      
      p$Posterior<-as.vector(apply(postrt[,-c(10001)],1,quantile)[3,])
      p$Posterior_q1<-as.vector(apply(postrt[,-c(10001)],1,quantile)[2,])
      p$Posterior_q3<-as.vector(apply(postrt[,-c(10001)],1,quantile)[4,])
      return(list(p,as.data.frame(Rtpre),postrt))
    })
    
    RT_pre<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[1]]
    }))
    prior0t<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[2]]
    }))
    postr0t<-do.call(rbind,lapply(seq(1,length(rtlist)),function(i){
      rtlist[[i]][[3]]
    }))
    y<-RT_pre[,c("Rt","Date")]
    y$Date<-as.Date(y$Date)
    
    meltr<-melt(RT_pre,id="Date")
    #ggthemr('fresh')
    c1<-as.data.frame(t(caret::postResample(RT_pre$Rt, RT_pre$Priori_median)))
    c2<-as.data.frame(t(caret::postResample(RT_pre$Rt, RT_pre$Posterior)))
    print(do.call(rbind,list(c1,c2)))
    me<-subset(meltr,meltr$variable=="Rt"|meltr$variable=="Priori_median"|meltr$variable=="Posterior")
    me2<-RT_pre[,c("Date","Priori_q1","Priori_q3")]
    me3<-RT_pre[,c("Date","Posterior_q1","Posterior_q3")]
    kk<-list()
    kk[[1]]<-ggplot(data=me)+
      scale_x_date(breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
      geom_ribbon(data=me2,aes(x=as.Date(Date), ymin = Priori_q1, ymax = Priori_q3,fill = "Priori IQR"),
                  alpha = 0.3)+
      geom_ribbon(data=me3,aes(x=as.Date(Date), ymin = Posterior_q1, ymax = Posterior_q3,fill="Posterior IQR"),
                  alpha = 0.2)+
      scale_fill_manual(values=c("#c9e4e7","#eae3d1"))+
      #geom_point(aes(x=as.Date(Date),y=value,color=variable),alpha=0.2,size=0.4)+
      geom_xspline(aes(x=as.Date(Date),y=value,color=variable),size=0.2)+
      scale_color_manual(values=c("grey10","#ae9a65","#6894b9"),labels=c("Rt"=expression(R["t"]),
                                                                         "Priori_mean"=expression("Priori predicted"*"  "*R["t"]),
                                                                         "Posterior"=expression("Posterior predicted"*"  "*R["t"])))+
      labs(y =expression(R[t]),x = NULL,title=i)+
      theme_classic()+
      theme(legend.position = "",
            plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
            axis.title.x= element_blank(),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
            axis.title.y= element_text(color="black",size = unit(9,"pt")),
            axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
            plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
            panel.background=element_blank())
    leg<-kk[[1]]+theme(legend.position = "bottom",
                       legend.title=element_blank(),
                       legend.text = element_text(size = unit(9, "pt")),
                       legend.key.height=unit(0.1,'cm'),
                       legend.key.width=unit(0.5,'cm'),
                       legend.key.size = unit(9, "pt"),
                       legend.background = element_rect(fill="transparent",color=NA),
                       legend.key=element_blank(),
                       plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(10, "pt")),
                       axis.title.x= element_blank(),
                       axis.text.x = element_text(color="black",hjust=0.5,size = unit(9,"pt")),
                       axis.title.y= element_text(color="black",size = unit(9,"pt")),
                       axis.text.y= element_text(color="black",hjust=1,size = unit(9,"pt")),
                       plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
                       panel.background=element_blank())
    grid.arrange(kk[[1]],g_legend(leg),heights = c(3,1))
    
    prior0t$date<-as.Date(unique(RT_pre$Date))
    #write.csv(prior0t,paste0(outpath,"/Pori_r0tDistributiondata_",i,".csv"))
    r0<-melt(prior0t,id="date")
    priolist<-lapply(seq(9,1),function(d){
      y1<-subset(y,y$Date<(min(y$Date)+50*d)&y$Date>=(min(y$Date)+50*(d-1)))
      r01<-subset(r0,r0$date<(min(r0$date)+50*d)&r0$date>=(min(r0$date)+50*(d-1)))
      y1$poi<-"1"
      fg<-ggplot()+
        geom_density_ridges2(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
                             color="#eaeff6",
                             scale=5,alpha=0.5)+
        geom_point(data=y1,aes(x=Rt,y=as.factor(Date),color=poi),size=0.5,alpha=0.8, show.legend =T)+
        #,color="grey30")+
        theme_classic()+
        scale_fill_cyclical(values = c("#bbc8dd", "#47659e"))+
        scale_color_manual(values = c("grey30"),labels=c("1"=expression(R["t"])))+
        scale_x_continuous(limits=c(0,5),breaks=c(0,2,4),expand=c(0,0))+
        labs(y =NULL,x =NULL)+
        #labs(y =NULL,x =expression("Priori predicted"*"  "*R["t"]))+
        theme(legend.position = "none",
              legend.background = element_rect(fill=NA),
              legend.key.size = unit(9, "pt"),
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              legend.title=element_blank(),
              plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
              #axis.text.x= element_text(color="black",size = unit(9, "pt")),
              axis.text.x= element_blank(),
              #axis.text.y=element_blank(),
              axis.text.y= element_text(color="black",size = unit(6, "pt")),
              plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
              panel.background=element_rect(fill = "transparent",colour = NA))
      #ggsave(paste0(outpath,"/Priori_r0tDistributionPlot_",i,d,".pdf"),fg,units="mm",width=50,height=80,device = cairo_pdf)
      return(fg)
    })
    for(u in 1:length(priolist)){
      if(u>6){
        priolist[[u]]<-priolist[[u]]+theme(axis.title.x= element_text(color="black",size =unit(9, "pt")),
                                           axis.text.x = element_text(color="black",size = unit(9, "pt")))}
    }
    legend<-priolist[[1]]+theme(legend.position = "bottom",
                                legend.title=element_blank(),
                                legend.text = element_text(size = unit(9, "pt")),
                                legend.key.height=unit(0.1,'cm'),
                                legend.key.width=unit(0.5,'cm'),
                                legend.key.size = unit(9, "pt"),
                                legend.background = element_rect(fill="transparent"),
                                legend.key=element_blank())
    
    grid.arrange(g_legend(legend),arrangeGrob(grobs = priolist,ncol = 3),heights = c(0.3,9),
                 top=textGrob(paste0("Priori of ",i)),
                 bottom=textGrob(expression("Priori predicted"*"  "*R["t"])))
    
    
    #ggsave(paste0("0924picture/sensitivity_delta.pdf"),plot,units="mm",width=240,height=320,device = cairo_pdf)
    
    #dev.off()
    
    postr0t$date<-as.Date(postr0t$date)
    #write.csv(postr0t,paste0(outpath,"/post_r0tDistributiondata_",i,".csv"))
    postr0t<-melt(postr0t,id="date")
    #pdf(paste0(outpath,"/Posterior_r0tDistributionPlot_",i,".pdf"), height=8,width=6,onefile = T)
    postlist<-lapply(seq(9,1),function(d){
      r01<-subset(postr0t,postr0t$date<(min(postr0t$date)+50*d)&postr0t$date>=(min(postr0t$date)+50*(d-1)))
      y1<-subset(y,y$Date<(min(y$Date)+50*d)&y$Date>=(min(y$Date)+50*(d-1)))
      y1$poi<-"1"
      fg<-ggplot()+
        geom_density_ridges2(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
                             color="#eaeff6",size=0.2,
                             scale=5,alpha=0.5)+
        #stat_density_ridges(data=r01,aes(x=value,y=as.factor(date),fill=as.factor(date)),
        #                    quantile_lines = TRUE, quantiles = 2,color="#eaeff6",
        #                    scale=5,alpha=0.5)+
        geom_point(data=y1,aes(x=Rt,y=as.factor(Date),color=poi),size=0.5,alpha=0.8, show.legend =T)+
        #geom_point(data=y1,aes(x=Rt,y=as.factor(Date)),size=0.3,alpha=0.8,color="grey30")+
        theme_classic()+
        scale_fill_cyclical(values = c("#bbc8dd", "#47659e"))+
        scale_x_continuous(limits=c(0,3),breaks=c(0,1,2),expand=c(0,0))+
        scale_color_manual(values = c("grey30"),labels=c("1"=expression(R["t"])))+
        labs(y =NULL,x =NULL)+
        #labs(y =NULL,x =expression("Posterior predicted"*"  "*R["t"]))+
        theme(legend.position = "none",
              legend.background = element_rect(fill=NA),
              legend.key.size = unit(9, "pt"),
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              legend.title=element_blank(),
              plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
              #axis.text.x= element_text(color="black",size = unit(9, "pt")),
              axis.text.x= element_blank(),
              #axis.text.y=element_blank(),
              axis.text.y= element_text(color="black",size = unit(6, "pt")),
              plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
              panel.background=element_rect(fill = "transparent",colour = NA))
      #ggsave(paste0(outpath,"/Posterior_r0tDistributionPlot_",i,d,".pdf"),fg,units="mm",width=50,height=80,device = cairo_pdf)
      return(fg)
    })
    for(u in 1:length(postlist)){
      if(u>6){
        postlist[[u]]<-postlist[[u]]+theme(axis.title.x= element_text(color="black",size =unit(9, "pt")),
                                           axis.text.x = element_text(color="black",size = unit(9, "pt")))}
    }
    grid.arrange(g_legend(legend),arrangeGrob(grobs = postlist,ncol = 3),heights = c(0.3,9),
                 top=textGrob(paste0("Posterior of ",i)),
                 bottom=textGrob(expression("Posterior predicted"*"  "*R["t"])))
    print(paste0(i,"has beenn processed"))
  })
  dev.off()
}
path="20220329_V2normal(0,0.3)0.5/R0_calculate"
DatasetV2<-read.csv("20220329_V2normal(0,0.3)0.5/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
xname=c("StringencyIndex","Fully_vaccinated_pre","Interaction")
outname<-"Prior&posterior_predictive_check"
inpath<-"20220329_V2normal(0,0.3)0.5result"
outpath="20220329_V2normal(0,0.3)0.5result/pri_post"
compare_piror_postV2(DatasetV2,path,outname,xname,inpath)
plot_piror_post(DatasetV2,path,outname,xname,inpath)
dev.off()