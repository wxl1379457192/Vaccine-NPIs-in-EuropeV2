library("rstan")
library("bayesplot")
library("zoo")
library("dplyr")
library("reshape2")
library("scales")
library("ggridges")
library("ggthemes")
library("ggcor")
library("ggplot2")
library("gridExtra")
library("ggalt")
library("aomisc")
library("meta")
library("RColorBrewer")
library("grid")
library("Hmisc")
library("ggthemr")
library("caret")
setwd("E:/COVID19_vacciantion1210")#set up your setwd here
Sys.setlocale("LC_TIME","English")
source('code/main.R')
source('code/rstanmain.R')
RT<-read.csv("Dataset/owid-covid-data.csv")# Daily reproduction rate data (Rt)
Variants<-read.csv("Dataset/covid-variants.csv")# Weekly variant structure data
NPI<-"Dataset/OxCGRT_latest.csv" # Daily non-pharmaceutical interventions data (NPI)
POP<-"Dataset/pop_data_age_by_country.csv" # Total population number of each country
index<-'Dataset/index.csv'# Control variables, contained population density, age structre and health index of each country
Env<-'Dataset/20200120-20211201humidity&airtem.csv'# Control variables, contained temperature and humidity. Only air temperature were considered in our study
Vaccination<-'Dataset/vaccinations.csv' # Daily vaccination data 
Vaccman<-'Dataset/vaccinations-by-manufacturer.csv'# Weekly vaccination manufacturer structure
agedata<-"Dataset/pop_structure_data.csv"
school_holiday<-"Dataset/day_public_and_school_holidays_2010_2019.csv"
vaccine_effect<-"Dataset/vaccine_effectiveness_V1.csv"
#vaccine_effect<-"Dataset/vaccine_effectiveness_S2.csv"
variant_tran<-"Dataset/variant_transmission.csv"# transmission parameters of each variant


#################pooling all countries###########################
pooling<-function(RT,Variants,Vaccination,NPI,POP,index,Env,
                  vaccine_effect,variant_tran,outpath,xname){
  Dataset<-merge_dataset(RT,Variants,Vaccination,NPI,POP,index,Env)
  Dataset<-subset(Dataset,Dataset$continent=="Europe"|Dataset$location=="Israel")
  gc()
  DatasetV2<-RatioVariable_merge(Dataset,vaccine_effect,variant_tran,list=c(1:length(unique(Dataset$location))))
  
  if (length(xname)>2){
    DatasetV2$Interaction<-DatasetV2[,xname[1]]*DatasetV2[,xname[2]]
  }
  write.csv(DatasetV2,paste0(outpath,"/Europe_dataset_withinR0_pooling.csv"),row.names = F)
  #DatasetV2<-read.csv(paste0(outpath,"/Europe_dataset_withinR0_pooling.csv"),stringsAsFactors = F)
  fit<-pooling_process(DatasetV2,source=paste0(outpath,"/R0_calculate/"),xname)
}
pooling_process<-function(DatasetV2,source,xname){
  if (dir.exists(source)==F){dir.create(source)
  }else{print("This path has been exists")}
  output<-paste0(source,"all.rds")
  start<-as.Date("2020-08-01")
  end<-as.Date("2021-10-26")
  mcon<-stan_model('stanmodel/stan_R0withinModel_pooling.stan')
  fit<-alpha_calculate_pooling(mcon,DatasetV2,start,end,output,xname)
  return(fit)
}
outpath<-"pooling_witheachcountry"
if (dir.exists(outpath)==F){dir.create(outpath)
}else{print("This path has been exists")}
fit<-pooling(RT,Variants,Vaccination,NPI,POP,index,Env,
        vaccine_effect,variant_tran,outpath,
        xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"))