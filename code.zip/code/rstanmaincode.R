
alpha_calculate_withinR0_con<-function(mcon,DatasetV2,start,
                                       end,output,
                                       xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),monthnum=15){
  r0<-max(DatasetV2$Rt[which(DatasetV2$Date<"2020-12-01"&DatasetV2$Date>=start)])
  vv<-read.csv(variant_tran,stringsAsFactors = F)
  D<-subset(DatasetV2,DatasetV2$Date>=start&DatasetV2$Date<end)
  D<-unique(D)
  if (max(D[,xname[2]])==0){
    X1<-as.matrix(D[,xname[1]])
  }else{
    X1<-as.matrix(D[,xname])
  }
  X2<-as.matrix(D[,c("Tem")])
  variant_ratio<-as.matrix(D[,c("alphaN","betaN","gammaN","etaN","kappaN","deltaN","baseN")])
  variant_sd<-as.vector(approx_sd(vv$IQR.,vv$IQR..1))
  X2<-(X2-min(X2))/(max(X2)-min(X2))
  Rt<-as.vector(D[,"Rt"])
  dataset<-list(m=length(Rt), k1=ncol(X1), k2=ncol(X2),
                X2=X2 ,X1=X1, Rt=Rt,r0=r0,
                variant_ratio=variant_ratio, variant_sd=variant_sd,n=monthnum)  
  rstan_options(auto_write = TRUE)
  set.seed(11)
  fit<-rstan::sampling(object = mcon,data=dataset,iter=5000,warmup=2500,
                       chains=4,thin=1,control = list(adapt_delta = 0.95, max_treedepth =10))
  saveRDS(fit, file = output)
  #tp<-traceplot(fit,pars="alpha")
  return(fit)
}

alpha_calculate_withinR0_all<-function(mcon,DatasetV2,start,
                                       end,output,
                                       xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),monthnum=15){
  r0<-do.call(rbind,lapply(split(DatasetV2,DatasetV2$iso_code),function(k){
    max(k$Rt[which(k$Date<"2020-12-01"&k$Date>=start)])
  }))
  c<-length(unique(DatasetV2$iso_code))
  vv<-read.csv(variant_tran,stringsAsFactors = F)
  D<-subset(DatasetV2,DatasetV2$Date>=start&DatasetV2$Date<end)
  D<-unique(D)
  if (max(D[,xname[2]])==0){
    X1<-as.matrix(D[,xname[1]])
  }else{
    X1<-as.matrix(D[,xname])
  }
  X2<-as.matrix(D[,c("Tem")])
  variant_ratio<-as.matrix(D[,c("alphaN","betaN","gammaN","etaN","kappaN","deltaN","baseN")])
  variant_sd<-as.vector(approx_sd(vv$IQR.,vv$IQR..1))
  X2<-(X2-min(X2))/(max(X2)-min(X2))
  Rt<-as.vector(D[,"Rt"])
  r0<-as.vector(r0)
  dataset<-list(m=length(Rt), k1=ncol(X1), k2=ncol(X2),c=c,
                X2=X2 ,X1=X1, Rt=Rt,r0=r0,
                variant_ratio=variant_ratio, variant_sd=variant_sd,n=monthnum)  
  rstan_options(auto_write = TRUE)
  set.seed(11)
  fit<-rstan::sampling(object = mcon,data=dataset,iter=2000,warmup=500,
                       chains=4,thin=1,control = list(adapt_delta = 0.95, max_treedepth =10))
  saveRDS(fit, file = output)
  #tp<-traceplot(fit,pars="alpha")
  return(fit)
}
alpha_calculate_pooling<-function(mcon,DatasetV2,start,end,output,
                                  xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction")){
  DatasetV2<-subset(DatasetV2,DatasetV2$Date>=start&DatasetV2$Date<end)
  r0<-do.call(rbind,lapply(split(DatasetV2,DatasetV2$iso_code),function(k){
    max(k$Rt[which(k$Date<"2020-12-01"&k$Date>=start)])
  }))
  n<-length(unique(DatasetV2$iso_code))
  m<-as.integer(nrow(DatasetV2)/n)
  vv<-read.csv(variant_tran,stringsAsFactors = F)
  X1<-as.matrix(DatasetV2[,xname])
  X2<-as.matrix(DatasetV2[,c("Tem")])
  variant_ratio<-as.matrix(DatasetV2[,c("alphaN","betaN","gammaN","etaN","kappaN","deltaN","baseN")])
  variant_sd<-as.vector(approx_sd(vv$IQR.,vv$IQR..1))
  X2<-(X2-min(X2))/(max(X2)-min(X2))
  Rt<-as.vector(DatasetV2[,"Rt"])
  r0<-as.vector(r0)
  dataset<-list(m=m, n=n, k1=ncol(X1), k2=ncol(X2),
                X1=X1 ,X2=X2, Rt=Rt,r0=r0,
                variant_ratio=variant_ratio, variant_sd=variant_sd)  
  rstan_options(auto_write = TRUE)
  set.seed(11)
  fit<-rstan::sampling(object = mcon, data=dataset,iter=15000,warmup=5000,
                       chains=4,thin=1,control = list(adapt_delta = 0.95, max_treedepth =10))
  saveRDS(fit, file = output) 
  return(fit)
}

alpha_calculate_SEforR0<-function(mcon,DatasetV2,start,r0,
                                  end,output,xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"),monthnum=15){
  r0<-r0$R0[which(r0$country_territory==unique(DatasetV2$location))]
  vv<-read.csv(variant_tran,stringsAsFactors = F)
  D<-subset(DatasetV2,DatasetV2$Date>=start&DatasetV2$Date<end)
  D<-unique(D)
  if (max(D[,xname[2]])==0){
    X1<-as.matrix(D[,xname[1]])
  }else{
    X1<-as.matrix(D[,xname])
  }
  X2<-as.matrix(D[,c("Tem")])
  variant_ratio<-as.matrix(D[,c("alphaN","betaN","gammaN","etaN","kappaN","deltaN","baseN")])
  variant_sd<-as.vector(approx_sd(vv$IQR.,vv$IQR..1))
  X2<-(X2-min(X2))/(max(X2)-min(X2))
  Rt<-as.vector(D[,"Rt"])
  dataset<-list(m=length(Rt), k1=ncol(X1), k2=ncol(X2),
                X2=X2 ,X1=X1, Rt=Rt,r0=r0,
                variant_ratio=variant_ratio, variant_sd=variant_sd,n=monthnum)  
  rstan_options(auto_write = TRUE)
  set.seed(11)
  fit<-rstan::sampling(object = mcon,data=dataset,iter=1000,warmup=500,
                       chains=4,thin=1,control = list(adapt_delta = 0.95, max_treedepth =10))
  saveRDS(fit, file = output)
  #tp<-traceplot(fit,pars="alpha")
  return(fit)
}