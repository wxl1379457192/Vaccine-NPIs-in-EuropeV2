########open risk calculate##############

CCcalculate<-function(cases){
  cases$date<-as.Date(cases$date)
  cc<-cases[,c("location","date","new_cases","people_fully_vaccinated_per_hundred","new_cases_per_million")]
  cc$people_fully_vaccinated_per_hundred[is.na(cc$people_fully_vaccinated_per_hundred)]<-0
  
  #cc$people_fully_vaccinated_per_hundred<-cummax(cc$people_fully_vaccinated_per_hundred)
  c<-do.call(rbind,lapply(split(cc,cc$location),function(c){
    cofc<-do.call(rbind,lapply(split(c,c$date),function(t){
      if ((t$date-min(c$date))>7){
        t$delta_c<-mean(c$new_cases[which(c$date>=(t$date-7)&c$date<t$date)])
      }else{t$delta_c<-NA}
      t$cc<-t$delta_c
      t$cc[which(t$cc>=50)]<-50
      t$EndemicFactorV<-(1-t$people_fully_vaccinated_per_hundred/100)
      t$EndemicFactorV[which(t$EndemicFactorV<0)]<-0
      t$EndemicFactor<-(t$new_cases_per_million-50)/150
      t$EndemicFactor[which(t$new_cases_per_million>200)]<-1
      t$EndemicFactor[which(t$new_cases_per_million<50)]<-0
      return(t)
    }))
    return(cofc)
  }))
  c$CC<-c$cc/50
  return(c)
}
TTMcalculate<-function(oxcgrt,cases){
  oxcgrt<-oxcgrt[which(oxcgrt$RegionName==""),]
  oxcgrt$Date<-as.Date.character(oxcgrt$Date,format="%Y%m%d")
  ox<-oxcgrt[,c("CountryName","Date","H2_Testing.policy","H3_Contact.tracing","C8_International.travel.controls")]
  colnames(ox)<-c("location","date","H2","H3","C8")
  test<-cases[,c("location","date","tests_per_case")]
  tt<-do.call(rbind,lapply(split(ox,ox$location),function(o){
    c<-subset(test,test$location==unique(o$location))
    m<-merge(o,c,by=c("location","date"))
    
    m<-m[which(is.na(m$tests_per_case)==F),]
    if(nrow(m)>0){
    m$TT<-0.25*(1-m$H2/3)+0.25*(1-m$H3/2)+0.5*(log(max(m$tests_per_case))-log(m$tests_per_case))/(log(max(m$tests_per_case))-log(min(m$tests_per_case)))
    m$M<-1
    m$M[which(m$C8==1)]<-0.5
    m$M[which(m$C8==2)]<-0.25
    m$M[which(m$C8>=3)]<-0
    m$M[is.na(m$C8)]<-NA
    }else{m<-NULL}
    return(m)
  }))
  return(tt)
}
riskalculate<-function(mobility,cases,ode="2021-10-25"){
  cc<-CCcalculate(cases)
  cc<-cc[which(cc$date==ode),]
  mobi<-mobility[which(mobility$sub_region_1==""),]
  mob<-mobi[,c("country_region","date","retail_and_recreation_percent_change_from_baseline",
               "transit_stations_percent_change_from_baseline","workplaces_percent_change_from_baseline")]
  colnames(mob)<-c("country_region","date","retail","transit","workplaces")
  #mob$date<-as.Date(mob$date)
  mob<-mob[which(mob$date==ode),]
  #mob[is.na(mob)]<-0
  mob$retail<-mob$retail+100
  mob$retail[which(mob$retail<100)]<-100-mob$retail[which(mob$retail<100)]
  mob$transit<-mob$transit+100
  mob$transit[which(mob$transit<100)]<-100-mob$transit[which(mob$transit<100)]
  mob$workplaces<-mob$workplaces+100
  mob$workplaces[which(mob$workplaces<100)]<-100-mob$retail[which(mob$workplaces<100)]
  mob$mob<-apply(mob[,c(3:5)],1,mean)
  mob$mob[which(mob$mob<(-20))]<--20
  mob$mob[which(mob$mob>20)]<-20
  mob<-mob[,c("country_region","date","mob")]
  colnames(mob)<-c("location","date","mob")
  C<-merge(cc,mob,by=c("location","date"))
  C<-C[complete.cases(C),]
  C$C<-0.5*(1+C$CC)*(C$mob-(-20))/40
  TTM<-TTMcalculate(oxcgrt,cases)
  TTM<-TTM[which(TTM$date==ode),]
  ROI<-merge(C,TTM,by=c("location","date"))
  ROI$ROOI<-apply(ROI[,c("CC","TT","M","C")],1,mean)
  ROI$risk<-ROI$EndemicFactor+(1-ROI$EndemicFactor)*ROI$ROOI
  ROI$riskV<-ROI$EndemicFactorV+(1-ROI$EndemicFactorV)*ROI$ROOI
  return(ROI)
}
fig4plot<-function(risk,figpath,DatasetV2,outpath){
  risk<-do.call(rbind,split(risk,risk$location)[unique(DatasetV2$location)])
  risk$date<-as.Date(risk$date)
  rd<-read.csv(figpath,stringsAsFactors = F)
  l<-rd[,c("parameter","m","strength","start","country")]
  l<-subset(l,l$parameter=="all_SI")
  l$strength<-l$strength*100
  fit <- nls(m ~ strength^b, start = list( b= 0),data=l)
  fit<-summary(fit)
  b<-fit$coefficients[1]
  dda<-max(DatasetV2$Date)
  Rtdata<-DatasetV2[,c("location","iso_code","Date","R0","Rt","Fully_vaccinated_effect","StringencyIndex")]
  Rtdata<-subset(Rtdata,Rtdata$Date==dda)
  Rtdata<-Rtdata%>%distinct(location,Date,.keep_all = T)
  Rt<-Rtdata
  Rt<-Rtdata[,-3]%>%dplyr::group_by(location,iso_code)%>%dplyr::summarise_each(funs(mean))
  Rt$Reduction<-(Rt$Rt-1)/Rt$R0*100
  Rt$Open<-abs(Rt$Reduction)^(1/b)
  Rt$Open[which(Rt$Reduction<0)]<--Rt$Open[which(Rt$Reduction<0)]
  write.csv(Rt,paste0(outpath,"/fig4a_result.csv"),row.names = F)
  colnames(Rt)<-c("location","adm0_a3",names(Rt)[-c(1,2)])
  world <- ne_countries(scale = "medium",type = 'map_units', returnclass = "sf")
  class(world)
  world<-full_join(world,Rt,by="adm0_a3")
  world<-world[-which(world$adm0_a3=="ATA"),]
  p1<-ggplot() +geom_sf(data = world,aes(fill=Open), inherit.aes = F,size=0.1)+  
    scale_fill_gradientn(colors =c("#51a1b5","#fddc8c","#a62b1f"),na.value  = "#ededed")+
    coord_sf(expand = FALSE,crs=4326) +
    scale_x_continuous(limits=c(-25,45))+
    scale_y_continuous(limits=c(25,75))+
    theme_bw()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          legend.text = element_text(size = unit(9,"pt")),
          legend.background = element_rect(fill="transparent",color=NA),
          legend.key=element_rect(fill=NA),
          plot.title = element_text(color="black",hjust = 0,vjust=0, size=unit(9,"pt")),
          axis.ticks= element_line(color="black"),
          axis.text = element_text(color="black",vjust=0,hjust=0, size=unit(9,"pt")),
          panel.background=element_rect(fill = "transparent",colour = NA),
          axis.line = element_line(size=0.05),
          axis.title = element_text(color="black", size=unit(9,"pt")))
  ggsave(p1, filename = paste0(outpath,"/fig4a.pdf"),width=75,heigh=85,unit="mm",device = cairo_pdf)
  
  #r1<-risk[,c("location","risk")]
  #r<-merge(Rt,r1,by="location")
  #g2<-ggplot(r,aes(x=Open,y=risk))+geom_point(aes(color=StringencyIndex,size=Fully_vaccinated_effect))+
  #  geom_vline(aes(xintercept=0),linetype=2,size=0.2)+geom_hline(aes(yintercept=0.5),linetype=2,size=0.2)+
  #  geom_text(aes(label=location), nudge_y = 0.04,size=unit(2,"pt"))+
  #  scale_size_continuous(range =c(0.5,1.5))+
    #scale_y_continuous(limits=c(0,1))+
  #  scale_x_continuous(limits=c(-50,50),expand=c(0,0))+
   # theme_bw()+
  #  theme(legend.position = "bottom",
  #        legend.title=element_blank(),
  #        legend.text = element_text(size = unit(9,"pt")),
  #        legend.background = element_rect(fill="transparent",color=NA),
  #        legend.key=element_rect(fill=NA),
  #        plot.title = element_text(color="black",hjust = 0,vjust=0, size=unit(9,"pt")),
  #        axis.ticks= element_line(color="black"),
   #       axis.text = element_text(color="black",vjust=0,hjust=0, size=unit(9,"pt")),
  #        panel.background=element_rect(fill = "transparent",colour = NA),
  #        axis.line = element_line(size=0.05),
  #        axis.title = element_text(color="black", size=unit(9,"pt")))
  #ggsave(g2, filename = paste0(outpath,"/fig4b.pdf"),width=75,heigh=85,unit="mm",device = cairo_pdf)
  
  r2<-risk[,c("location","riskV")]
  r<-merge(Rt,r2,by="location")
  gV<-ggplot(r,aes(x=Open,y=riskV))+
    geom_rect(aes(ymin = 0.5, ymax = 1, xmin = 0, xmax = 50),fill="grey90",alpha=0.1)+
    geom_rect(aes(ymin = 0, ymax = 0.5, xmin = -50, xmax = 0),fill="grey95",alpha=0.1)+
    geom_point(aes(color=StringencyIndex,size=Fully_vaccinated_effect))+
    geom_vline(aes(xintercept=0),linetype=2,size=0.2)+geom_hline(aes(yintercept=0.5),linetype=2,size=0.2)+
    geom_text(aes(label=location), nudge_y = -0.04,size=unit(2,"pt"))+
    scale_size_continuous(range =c(0.5,1.5))+
    scale_y_continuous(limits=c(0,1),expand=c(0.005,0.005))+
    scale_x_continuous(limits=c(-50,50),expand=c(0.01,0.01))+
    theme_bw()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          legend.text = element_text(size = unit(9,"pt")),
          legend.background = element_rect(fill="transparent",color=NA),
          legend.key=element_rect(fill=NA),
          plot.title = element_text(color="black",hjust = 0,vjust=0, size=unit(9,"pt")),
          axis.ticks= element_line(color="black"),
          axis.text = element_text(color="black",vjust=0,hjust=0, size=unit(9,"pt")),
          panel.background=element_rect(fill = "transparent",colour = NA),
          axis.line = element_line(size=0.05),
          axis.title = element_text(color="black", size=unit(9,"pt")))
  ggsave(gV, filename = paste0(outpath,"/fig4bV.pdf"),width=75,heigh=85,unit="mm",device = cairo_pdf)
  return(r)
}
##############fig 4: open risk##############
setwd("E:/COVID19_vacciantion1210")
cases<-read.csv("Dataset/owid-covid-data.csv",stringsAsFactors = F)
oxcgrt<-read.csv("Dataset/OxCGRT_latest.csv",stringsAsFactors = F)
mobility<-read.csv("Dataset/Global_Mobility_Report.csv",stringsAsFactors = F)
library("rstatix")
library("rnaturalearth")
risk<-riskalculate(mobility,cases,ode="2021-10-25")# an openness risk calculated by Hale et al.

DatasetV2<-read.csv("20220329_V2normal(0,0.3)0.5/R0_Europe_dataset_withinR0.csv",stringsAsFactors = F)
figpath<-"20220329_V2normal(0,0.3)0.5result/SI_country_20220330.csv"
outpath<-"20220329_V2normal(0,0.3)0.5result"
write.csv(risk,paste0(outpath,"/openrisk.csv"),row.names = F)
r<-fig4plot(risk,figpath,DatasetV2,outpath)
r%>%select(riskV,Open)%>%cor_test()
cor.test(r$riskV,r$Open, type="pearson") 

write.csv(r,paste0(outpath,"/openrisk_risk.csv"),row.names = F)


