library("rstan")
library("bayesplot")
library("zoo")
library("dplyr")
library("reshape2")
library("scales")
library("ggridges")
library("ggthemes")
library("ggcor")
library("ggplot2")
library("gridExtra")
library("ggalt")
library("aomisc")
library("meta")
library("RColorBrewer")
library("grid")
library("Hmisc")
library("ggthemr")
library("caret")
setwd("E:/COVID19_vacciantion1210")#set up your setwd here
Sys.setlocale("LC_TIME","English")
source('code/maincode.R')
source('code/rstanmaincode.R')


##################load data################################################
RT<-read.csv("Dataset/owid-covid-data.csv")# Daily reproduction rate data (Rt)
Variants<-read.csv("Dataset/covid-variants.csv")# Weekly variant structure data
NPI<-"Dataset/OxCGRT_latest.csv" # Daily non-pharmaceutical interventions data (NPI)
POP<-"Dataset/pop_data_age_by_country.csv" # Total population number of each country
index<-'Dataset/index.csv'# Control variables, contained population density, age structre and health index of each country
Env<-'Dataset/20200120-20211201humidity&airtem.csv'# Control variables, contained temperature and humidity. Only air temperature were considered in our study
Vaccination<-'Dataset/vaccinations.csv' # Daily vaccination data 
Vaccman<-'Dataset/vaccinations-by-manufacturer.csv'# Weekly vaccination manufacturer structure
agedata<-"Dataset/pop_structure_data.csv"
school_holiday<-"Dataset/day_public_and_school_holidays_2010_2019.csv"
vaccine_effect<-"Dataset/vaccine_effectiveness_V1.csv"
#vaccine_effect<-"Dataset/vaccine_effectiveness_S2.csv"
variant_tran<-"Dataset/variant_transmission.csv"# transmission parameters of each variant
#############################################################################


##############################################################
#############NPI effect for each country#####################
mainpath<-"20220329_V2normal(0,0.3)0.5"#set your output path here
if (dir.exists(mainpath)==F){dir.create(mainpath)
}else{print("This path has been exists")}
R0process(RT,Variants,Vaccination,NPI,POP,index,Env,
          vaccine_effect,variant_tran,i,mainpath,
          mcon=stan_model('stanmodel/stan_R0withinModel.stan'),
          #replace it with the right version of stan model
          xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"), #xname can be replaced by any NPIs of your intrest
          monthnum=15) # monthnum: the number of months during your study period
###############################################################################

############################################################################
##########Leave-one-out validation data process##############################
valpath<-"20220329_V2normal(0,0.3)0.5result" #set your output path of validation result here
if (dir.exists(valpath)==F){dir.create(valpath)
}else{print("This path has been exists")}
Leave_one_out_Validation(Datapath= mainpath, valpath,
                         mcon=stan_model('stanmodel/stan_R0withinModel.stan'),
                         xname=c("StringencyIndex","Fully_vaccinated_effect","Interaction"))
##############################################################################

################################################################################
####################fig 2 & meta anlaysis########################################
DatasetV2<-R0extract(paste0(mainpath, "/R0_calculate"))
outpath<-"result" #set your output path to store your main results
if (dir.exists(outpath)==F){dir.create(outpath)
}else{print("This path has been exists")}
counresultplot(DatasetV2,
               paste0(mainpath, "/R0_calculate"), 
               outname = "20220329",
               xname = c("StringencyIndex","Fully_vaccinated_effect","Interaction"),
               outpath)
meta_alalysis(DatasetV2,
              paste0(mainpath, "/R0_calculate"),outname = "20220329",
              xname = c("StringencyIndex","Fully_vaccinated_effect","Interaction"),
              outpath)
meta_R0(DatasetV2, paste0(mainpath, "/R0_calculate"), outname = "20220329",outpath)
R0plot(DatasetV2, "R0V2", outpath)
#################################################################################

##################################################################
###############fig 3##############################################
source('code/fig3plot.R')
fig3plot(inputpath = mainpath,
         figpath = "result/SI_country_20220330.csv",
         outpath = outpath)
##################################################################

##################################################################
########coefficient extract#######################################
path<-paste0(mainpath, "/R0_calculate")
country_coefficient(DatasetV2,
                    path,
                    outname="20220330",
                    xname=c("StringencyIndex","Fully_vaccinated_pre","Interaction"),
                    outpath)
meta_coefficient(DatasetV2,
                 path,
                 outname="20220330",
                 xname=c("StringencyIndex","Fully_vaccinated_pre","Interaction"),
                 outpath)
##################################################################


##################################################################
################SI coefficient variation plot: Fig B6-B10#####################
Coe<-read.csv(paste0(outpath,"/Country_cofficient_20220330.csv"),stringsAsFactors = F)
meta<-read.csv(paste0(outpath,"/Meta_coefficient_20220330.csv"),stringsAsFactors = F)
Coe$parameter[which(Coe$parameter=="StringencyIndex")]<-"Stringency Index"
Coe$parameter[which(Coe$parameter=="Fully_vaccinated_pre")]<-"Vaccination"
Coe$parameter[which(Coe$parameter=="Interaction")]<-"Interaction of SI and Vaccination"
concol<-c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7",
          "#777777", "#f6be6a", "#79add0", "#398367", "#d6ca67", "#4e88bf", "#af4f08", "#d68fb5",
          "#a2a2a2", "#fcce8f", "#b4d9f4", "#74bfa0", "#b9b182", "#769ecc", "#8a400d", "#e8bcd2",
          "#d0d0d0", "#fcce8f", "#e7f2fc", "#bbdfce", "#aaa58e", "#9ab6d9", "#67310e", "#b296a4")
fig<-lapply(split(Coe,Coe$parameter),function(k){
  m<-subset(meta,meta$par==unique(k$parameter))
  fig<-ggplot()+
    geom_line(data=k,aes(x=as.Date(start),y=m,color=country),size=0.2,alpha=0.4,linetype=2)+
    geom_line(data=m,aes(x=as.Date(start),y=m),color="grey20",size=0.5,alpha=0.7)+
    #geom_ribbon(data=m,aes(x=as.Date(start), ymin = lower, ymax = upper),fill="#cbd5ea", alpha = 0.3)+
    scale_color_manual(values=concol)+
    scale_x_date(limits=as.Date(c("2020-08-01","2021-10-01")),
                 breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0.01,0.01))+
    labs(y =paste("Coefficient of",tolower(unique(k$parameter))),x = NULL)+theme_light()+
    theme(legend.position = "none",
          legend.background = element_rect(fill=NA,color = NA),
          legend.key.size = unit(9, "pt"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.x= element_text(color="black",size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/Coefficient_",unique(k$parameter),".pdf"),fig,
         units="mm",width=140,height=80,device = cairo_pdf)
  return(fig)
})
dev.off()
legend<-fig[[1]]+geom_line(data=k,aes(x=as.Date(start),y=m,color=country),size=0.35,alpha=1,linetype=2)+
  guides(color=guide_legend(nrow=7)) +
  theme(legend.position = "bottom")
mylegend<-g_legend(legend)
leg<-grid.arrange(mylegend)
ggsave(paste0(outpath,"/Coefficient_legend.pdf"),leg,
       units="mm",width=180,height=120,device = cairo_pdf)
###############################################################################



###############################################################################
##################SI: RSS and Rhat plot#########################################
path<- paste0(mainpath, "/R0_calculate/")
efdata<-list()
list<-list.files(path)
conresult<-do.call(rbind,lapply(list,function(l){
  f<-readRDS(paste0(path,l,"/all.rds"))
  rhat<-as.data.frame(rhat(f))
  Rneff<-as.data.frame(neff_ratio(f))
  dd<-do.call(cbind,list(rhat,Rneff))
  colnames(dd)<-c("rhat","R_ESS")
  return(dd)
}))
valplot<-list()
valplot[[1]]<-ggplot(conresult,aes(rhat))+
  geom_histogram(bins=100,colour="white",fill="#a23434",size=0.01)+
  labs(x=NULL,y=NULL,title="a")+
  scale_x_continuous(expand=c(0,0),limits=c(0.998,1.045))+
  scale_y_continuous(expand=c(0,0))+geom_vline(xintercept = 1,linetype ="dotdash",size=1)+
  theme(axis.line.y= element_blank(),
        axis.text.y = element_blank(),
        axis.text.x =element_text(size = unit(9, "pt")),
        axis.ticks.y = element_blank(),
        axis.title.y = element_blank(),
        legend.position = "none",
        plot.title=element_text(size = unit(9, "pt"),hjust=0),
        panel.grid=element_blank(),
        axis.line.x = element_line(colour = "black"),
        axis.ticks.x = element_line(colour = "black"),
        panel.background=element_rect(fill = "transparent",colour = NA),
        plot.margin=unit(c(0.1,0.2,0.1,0.2),"cm"),
        axis.text=element_text(size = unit(9, "pt")))
valplot[[2]]<-ggplot(conresult,aes(R_ESS))+
  geom_histogram(bins=100,colour="white",fill="#a23434",size=0.01)+
  labs(x=NULL,y=NULL,title="b")+scale_x_continuous(expand=c(0.02,0.02),limits=c(0,1.2))+
  geom_vline(xintercept = 1,linetype ="dotdash",size=1)+
  scale_y_continuous(expand=(c(0,0)))+
  theme(axis.line.y= element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        axis.title.y = element_blank(),
        legend.position = "none",
        axis.text.x =element_text(size = unit(9, "pt")),
        plot.title=element_text(size =unit(9, "pt"),hjust=0),
        panel.grid=element_blank(),
        axis.line.x = element_line(colour = "black"),
        axis.ticks.x = element_line(colour = "black"),
        panel.background=element_rect(fill = "transparent",colour = NA),
        plot.margin=unit(c(0.1,0.2,0.1,0.2),"cm"),
        axis.text=element_text(size = unit(9, "pt")))
plot<-grid.arrange(arrangeGrob(grobs =valplot,ncol =2))
ggsave(paste0(outpath,"/mcmc_convergence.pdf"),plot,units="mm",width=85,height=40,device = cairo_pdf)
############################################################################################


#############################################################################################
#############SI: Correlation analysis########################################################
N<-DatasetV2[,c("R0","Rt","StringencyIndex","Fully_vaccinated_effect","Interaction","Tem","Hum")]
colnames(N)<-c("R0","R0,t","Stringency index","Pratical vaccination rate","Interaction of SI and vaccination","Temperature","Humidity")
cor<-COR(N)
ggsave(paste0(outpath,"/correlation_analysis.pdf"),cor,width=180,height=180,units="mm",device = cairo_pdf)
###########################################


