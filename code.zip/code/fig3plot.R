
###################### part III: Impact of vaccination on the effectiveness of NPIs ###############

library("rcompanion")
library("tidyverse")
library("investr")
library("modelr")
library("grid")
library("ggpubr")

fig3plot<-function(inputpath,figpath,outpath){
  #<-read.csv(figpath,stringsAsFactors = F)
  #rd<-subset(rd,rd$parameter=="StringencyIndex"|rd$parameter=="Fully_vaccinated_effect")
  #rd<-subset(rd,rd$parameter=="all_SI"|rd$parameter=="all_V")
  #l<-rd[,c("parameter","m","strength","start","country")]
  #si<-subset(l,l$parameter=="all_SI")[,c(1,2,3,4)]
  #colnames(si)<-c("par","m","s","start")
  #v<-subset(l,l$parameter=="all_V")[,c(1,2,3,4)]
  #colnames(v)<-c("par","m","v","start")
  #ss<-merge(si,v[,c("v","start")])
  #vv<-merge(v,si[,c("s","start")])
  #l<-do.call(rbind,list(ss,vv))

  rd<-read.csv(figpath,stringsAsFactors = F)
  rd<-subset(rd,rd$parameter=="StringencyIndex"|rd$parameter=="Fully_vaccinated_effect")
  l<-rd[,c("parameter","m","strength","start","country")]
  si<-subset(l,l$parameter=="StringencyIndex")[,c(1,2,3,4)]
  colnames(si)<-c("par","m","s","start")
  v<-subset(l,l$parameter=="Fully_vaccinated_effect")[,c(1,2,3,4)]
  colnames(v)<-c("par","m","v","start")
  ss<-merge(si,v[,c("v","start")])
  vv<-merge(v,si[,c("s","start")])
  l<-do.call(rbind,list(ss,vv))
  
  l$v1<-cut(l$v*100,breaks=seq(-10,80,10))
  l$s1<-cut(l$s*100,breaks=seq(-10,100,10))
  l$label<-"After vaccination"
  l$label[which(l$v==0)]<-"Before vaccination"
  lfig<-subset(l,l$v>0)
  lfig3<-subset(l,l$v==0)
  lfig3<-subset(lfig3,lfig3$par=="StringencyIndex")
  lfig1<-subset(lfig,lfig$par=="StringencyIndex")
  #lfig1<-subset(lfig1,lfig1$m>0.01)
  lfig2<-subset(lfig,lfig$par=="Fully_vaccinated_effect")
  lfig1$v1<-as.factor(lfig1$v1)
  mydata1<-do.call(rbind,lapply(split(lfig,lfig$v1),function(d){
    d$s1<-as.factor(d$s1)
    #f<-do.call(rbind,lapply(split(d,d$s1),function(d1){
      return(data.frame(m_SI=median(d$m[which(d$par=="StringencyIndex")]),
                        m_V=median(d$m[which(d$par=="Fully_vaccinated_effect")]),
                        v1=as.factor(d$v1[1])))
    #}))
    #return(f)
  }))

  #my_comparisons <- list(c("(0,20]", "(20,40]"), c("(0,20]", "(40,60]"),  c("(20,40]", "(40,60]"))
  #my_comparisons <- list(c("(0,10]", "(10,20]"), c("(0,10]", "(20,30]"), c("(0,10]", "(30,40]"),c("(0,10]", "(40,50]"), c("(0,10]", "(50,60]"),
  #                       c("(10,20]", "(20,30]"), c("(10,20]", "(30,40]"),c("(10,20]", "(40,50]"), c("(10,20]", "(50,60]"),
  #                       c("(20,30]", "(30,40]"), c("(20,30]", "(40,50]"), c("(20,30]", "(50,60]"),
  #                       c("(30,40]", "(40,50]"),c("(30,40]", "(50,60]"),c("(40,50]", "(50,60]")) 
  fig3a<-ggplot()+
    geom_flat_violin(data=lfig3,aes(x=as.factor(v1),y=m),fill ="#7f97bd", 
                     alpha=0.4, color="black",width=1,size=0.1)+
    geom_flat_violin(data=lfig1,aes(x=as.factor(v1),y=m),fill ="#7f97bd", 
                     alpha=0.4, color="black",width=1,size=0.1)+
    geom_boxplot(data=lfig2,aes(x=as.factor(v1),y=m),width=0.2,position=position_nudge(x=0.6),
                 color="#723f39",fill="#d4afaa",alpha=0.4,size=0.1,outlier.size = 0.1)+
    geom_jitter(data=lfig1,aes(x=as.factor(v1),y=m,color=s),position=position_nudge(x=-0.05),size=0.1,alpha=0.8)+
    geom_jitter(data=lfig3,aes(x=as.factor(v1),y=m,color=s),position=position_nudge(x=-0.05),size=0.1,alpha=0.8)+
    scale_color_gradientn(colours=brewer.pal(7,"PuBuGn"),breaks=c(min(lfig1$s),max(lfig1$s)))+
    scale_fill_gradientn(colours=  c("grey95","#7b2625"),breaks=c(0,round(max(lfig2$v),2)))+
    labs(y = paste0("Reduction in R0,t","(%)"),x = "Vaccination rate (%)")+
    scale_y_continuous(limits=c(0,70),expand=c(0,0))+
    theme_clean()+
    theme(legend.position = "none",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.x = element_text(color="black",size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y = element_text(color="black",size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/fig3a.pdf"),fig3a,units="mm",width=75,height=60,device = cairo_pdf)
  
  my_comparisons <- list(c("(0,20]", "(20,40]"), c("(0,20]", "(40,60]"), c("(0,20]", "(60,80]"),
                         c("(20,40]", "(40,60]"),c("(20,40]", "(60,80]"),
                         c("(40,60]", "(60,80]")) 
  my_comparisons <- list(c("(0,10]", "(10,20]"), c("(0,10]", "(20,30]"), c("(0,10]", "(30,40]"),c("(0,10]", "(40,50]"), c("(0,10]", "(50,60]"),
                        c("(0,10]", "(60,70]"), c("(0,10]", "(70,80]"), 
                        c("(10,20]", "(20,30]"), c("(10,20]", "(30,40]"),c("(10,20]", "(40,50]"), c("(10,20]", "(50,60]"), c("(10,20]", "(60,70]"),
                        c("(10,20]", "(70,80]"),
                        c("(20,30]", "(30,40]"), c("(20,30]", "(40,50]"), c("(20,30]", "(50,60]"),c("(20,30]", "(60,70]"),c("(20,30]", "(70,80]"),
                        c("(30,40]", "(40,50]"),c("(30,40]", "(50,60]"),c("(30,40]", "(60,70]"),c("((30,40]", "(70,80]"),
                        c("(40,50]", "(50,60]"),c("(40,50]", "(60,70]"),c("((40,50]", "(70,80]"),
                        c("(50,60]", "(60,70]"),c("(50,60]", "(70,80]"),c("(60,70]", "(70,80]")) 
  mydata2<-do.call(rbind,lapply(split(lfig1,lfig1$s1),function(data){
    if(length(unique(data$v1))>1){
        c<-as.data.frame(compare_means(m ~ v1, data = data,method="anova"))
        c$par<-unique(data$s1)
        return(c)}else{return(NULL)}
  }))
  write.csv(mydata2,paste0(outpath,"/fig3b.csv"),row.names = F)
  lfig1<-subset(lfig1,lfig1$s>0.2)

  write.csv(lfig1,paste0(outpath,"/fig3bsamplesize.csv"),row.names = F)
  
  fig3b<-ggplot()+
    geom_boxplot(data=lfig1,aes(x=s1,y=m,fill=v1,color=v1), 
                 alpha=0.5,width=0.9,size=0.1,outlier.size = 0.01)+
    scale_fill_manual(values = c("#cec2d6","#fde590",
                                 "#f7a95f","#14a1a7",
                                 "#9bbeda","#6e6e4b",
                                 "#e3c6c2","#c4c3be"
    ))+
    scale_color_manual(values = c("#cec2d6","#fde590",
                                  "#f7a95f","#14a1a7",
                                  "#9bbeda","#6e6e4b",
                                  "#e3c6c2","#c4c3be"))+
    labs(y = paste0("Reduction in R0,t","(%)"),
         x = "Stringency index intensity")+
    scale_y_continuous(limits=c(10,60),breaks=c(0,15,30,45,60),expand=c(0,0))+
    theme_clean()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.x = element_text(color="black",size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y = element_text(color="black",size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",
                                        colour = NA))
  ggsave(paste0(outpath,"/fig3b.pdf"),fig3b,units="mm",width=75,height=100,device = cairo_pdf)
  
  DatasetV2<-read.csv(paste0(inputpath,"/R0_Europe_dataset_1220withinR0.csv"),stringsAsFactors = F)
  Variants<-read.csv("Dataset/covid-variants.csv")
  ################plot fig3a-2##############
  D<-DatasetV2[,c("Fully_vaccinated_effect","Date","location")]
  D$Date<-as.Date(D$Date)
  D$m<-cut(D$Date,breaks=seq(as.Date("2020-08-01"),max(D$Date)+30,30))
  D<-D[complete.cases(D),]
  D<-D%>%dplyr::group_by(m,location)%>%dplyr::summarise(Fully_vaccinated_effect=mean(Fully_vaccinated_effect))
  D$v1<-cut(D$Fully_vaccinated_effect*100,breaks=seq(-10,80,10))
  
  D$m<-as.Date(D$m)
  conv<-D[,c("m","v1","location")]%>%dplyr::group_by(v1,location)%>%dplyr::summarise(min=min(m),max=max(m))
  conv<-conv[complete.cases(conv),]
  Variants[is.na(Variants)]<-0
  Variants$date<-as.Date(Variants$date)
  Variants<-do.call(rbind,split(Variants,Variants$location)[unique(D$location)])
  
  dv<-lapply(seq(1,9),function(n){
    v<-split(conv,conv$v1)[[n]]
    if(n>1){
      v1<-split(conv,conv$v1)[[n-1]]
    }
    if (nrow(v)>0){
      vlist<-lapply(1:length(split(v,v$location)),function(m){
        l<-split(v,v$location)[[m]]
        if(n>1){min<-v1$max[which(v1$location==l$location)]}else(min<-l$min)
        k<-subset(Variants,Variants$date<=l$max&Variants$date>l$min)
        k<-k[,-c(1,2)]%>%dplyr::group_by(variant)%>%dplyr::summarise_each(funs(sum))
        return(k)
      })
      i<-do.call(rbind,vlist)
      if (nrow(i>0)){
        i<-i[,-3]%>%dplyr::group_by(variant)%>%dplyr::summarise_each(funs(sum))
        alphaN<- i$num_sequences[which(i$variant=="Alpha")]/i$num_sequences_total[1]
        betaN<-i$num_sequences[which(i$variant=="Beta")]/i$num_sequences_total[1]
        gammaN<-i$num_sequences[which(i$variant=="Gamma")]/i$num_sequences_total[1]
        deltaN<-i$num_sequences[which(i$variant=="Delta")]/i$num_sequences_total[1]
        etaN<-i$num_sequences[which(i$variant=="Eta")]/i$num_sequences_total[1]
        kappaN<-i$num_sequences[which(i$variant=="Kappa")]/i$num_sequences_total[1]
        baseN<-1-alphaN-betaN-gammaN-deltaN-etaN-kappaN
        r<-data.frame(alpha=alphaN,beta=betaN,
                      gamma=gammaN,delta=deltaN,eta=etaN,kappa=kappaN,
                      base=baseN,v=as.vector(unique(v$v1)))
      }else{r<-NULL}
    }else{r<-NULL}
    return(r)
  })
  varD<-do.call(rbind,dv)
  varD$v<-unique(conv$v1)
  varD<-melt(varD,id="v")
  fig2b4<-ggplot(data=varD,aes(v,value,fill=variable))+geom_bar(stat="identity",position="stack")+
    scale_fill_manual(values=  c("#d2dde4","#f5ba93","#80bfb0","#ead4e2","#75cbe8","#f6dd6e","#fff7ee"))+
    labs(y = paste0("Proportion of variant","(*100%)"),x = "Vaccination rate (%)")+
    scale_y_continuous(limits=c(0,1),expand=c(0,0))+
    theme_clean()+
    theme(legend.position = "bottom",
          legend.title=element_blank(),
          plot.title = element_text(color="black",hjust = 0.5,vjust=0,size = unit(9, "pt")),
          axis.title.x= element_text(color="black",size = unit(9, "pt")),
          axis.text.x = element_text(color="black",size = unit(9, "pt")),
          axis.title.y= element_text(color="black",size = unit(9, "pt")),
          axis.text.y = element_text(color="black",size = unit(9, "pt")),
          plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
          panel.background=element_rect(fill = "transparent",colour = NA))
  ggsave(paste0(outpath,"/fig3a-2.pdf"),fig2b4,units="mm",width=75,height=50,device = cairo_pdf)
}

