forestplot<-function(DatasetV2,path,xname,outpath){
  conlist<-list.files(path)
  eachC<-do.call(rbind,lapply(conlist,function(c){
    k<-subset(DatasetV2,DatasetV2$location==strsplit(c,"_")[[1]][1])
    k$Tem<-(k$Tem-min(k$Tem))/(max(k$Tem)-min(k$Tem))
    fit<-readRDS(paste0(path,"/",c,"/all.rds"))
    out<-rstan::extract(fit)
    alpha<-as.data.frame(out$alpha)
    beta<-as.data.frame(out$beta)
    eli<-as.data.frame(out$eli)
    start<-as.Date("2020-08-01")
    d<-do.call(rbind,lapply(seq(1,15),function(i){
      start<-start+30*(i-1)
      end<-start+30
      al<-alpha[,((i-1)*3+1):(i*3)]
      be<-beta[,i]
      el<-eli[,i]
      pars<-do.call(cbind,list(al,be,el))
      colnames(pars)<-c(xname,"Air Temperature","Epslion")
      k1<-subset(k,k$Date>=start&k$Date<end)
      X<-do.call(cbind,lapply(c(xname,"Tem","Epslion"),function(x){
        if(x=="Epslion"){m<-1}else{
          m<-mean(k1[,x])
        }
        return(m)
      }))
      colnames(X)<-c(xname,"Air Temperature","Epslion")
      for (k in c(xname,"Air Temperature","Epslion")){
        pars[,k]<- pars[,k]*X[,k]}
      pars$all<-apply(pars,1,sum)
      pars$all_H<-pars[,xname[1]]+pars[,xname[2]]+pars[,xname[3]]
      pars<-(1-exp(-pars))*100
      pard<-mcmc_intervals_data(pars,prob = .5,prob_outer= .95,point_est="median")
      pard$start<-start
      pard$end<-end
      pard$country<-strsplit(c,"_")[[1]][1]
      pard$strength<-0
      for (i in c(xname,"Air Temperature","Epslion")){
        pard$strength[which(pard$parameter==i)]<-X[,i]
      }
      data<-data.frame(n=30,
                       sd_SI=sd(pars[,xname[1]]),sd_Int=sd(pars[,xname[3]]),
                       sd_V=sd(pars[,xname[2]]),sd_Tem=sd(pars[,c("Air Temperature")]),
                       sd_Eli=sd(pars[,c("Epslion")]),sd_R0=mean(k1$R0_sd),
                       mean_SI=mean(pars[,xname[1]]),mean_Int=mean(pars[,xname[3]]),
                       mean_V=mean(pars[,xname[2]]),mean_Tem=mean(pars[,c("Air Temperature")]),
                       mean_Eli=mean(pars[,c("Epslion")]),mean_R0=mean(k1$R0),
                       strength_SI=X[,xname[1]],median_SI=pard$m[which(pard$parameter==xname[1])],
                       q1_SI=pard$ll[which(pard$parameter==xname[1])],q3_SI=pard$hh[which(pard$parameter==xname[1])],
                       min_SI=min(pars[,xname[1]]),max_SI=max(pars[,xname[1]]),
                       strength_Int=X[,xname[3]],median_Int=pard$m[which(pard$parameter==xname[3])],
                       q1_Int=pard$ll[which(pard$parameter==xname[3])],q3_Int=pard$hh[which(pard$parameter==xname[3])],
                       min_Int=min(pars[,xname[3]]),max_Int=max(pars[,xname[3]]),
                       strength_V=X[,xname[2]],median_V=pard$m[which(pard$parameter==xname[2])],
                       q1_V=pard$ll[which(pard$parameter==xname[2])],q3_V=pard$hh[which(pard$parameter==xname[2])],
                       min_V=min(pars[,xname[2]]),max_V=max(pars[,xname[2]]),
                       strength_Tem=X[,"Air Temperature"],median_Tem=pard$m[which(pard$parameter=="Air Temperature")],
                       q1_Tem=pard$ll[which(pard$parameter=="Air Temperature")],q3_Tem=pard$hh[which(pard$parameter=="Air Temperature")],
                       min_Tem=min(pars[,"Air Temperature"]),max_Tem=max(pars[,"Air Temperature"]),
                       strength_Eli=X[,"Epslion"],median_Eli=pard$m[which(pard$parameter=="Epslion")],
                       q1_Eli=pard$ll[which(pard$parameter=="Epslion")],q3_Eli=pard$hh[which(pard$parameter=="Epslion")],
                       min_Eli=min(pars[,"Epslion"]),max_Eli=max(pars[,"Epslion"]),
                       median_R0=mean(k1$R0),
                       q1_R0=mean(k1$R0_CI95low),q3_R0=mean(k1$R0_CI95high),
                       country=strsplit(c,"_")[[1]][1],start=start,
                       Rt=mean(k1$Rt))
      return(data)
    }))
    return(d)
  }))
  f<-split(eachC,eachC$start)[[15]]
  #R0
  sir<-metamean(n=f$n,mean=f$mean_R0,sd=f$sd_R0,studlab = f$country)
  si<-summary(sir)$random
  weight<-sir$w.random/sum(sir$w.random)
  r<-data.frame(start=f$start[1],par="R0",
                strength=NA,
                m=si$TE,lower=sum(f$q1_R0*weight),upper=sum(f$q3_R0*weight),
                min=NA,max=NA)
  #air temperature
  sia<-metamean(n=f$n,mean=f$mean_Tem,sd=f$sd_Tem,studlab = f$country)
  si<-summary(sia)$random
  weight<-sia$w.random/sum(sia$w.random)
  t<-data.frame(start=f$start[1],par="Air Temperature",
                strength=mean(f$strength_Tem),
                m=si$TE,lower=sum(sia$lower*weight),upper=sum(sia$upper*weight),
                min=sum(f$min_Tem*weight),max=sum(f$max_Tem*weight))
    #Epslion
  sie<-metamean(n=f$n,mean=f$mean_Eli,sd=f$sd_Eli,studlab = f$country)
  si<-summary(sie)$random
  weight<-sie$w.random/sum(sie$w.random)
  e<-data.frame(start=f$start[1],par="Epslion",
                strength=1,
                m=si$TE,lower=sum(sie$lower*weight),upper=sum(sie$upper*weight),
                min=sum(f$min_Eli*weight),max=sum(f$max_Eli*weight))
    
  if(max(f$median_SI)>0){
    ds<-subset(f,f$mean_SI>0)
    sim<-metamean(n=ds$n,mean=ds$mean_SI,sd=ds$sd_SI,studlab = ds$country)
    si<-summary(sim)$random
    weight<-sim$w.random/sum(sim$w.random)
    s<-data.frame(start=f$start[1],par="Stringency Index",
                  strength=mean(f$strength_SI),
                  m=si$TE,lower=sum(sim$lower*weight),upper=sum(sim$upper*weight),
                  min=sum(f$min_SI*weight),max=sum(f$max_SI*weight))
  }else{s<-NULL}
  if(is.null(f$mean_V)==F){
    if(max(f$mean_V)>0){
      dv<-subset(f,f$mean_V>0)
      vm<-metamean(n=dv$n,mean=dv$mean_V,sd=dv$sd_V,studlab = dv$country)
      va<-summary(vm)$random
      weight<-vm$w.random/sum(vm$w.random)
      v<-data.frame(start=dv$start[1],par="Vaccination",
                    strength=mean(dv$strength_V),
                    m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight),
                    min=sum(f$min_V*weight),max=sum(f$max_V*weight))
    }else{v<-NULL}
    if(max(f$median_Int)>0){
      dI<-subset(f,f$median_Int>0)
      vm<-metamean(n= dI$n,mean=dI$mean_Int,sd=dI$sd_Int,studlab=dI$country)
      va<-summary(vm)$random
      weight<-vm$w.random/sum(vm$w.random)
      i<-data.frame(start=dI$start[1],par="Interaction of SI and Vaccination",
                    strength=mean(dI$strength_Int),
                    m=va$TE,lower=sum(vm$lower*weight),upper=sum(vm$upper*weight),
                    min=sum(f$min_Int*weight),max=sum(f$max_Int*weight))
    }else{i<-NULL}
  }
  pdf(paste0(outpath,"/forestSIa.pdf"),height=7.5,width=7, onefile = T)
  forest(sim,family="sans",fontsize=9,lwd=2,
         col.diamond.fixed="lightslategray",
         col.diamond.line.fixed="lightslategray",
         col.diamond.random = "maroon",col.diamond.lines.random = "maroon",
         col.square = "#b2b4c6",col.study = "lightslategray")
  dev.off()
  gc()
  pdf(paste0(outpath,"/forestSIb.pdf"),height=7.5,width=7, onefile = T)
  forest(metainf(sim, pooled="random"),family="sans",fontsize=9,lwd=2,
         col.diamond.fixed="lightslategray",
         col.diamond.line.fixed="lightslategray",
         col.diamond.random = "maroon",col.diamond.lines.random = "maroon",
         col.square = "#b2b4c6",col.study = "lightslategray")
  dev.off()
  gc()
  pdf(paste0(outpath,"/forestVaca.pdf"),height=7.5,width=7, onefile = T)
  forest(vm,family="sans",fontsize=9,lwd=2,
         col.diamond.fixed="lightslategray",
         col.diamond.line.fixed="lightslategray",
         col.diamond.random = "maroon",col.diamond.lines.random = "maroon",
         col.square = "#b2b4c6",col.study = "lightslategray")
  dev.off()
  gc()
  pdf(paste0(outpath,"/forestVacb.pdf"),height=7.5,width=6, onefile = T)
  forest(metainf(vm, pooled="random"),family="sans",fontsize=9,lwd=2,
         col.diamond.fixed="lightslategray",
         col.diamond.line.fixed="lightslategray",
         col.diamond.random = "maroon",col.diamond.lines.random = "maroon",
         col.square = "#b2b4c6",col.study = "lightslategray")
  dev.off()
  gc()
}





