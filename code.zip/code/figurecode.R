library("ggplot2")

setwd("E:/COVID19_vacciantion1210")#se
###########fig 1 a_1#############
DatasetV2<-read.csv("20220329_V2normal(0,0.3)0.5/R0_Europe_dataset_1220withinR0.csv",stringsAsFactors = F)
D<-subset(DatasetV2,DatasetV2$Date>="2020-08-01")
D<-D[,c("Date","iso_code","New_cases_smoothed")]
D$id<-1:nrow(D)
angle<-90-360*(D$id-0.5)/nrow(D)
basean <- do.call(rbind,lapply(split(D,D$iso_code),FUN = function(v){
  f<-data.frame(start=min(v$id),end=max(v$id),iso_code=unique(v$iso_code))
  f$mid<-(f$start +f$ end) / 2
  return(f)
}))

textangle<-angle[floor(basean$mid)]

colorpal<-c("#a18480","#5e7b7f","#a99fc6","#d2691e","#5e86c1","#a1793e",
            "#808000","#ebbe00","#8a322e","#d9e0c4","#506797","#bfac85",
            "#9084b4","#9c9c9c","#7f6358","#a0522d","#c4daee","#675f4c",
            "#c3aebf","#3c5140","#bcd1a2","#354b36","#868381","#b8977b",
            "#7c5335","#cac8b5","#fff1cd","#90e3ff","#ff9ce6","#963f00","#617600")
g<-ggplot(data=D,aes(id, New_cases_smoothed/1000,fill=iso_code))+
  geom_col(position = position_dodge2(),width = 0.9)+
  geom_segment(data=basean,aes(x=start,y=-5,xend=end,yend=-5,color=iso_code))+
  geom_text(data = basean, aes(x = mid, y = -10, label = iso_code), 
            angle=textangle,colour = "grey40",size=2) +
  coord_polar()+
  scale_fill_manual(values=colorpal)+
  scale_color_manual(values=colorpal)+
  scale_y_continuous(limits=c(-100,60),expand=c(0,0))+
  theme(plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
    legend.position = "",
    panel.background = element_blank(),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    panel.grid = element_blank())
ggsave(g, filename = "picture/fig1a-1.pdf",unit="mm",device = cairo_pdf)

dv<-subset(DatasetV2,DatasetV2$Date=="2021-10-25")
dv1<-dv[,c("location","Fully_vaccinated_effect","Fully_vaccinated_pre")]
D$month<-substring(D$Date,0,7)
d1<-D[,c("month","New_cases_smoothed")]%>%dplyr::group_by(month)%>%dplyr::summarize_each(funs(sum))
###########fig 1 a_2#############

library("sf")
library("rnaturalearth")
library("rnaturalearthdata")
library("dplyr")
library("mapproj")
library("fiftystater")
world<-map_data("world")
Dataset<-do.call(rbind,lapply(split(DatasetV2,DatasetV2$location),function(x){
  data.frame(iso=unique(x$iso_code),region=unique(x$location),Vaccination_Fully=max(x$Fully_vaccinated_pre))
}))
Dataset$region[which(Dataset$region=="Czechia")]<-"Czech Republic"
Dataset$region[which(Dataset$region=="United Kingdom")]<-"UK"
world<-full_join(world,Dataset,by="region")

world$w<-1
world$w[which(is.na(world$iso_code))]<-0
world$w<-as.factor(world$w)
p1<-ggplot()+
  geom_polygon(data = world,aes(x=long,y=lat,group=group,fill=Vaccination_Fully),color="white",size=0.1, inherit.aes = F)+  
  #scale_fill_manual(values =c("#eceae4","#576897"))+ 
  scale_fill_gradientn(colors =c("#bfcee5","#c5c8e8","#0b59be"),na.value  = "#ededed",)+
  coord_map("ortho",orientation = c(50,10,0))+
  theme(legend.position = "bottom",
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background = element_blank(),
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        panel.border = element_blank())
ggsave(p1, filename = "picture/fig1a-2.pdf",width=300,heigh=300,unit="mm",device = cairo_pdf)

###########fig 1 b#############
Dataset<-subset(DatasetV2,DatasetV2$Date>="2020-08-01")
var<-Dataset[,c("Date","alphaN","betaN","gammaN","deltaN",
                  "etaN","kappaN","baseN")]
Dataset$Date<-as.Date(Dataset$Date)
var_mean<-group_by(var,Date)%>%summarize_each(funs(mean))

v<-melt(var_mean,id=c("Date"))
v1<-subset(v,v$Date=="2021-01-31")
v1$Date<-"2021-01-30"
v<-do.call(rbind,list(v,v1))
#v<-subset(v,v$Date<="2021-09-16")
v$value[which(v$value==0)]<-NA

var<-ggplot(v,aes(x=as.Date(Date),y=variable))+
  geom_tile(aes(fill=value),
            color="white",lwd=0.1,
            linetype=1)+
  scale_fill_gradientn(colours= brewer.pal(7,"YlGnBu"),na.value="grey99",
                       values=c(0,0.01,0.3,0.6,1.0))+
  scale_x_date(limits=as.Date(c("2020-08-01",max(v$Date))),
               breaks=("1 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  labs(y =NULL,x = NULL)+theme_light()+
  theme(legend.position = "right",
        legend.title=element_blank(),
        legend.key.height=unit(0.4,'cm'),
        legend.key.width =unit(0.1,'cm'),
        #panel.grid=element_line(color="transparent",size=0.01),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_text(color="black",size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.5,0.5,0.5,0.5),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/variant_distribution.pdf",var,width=180,height=40,units="mm",device = cairo_pdf)
dev.off()
###########fig 1 c#############
vv<-DatasetV2[,c("Date","Johnson.Johnson","Moderna","Oxford.AstraZeneca","Pfizer.BioNTech",
                 "Sputnik.V","Sinopharm.Beijing")]
 

vv1<-group_by(vv,Date)%>%summarize_each(funs(mean))

vc<-melt(vv1,id=c("Date"))
vc1<-subset(vc,vc$Date=="2021-01-31")
vc1$Date<-"2021-01-30"
vc<-do.call(rbind,list(vc,vc1))
#vc<-subset(vc,vc$Date<="2021-07-25")
vc$value[which(vc$value==0)]<-NA
vacman<-ggplot(vc,aes(x=as.Date(Date),y=variable))+
  geom_tile(aes(fill=value),
            color="white",lwd=0.1,
            linetype=1)+
  scale_fill_gradientn(#colours=c("#4575B4","#E0F3F8","#FFFFD4","#FEE090","#D73027"),
                       colours= brewer.pal(7,"YlGnBu"),
                       na.value="grey99",
                       values=c(0,0.05,0.2,0.5,0.75,1.0))+
  #scale_fill_gradientn(colours= c("white","#829abf","#3d5985","#425066"), values=c(0,0.02,0.3,1))+
  scale_x_date(limits=as.Date(c("2020-08-01",max(v$Date))),
               breaks=("1 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  labs(y =NULL,x = NULL)+theme_light()+
  theme(legend.position = "right",
        legend.title=element_blank(),
        legend.key.height=unit(0.3,'cm'),
        legend.key.width =unit(0.1,'cm'),
        plot.title = element_text(color="black",size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/vaccine_distribution.pdf",vacman,width=180,height=35,units="mm",device = cairo_pdf)
###########fig 1 d#############

c<-Dataset[,c("Date","location","StringencyIndex","Fully_vaccinated_pre")]
c$Fully_vaccinated_pre<-c$Fully_vaccinated_pre*100
c$StringencyIndex<-c$StringencyIndex*100
cs<-c[,c("Date","location","StringencyIndex")]

cpcol1 <- c("#697fa0", "#526582", "#4682b4", "#4682b4", "#5e86c1", 
           "#97c0e2", "#5b94c2", "#80acd0", "#2eaec6","#2f5a7f", "#0f3c62", 
           "#6587bf", "#9bb1d4", "#2e73c6","#36517d", "#7b8ca9",
           "#b3bccc",  "#8d8fb3", "#8674a1", "#8d8fb3", "#666999", 
           "#cacbdd",  "#78699f", "#b9b1cd", "#778899", "#719fda", "#496e9c",
           "#5686bf","#a099b2","#248f97","#2888e8")
cpcol3<-c("#d9d7cb","#e2dec2","#ece5b8","#fbf1a9","#fae780","#f8c43f",
          "#c59007","#fafb94","#f8fa70","#eaeaae","#d5d661","#c29b32",
          "#ffe6a3","#dcce8f","#d6c499","#c2b54c","#d1c13d","#f0ebc1",
          "#d8ca88","#87772c","#fdeb86","#c4a603","#fbd509","#dfd4c5",
          "#eed6b6","#e0b376","#b0a586")
cpcol2 <- c("#e5d7dd", "#d1b9c5", "#c19fb0", "#9a6580", "#7f5369", "#bc6e57",
           "#eadfe5", "#ddcad1", "#c9abb6", "#af8393", "#986276", "#8c3840",
           "#dfced2", "#c7a9b0", "#ae848e", "#b35b70", "#853d4e", "#b0636a",
           "#cc9090", "#dcb2b2", "#a13030", "#9f6e92", "#a78b8d","#8e645d",
           "#836063", "#cdbcbc", "#e1a893", "#719fda", "#70341f","#f5e2db","#c5927d")

f1<-ggplot(data=c)+
  geom_step(aes(x=as.Date(Date),y=Fully_vaccinated_pre,color=location),size=0.3,alpha=0.1)+
  geom_smooth(aes(x=as.Date(Date),y=Fully_vaccinated_pre),
              color="#602029",fill="#d4aaae",span=0.5,size=0.9)+
  scale_color_manual(values=cpcol2)+
  scale_x_date(limits=as.Date(c("2020-08-01",max(Dataset$Date))),
               breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  scale_y_continuous(limits=c(0,100),expand = c(0,0),breaks=seq(0,100,20))+
  labs(y ="Intensity (%)",x = NULL)+theme_light()+
  theme(legend.position = "none",
        #panel.grid.major = element_line(colour = "transparent"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/fig1b-1.pdf",f1,width=100,height=80,units="mm",device = cairo_pdf)
f2<-ggplot(data=c)+
  geom_step(aes(x=as.Date(Date),y=StringencyIndex,color=location),size=0.3,alpha=0.1)+
  geom_smooth(aes(x=as.Date(Date),y=StringencyIndex),linetype=2,color="#606bbc",fill="#b9bad8",
              span=0.5,size=0.9)+
  scale_color_manual(values=cpcol1)+
  scale_x_date(limits=as.Date(c("2020-08-01",max(Dataset$Date))),
               breaks=("2 month"),labels=date_format("%b\n%Y"),expand=c(0,0))+
  scale_y_continuous(limits=c(0,100),expand = c(0,0),breaks=seq(0,100,20))+
  labs(y ="Intensity (%)",x = NULL)+theme_light()+
  theme(legend.position = "none",
        #panel.grid.major = element_line(colour = "transparent"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("picture/fig1b-2.pdf",f2,width=100,height=80,units="mm",device = cairo_pdf)
###########fig 1 e#############
###########plot R0 and Rt##################
Dataset<-subset(DatasetV2,DatasetV2$Date>="2020-08-01")
c<-Dataset[,c("Date","location","Rt")]
R<-Dataset[,c("Date","R0","Rt")]
R1<-R%>%dplyr::group_by(Date)%>%summarize_each(funs(mean))
cbPalette <- c("#f5ead6", "#e6c68e", "#deb368", "#d1952e", "#8e661f", 
               "#d3c6b1", "#bba886", "#a78e62", "#89734d", "#52452e", 
               "#d8d1ca", "#c7bdb3", "#aa9b8d", "#7e6d5d", "#726040", 
               "#e5be9e", "#daa172", "#ce8346", "#ad672e", "#895224", 
               "#feeab4", "#fdde87", "#fcd055", "#ebae05", "#7d5d02","#a27c3c")

f<-ggplot(data=R1)+
  geom_smooth(aes(x=as.Date(Date),y=Rt),color="#60868d",span=0.4,size=0.9,alpha=0.4)+
  geom_smooth(aes(x=as.Date(Date),y=R0),color="#9cbcbc",span=0.4,size=0.9,alpha=0.4,linetype=4)
gg1 <- ggplot_build(f)

# extract data for the loess lines from the 'data' slot
df2 <- data.frame(x = gg1$data[[1]]$x,
                  ymin = gg1$data[[1]]$y,
                  ymax = gg1$data[[2]]$y) 
f2<-f+
  geom_ribbon(data=df2,aes(x=as.Date(x), ymin = ymin, ymax = ymax),fill="#c6e7e6",
              alpha = 0.3)+
  scale_x_date(limits=as.Date(c("2020-08-01",max(Dataset$Date))),
               breaks=("2 month"),labels=date_format("%b\n%Y"))+
  scale_y_continuous(limits=c(0,5),expand = c(0,0),breaks=seq(0,5,1))+
  geom_vline(aes(xintercept=as.Date("2020-12-22"),color="#d2dde4",alpha=0.3))+
  geom_vline(aes(xintercept=as.Date("2021-05-04"),color="#d2dde4",alpha=0.3))+
  labs(y ="Repoduction number",x = NULL)+theme_clean()+
  scale_color_manual(values=cbPalette)+
  theme(legend.position = "",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        legend.title=element_blank(),
        plot.title = element_text(color="black",hjust = 0,vjust=0,size = 10),
        axis.title.x= element_text(color="black",size = 10),
        axis.text.x= element_text(color="black",size = 10),
        plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
        panel.background=element_rect(fill = "transparent",colour = NA))
ggsave("0924picture/fig2a-2.pdf",f2,width=90,height=30,units="mm",device = cairo_pdf)

